# DISURI Content Pillars

Six content pillars to rotate through for variety and consistent messaging.

## 1. Barrier Science

**Theme:** Why barrier health is the foundation of all skincare

**Key Messages:**
- Your barrier is why products don't work
- Barrier damage = hydration evaporation
- Fix the barrier, fix everything else

**Hook Examples:**
- "Your moisturizer isn't the problem. Your barrier is."
- "Why does everything evaporate by noon?"
- "Your barrier is leaking. Here's how to know."
- "Stop adding products. Start repairing your barrier."

**Post Template:**
```
[HOOK: Pattern interrupt about barrier]

[PROBLEM: 1-2 sentences on what happens with damaged barrier]

[SOLUTION: How DISURI product addresses this]

[CTA: Link or next step]

[HASHTAGS: 3-5 strategic]
```

**Example Post (Instagram):**
```
Your moisturizer isn't broken. Your barrier is.

You apply product after product but still feel dry by noon. 
That's not a hydration problem — it's a barrier problem.

Our HA Intense Cream doesn't just add moisture. The 2% niacinamide 
actually helps repair the barrier that holds moisture IN.

Hydration that lasts. Finally.

Link in bio 🔗

#BarrierRepair #KoreanSkincare #DISURIBeauty
```

---

## 2. K-Beauty Authority

**Theme:** Korean formulation expertise and Made in Korea quality

**Key Messages:**
- Korean formulators have studied skin for decades
- Concentrations matter (we tell you exactly what's in it)
- Made in Korea = gold standard

**Hook Examples:**
- "The Korean difference your skin will feel in 3 days"
- "Why Korean skincare actually works differently"
- "Made in Korea. There's a reason."
- "Korean formulators do this differently..."

**Post Template:**
```
[HOOK: Korean expertise angle]

[EDUCATION: What makes Korean formulation different]

[PROOF POINT: Specific concentration or ingredient fact]

[PRODUCT TIE: How DISURI embodies this]

[CTA + HASHTAGS]
```

**Example Post (TikTok Script):**
```
HOOK (0-2s): "Korean skincare isn't a trend. It's science."

TEXT OVERLAY: "Why K-beauty actually works"

BODY (2-15s): 
"Korean formulators have been studying barrier function for decades.
While Western brands focus on actives, Korean brands focus on delivery.
3,500ppm collagen. 10,000ppm hyaluronic acid. 
We tell you exactly what's in it."

CTA (15-18s): 
"Made in Korea. Glow like you own the city."
```

---

## 3. Urban Skin Survival

**Theme:** City life is hard on skin — we're your survival kit

**Key Messages:**
- Pollution, stress, AC, blue light are attacking your skin
- City skin needs different care
- Urban performance skincare (not spa skincare)

**Hook Examples:**
- "City skin needs a survival plan"
- "Your skin vs. your commute. Who's winning?"
- "NYC air is brutal. Your skincare should be tougher."
- "From 7am meetings to 11pm drinks. Your skin needs backup."

**Post Template:**
```
[HOOK: Urban stressor reference]

[RELATABLE MOMENT: City life scenario]

[SOLUTION: Product as urban armor]

[EMPOWERING CTA]
```

**Example Carousel (Instagram):**
```
Slide 1: "City skin hits different. (And not in a good way.)"
Slide 2: "THE DAMAGE: Pollution, blue light, AC, stress, coffee-as-breakfast"
Slide 3: "THE RESULT: Dull, dehydrated, aging faster"
Slide 4: "THE FIX: Barrier-first skincare that actually lasts"
Slide 5: "Ultimate Snail Mucin Cream: 92% snail secretion + adenosine"
Slide 6: "Made in Korea. Made for the city. Link in bio."
```

---

## 4. Routine Building

**Theme:** How to use, layering order, AM/PM routines

**Key Messages:**
- Order matters more than products
- Build a routine that works for YOUR life
- Less products, better results

**Hook Examples:**
- "The order that changes everything"
- "You're using your products wrong. Here's the fix."
- "AM vs PM: Why your routine should be different"
- "The 3-minute routine that actually works"

**Post Template:**
```
[HOOK: Routine mistake or revelation]

[STEP-BY-STEP: Clear, numbered routine]

[WHY IT WORKS: Brief science/logic]

[CTA: Try it yourself]
```

**Example Reel Script:**
```
HOOK: "Stop doing your skincare in the wrong order."

TEXT OVERLAYS (with demo):
1. "Foam cleanser (collagen while you cleanse)"
2. "Toner (10,000ppm HA prep)"
3. "Essence (85% water, absorbs in seconds)"
4. "Eye cream (before moisturizer!)"
5. "Moisturizer (seal it all in)"

CTA: "This is the DISURI system. Link in bio."
```

---

## 5. Results & Transformations

**Theme:** Real results, before/after, user testimonials

**Key Messages:**
- Results speak louder than claims
- Visible difference with consistent use
- Real people, real skin

**Hook Examples:**
- "2 weeks with snail mucin..."
- "I didn't believe it either. Then I tried it."
- "The before/after I wasn't expecting"
- "What 4 weeks of barrier repair looks like"

**Content Notes:**
- Use UGC when possible
- Always include timeframe
- Comply with FTC disclosure requirements
- Use realistic, achievable claims

**Example Post:**
```
"I thought my skin was just... dry."

After 3 weeks with the HA Intense Cream:
✓ Hydration that actually lasts past 10am
✓ Less makeup sliding off by noon
✓ Skin that looks healthy, not just moisturized

The difference? 2% niacinamide that helps repair the barrier.
Not just adding moisture. Keeping it in.

What are you waiting for? Link in bio.

#DISURIBeauty #BeforeAfter #BarrierRepair
```

---

## 6. Myth-Busting

**Theme:** Ingredient misconceptions, skincare myths

**Key Messages:**
- Let's cut through the skincare BS
- What the science actually says
- We're here to educate, not just sell

**Hook Examples:**
- "Collagen in skincare doesn't work? Wrong. Here's why."
- "Stop believing this skincare myth."
- "Your dermatologist didn't tell you this..."
- "Everything you've heard about snail mucin is wrong."

**Post Template:**
```
[HOOK: Bold myth statement]

[THE MYTH: What people believe]

[THE TRUTH: Science-backed reality]

[PRODUCT PROOF: How DISURI does it right]

[CTA]
```

**Example TikTok Script:**
```
HOOK: "Collagen in skincare is a scam? Let me explain."

MYTH: "People say topical collagen can't penetrate skin."

TRUTH: "They're right — about SOME collagen. 
But hydrolyzed collagen (broken into smaller molecules) 
can actually work on the surface to help with hydration and appearance."

PROOF: "That's why we use TRIPLE collagen — 
3 different molecular weights working at different levels.
3,500ppm total. Made in Korea."

CTA: "Science, not marketing. Link in bio."
```

---

## Content Mix Recommendations

**Weekly Balance:**
- 2-3 posts: Product-focused (rotate through line)
- 1-2 posts: Educational (barrier science, myth-busting)
- 1 post: Community/UGC/testimonial
- 1 post: Routine/how-to

**Platform Mix:**
- Instagram: Mix of Reels, Carousels, occasional static
- TikTok: All video, trend-aware, faster pace
- YouTube Shorts: Educational lean, slightly longer hooks
