# Platform Specifications

Detailed specs and best practices for each platform.

## Instagram

### Reels

**Technical Specs:**
- Duration: 15-90 seconds (sweet spot: 30-60s)
- Aspect ratio: 9:16 (1080x1920px)
- Safe zone: Keep text/graphics away from edges and bottom UI

**Performance Drivers:**
- First 3 seconds = make or break
- Native filming (in-app or edited to feel native)
- Trending audio boosts discovery
- Text overlays for sound-off viewing
- Strong hook + clear payoff

**Best Times to Post:** 
- Weekdays: 7-9am, 12-2pm, 7-9pm (target's schedule)
- Sundays: 10am-12pm (self-care scrolling)

**Caption Best Practices:**
- Front-load value (first 125 chars visible)
- Up to 2,200 characters total
- Line breaks for readability
- CTA at end (link in bio, save this, share with friend)

### Carousels

**Technical Specs:**
- Slides: 2-10 (optimal: 5-7)
- Dimensions: 1080x1350px (4:5) or 1080x1080px (1:1)
- File type: JPG or PNG

**Performance Drivers:**
- Swipe-worthy first slide (hook, not logo)
- Each slide = one clear point
- Progress through story/steps
- Final slide = strong CTA
- Save rate matters for algorithm

**Carousel Templates:**
1. **Problem → Solution:** Slide 1 problem, slides 2-4 why, slide 5-6 solution, slide 7 CTA
2. **Myth-Busting:** Slide 1 myth statement, slides 2-5 breakdown, slide 6 product, slide 7 CTA
3. **Step-by-Step:** Slide 1 title, slides 2-6 steps, slide 7 CTA
4. **Before/After:** Slide 1 hook, slide 2 before, slide 3 after, slides 4-5 how, slide 6 CTA

### Stories

**Technical Specs:**
- Duration: Up to 60s per story
- Dimensions: 1080x1920px (9:16)
- Interactive elements: polls, questions, links, quizzes

**Use Cases:**
- Behind-the-scenes
- Quick tips
- Poll engagement
- Link driving
- Flash sales
- Real-time content

### Hashtag Strategy

**Do:**
- Use 3-5 strategic hashtags
- Mix branded + discovery tags
- Place in caption or first comment
- Research hashtag volume (10K-500K sweet spot)

**Don't:**
- Use 30 hashtags (signals spam)
- Use #skincare #beauty (too generic)
- Put hashtags in middle of caption

**Recommended Hashtags:**
```
Branded: #DISURIBeauty #GlowLikeYouOwnTheCity
Product: #SnailMucin #TripleCollagen #KBeautyRoutine
Discovery: #BarrierRepair #KoreanSkincare #GlassSkin #UrbanSkincare
Niche: #SkincareIngredients #BarrierHealth #NiacinamideSkincare
```

---

## TikTok

### Technical Specs

**Video:**
- Duration: 15-180 seconds (sweet spot: 21-34 seconds)
- Aspect ratio: 9:16 (1080x1920px)
- Safe zones: Top 15% (username), bottom 20% (captions/UI)

**Hook Window:** 
- 0.8 seconds to grab attention
- If they don't stop scrolling, nothing else matters

### Content Formats That Work

1. **POV/Story:** "POV: You finally tried snail mucin"
2. **Before/After:** Visual transformation
3. **Get Ready With Me (GRWM):** Routine walkthrough
4. **Educational:** "Why [thing] doesn't work and what to do instead"
5. **Duet/Stitch:** React to skincare myths or claims
6. **Trend Participation:** Adapt trending sounds/formats to skincare

### Performance Drivers

**Watch Time is King:**
- Loop potential (ending connects to beginning)
- Pattern interrupts every 3-5 seconds
- Text overlays (75%+ watch muted)
- Fast cuts, no dead air

**Engagement Signals:**
- Comments (ask questions, spark debate)
- Shares (save-worthy or send-to-friend content)
- Follows (series content, personality)

### TikTok-Specific Writing

**Hook Formulas:**
- "The reason your [product] doesn't work..."
- "Nobody talks about this but..."
- "Stop doing [thing] immediately."
- "I was today years old when I learned..."
- "You're doing [thing] wrong. Here's the fix."

**Caption (Description):**
- Keep under 150 characters
- Front-load keywords for search
- Include 3-4 hashtags
- Use line breaks sparingly

**Text Overlays:**
- Large, readable font
- Contrast with background
- Center of frame (safe zone)
- Time synced with speech

### Trending Sounds

Check weekly. Adapt brand content to trending sounds when authentic fit exists.
Avoid: Sounds that feel forced or off-brand.

---

## YouTube Shorts

### Technical Specs

**Video:**
- Duration: Up to 60 seconds
- Aspect ratio: 9:16 (1080x1920px)
- Must include #Shorts in title or description

**Title:**
- 60 characters max
- Keyword-forward
- Clear, specific (not clickbait)

### How Shorts Differ from TikTok

| Factor | TikTok | YouTube Shorts |
|--------|--------|----------------|
| Hook window | 0.8s | 3s |
| Tone | Casual, trendy | Slightly more polished |
| Discovery | FYP algorithm | Search + suggested |
| Audience | Younger, trend-driven | Broader, tutorial-seeking |
| Sound | Trending sounds essential | Less sound-dependent |

### Content That Works on Shorts

1. **Quick Tips:** "One thing that changed my skin"
2. **Product Reveals:** Unboxing, first impressions
3. **Myth-Busting:** Fast debunks with proof
4. **Transformation:** Visual before/after
5. **Routine Clips:** Single step or full routine sped up

### Shorts Best Practices

- **Title card in first 3 seconds** (grab attention, set expectation)
- **Clear structure** (problem → solution, or step-by-step)
- **End with CTA** (subscribe, check description, try this)
- **More educational tone** than TikTok
- **Optimize for search** (keywords in title + description)

### Description Template
```
[Primary benefit + product name] 

[1-2 sentence expansion with key ingredient/proof point]

Try it yourself: [link]

#Shorts #KoreanSkincare #BarrierRepair #DISURI
```

---

## Cross-Platform Repurposing

### One Video → Three Platforms

**Source Content:** Create one high-quality video (TikTok-native works well as source)

**TikTok Version:**
- Native sound/trending audio
- Fastest cuts
- Most casual tone
- 15-34 seconds

**Instagram Reels Version:**
- Can be slightly longer (30-60s)
- IG-specific hashtags
- Caption can be more detailed
- May adjust audio for IG trends

**YouTube Shorts Version:**
- Add title card/intro (2-3s)
- Slightly more educational framing
- Optimize title for search
- Include #Shorts

### Adaptation Checklist

- [ ] Adjust aspect ratio if needed
- [ ] Check safe zones per platform
- [ ] Update hashtags for each platform
- [ ] Modify caption length/style
- [ ] Adjust audio (trending sounds vary by platform)
- [ ] Update CTA (bio link vs. description)
