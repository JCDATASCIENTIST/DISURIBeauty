# DISURI Beauty Brand Voice

## Core Identity

**Tagline:** "Glow Like You Own The City"

**Positioning:** Korean barrier-science skincare as urban performance equipment. Accessible luxury with cultural soul.

**Core Message:** Multi-benefit clinical actives + authentic K-beauty formulation expertise + bilingual community-driven movement.

## Target Audience

**Primary:** Urban professional women, ages 25-38
- $60K-$150K income
- Bilingual/bicultural (English/Spanish)
- Key cities: NYC, LA, Miami, Chicago, Houston, Mexico City, Bogotá, Medellín, São Paulo
- Skincare-as-investment mindset
- Research-driven (reads ingredients, understands formulations)

**Skin Concerns:**
- Barrier damage from urban stressors (pollution, stress, blue light)
- Hyperpigmentation/uneven tone
- Fine lines/loss of firmness
- Dehydration/dullness

## Voice Characteristics

| Attribute | What It Means | Example |
|-----------|---------------|---------|
| **Empowering** | Confidence-building, not preachy | "Your skin deserves this" not "You need to fix this" |
| **Science-backed** | Evidence-based, not clinical | "92% snail secretion" not "dermatologically tested" |
| **Culturally fluent** | Authentic Korean heritage, not performative | "Made in Korea by formulators who've studied skin for decades" |
| **No-nonsense** | Direct, cuts through BS | "This works because..." not "Maybe try..." |
| **Warm but direct** | Approachable expertise | Like advice from a friend who's also a chemist |

## Language Guidelines

### Do's
- Use "helps improve appearance of" 
- Use "supports" when describing benefits
- Include ingredient concentrations as proof points
- Include "Made in Korea" when space allows
- Use bilingual content (English/Spanish) where appropriate
- Reference barrier health as foundational concept
- Use urban imagery and language

### Don'ts
- Don't use "treats," "cures," or "heals"
- Don't say "repairs damaged skin" (medical claim)
- Don't say "clinically proven" without study citation
- Don't say "FDA-approved" (cosmetics aren't FDA-approved)
- Don't use spa vibes (this is urban energy)
- Don't use generic wellness language
- Don't over-promise or use superlatives without backing

## Mood & Energy

**Right Mood:**
- Urban luxury, NYC energy
- Premium but accessible
- Confident, not arrogant
- City lights, morning rush, power moves
- "I've got this" energy

**Wrong Mood:**
- Spa relaxation
- Soft, whispery wellness
- Overly scientific/cold
- Basic/generic beauty
- Desperate or pushy sales

## Visual Identity (Reference for Content)

**Primary Colors:**
- Power Crimson: #B82024
- Midnight Blue: #1f3f5c
- Molten Copper: #bf6738
- Soft Porcelain: #f4f2ee
- Deep Charcoal: #2a2a2a

**Typography:**
- Headlines: Bodoni Book (elegant, editorial)
- Subheads: Mrs Eaves (refined)
- Body: Frutiger (clean, modern)

## FDA Compliance for Content

### Approved Claim Language
✅ "Helps improve the appearance of..."
✅ "Supports smoother, younger-looking skin"
✅ "Helps reduce the appearance of fine lines"
✅ "Visible improvement with continued use"
✅ "Dermatologist tested"
✅ "Non-comedogenic"

### Prohibited Language
❌ "Treats," "Cures," "Heals"
❌ "Repairs damaged skin/barrier" (medical claim)
❌ "FDA-approved" (cosmetics aren't FDA-approved)
❌ "Eliminates wrinkles"
❌ "Anti-aging" without "appearance of"
❌ "Clinically proven" (without study citation)

### Ingredient-Specific Claims

**Adenosine:** 
- ✅ "Adenosine (Korean FDA-approved functional ingredient)"
- ❌ "US FDA-approved"

**Snail Mucin:**
- ✅ "92% snail secretion filtrate helps support barrier function"
- ❌ "Clinically proven to repair barrier"

**Niacinamide:**
- ✅ "2% niacinamide helps support barrier function"
- ❌ "Repairs damaged barrier"

**Collagen:**
- ✅ "Triple Collagen Complex helps improve firmness appearance"
- ❌ "Rebuilds collagen" or "Restores collagen levels"
