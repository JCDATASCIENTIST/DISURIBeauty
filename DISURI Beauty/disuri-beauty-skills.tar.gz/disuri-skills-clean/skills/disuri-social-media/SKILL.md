---
name: disuri-social-media
description: Social media content creation for DISURI Beauty skincare brand across Instagram, TikTok, and YouTube Shorts. Use when creating captions, video scripts, content calendars, carousel concepts, hooks, hashtag strategies, or repurposing content across platforms. Triggers on "DISURI social media", "DISURI Instagram", "DISURI TikTok", "DISURI content", "DISURI post", "DISURI video", "DISURI caption", "skincare content", or any social media request mentioning DISURI products (Snail Mucin, Triple Collagen, HA Cream, Foam, Toner, Eye Cream, Essence).
---

# DISURI Beauty Social Media Content Skill

Create on-brand social media content for DISURI Beauty's Korean skincare line.

## Quick Start

1. **Identify content type:** Caption, video script, carousel, or content calendar
2. **Select product focus:** Single product, product comparison, or brand-level
3. **Choose platform:** Instagram, TikTok, or YouTube Shorts (or all)
4. **Generate content** using brand voice and content pillars below

## Brand Voice Snapshot

**Tone:** Empowering, science-backed, culturally fluent, no-nonsense, warm but direct

**Tagline:** "Glow Like You Own The City"

**Target:** Urban professional women, 25-38, bilingual/bicultural (English/Spanish), skincare-as-investment mindset

**Key Rules:**
- Use "helps improve appearance of" not "treats" or "cures"
- Always include "Made in Korea" when space allows
- Never use spa vibes — this is urban energy
- Bilingual content encouraged

For full brand guidelines: See `references/brand_voice.md`

## Content Pillars

| Pillar | What It Covers | Example Hooks |
|--------|----------------|---------------|
| **Barrier Science** | Why barrier health matters, ingredient education | "Your barrier is why everything evaporates..." |
| **K-Beauty Authority** | Korean formulation expertise, Made in Korea quality | "The Korean difference your skin will feel..." |
| **Urban Skin Survival** | Pollution, stress, city life skin challenges | "City skin needs a survival plan..." |
| **Routine Building** | How to use, layering, AM/PM routines | "The order that changes everything..." |
| **Results & Transformations** | Before/after, user testimonials | "2 weeks with snail mucin..." |
| **Myth-Busting** | Ingredient misconceptions, skincare myths | "Collagen in skincare doesn't work? Here's wrong..." |

For post templates and examples: See `references/content_pillars.md`

## Platform Specifications

### Instagram
- **Reels:** 15-90s (sweet spot 30-60s), vertical 9:16
- **Carousels:** 2-10 slides, 1080x1350px
- **Captions:** Up to 2,200 chars, front-load value
- **Hashtags:** 3-5 strategic (avoid generic #skincare)

### TikTok
- **Duration:** 15-60s (sweet spot 21-34s)
- **Hook window:** 0.8 seconds to grab attention
- **Text overlays:** Required — many watch muted
- **Trending sounds:** Check weekly

### YouTube Shorts
- **Duration:** Up to 60s
- **Hook window:** 3 seconds
- **Vertical only:** 9:16
- **Title:** ≤60 chars, keyword-forward

For full specs and best practices: See `references/platform_specs.md`

## Products Quick Reference

| Product | Price | Hero Angle |
|---------|-------|------------|
| Ultimate Snail Mucin Cream | $34.99 | 92% snail secretion, barrier repair |
| Triple Collagen Firming Cream | $44.99 | 3,500ppm collagen, firmness |
| Hyaluronic Acid Intense Cream | $39.99 | Triple HA + 2% niacinamide, lasting hydration |
| Triple Collagen Foam | $14.99 | 3,000ppm collagen cleanser, never strips |
| Triple Collagen Toner | $27.99 | 10,000ppm HA prep toner |
| Triple Collagen Eye Cream | $33.99 | Under-eye fine lines, rich formula |
| Triple Collagen Essence | $19.99 | 85% water base, lightweight |

## Content Generation Workflows

### Single Post/Caption
1. Pick product + pillar combination
2. Write hook (under 10 words, pattern interrupt)
3. Add value/education (1-3 sentences)
4. Include CTA + hashtags
5. Adapt for each platform

### Video Script
1. Hook (0-3s): Pattern interrupt or bold claim
2. Tension (3-15s): Problem or misconception
3. Solution (15-45s): Product + how it works
4. Proof (if applicable): Results or science
5. CTA (final 5s): Next step

### Content Calendar
1. Map week across pillars (variety)
2. Balance product focus (rotate through line)
3. Mix content types (reels, carousels, static)
4. Plan repurposing (1 concept → 3 platforms)

### Cross-Platform Repurposing
**One video → Three platforms:**
- TikTok: Native, trending sound, fast cuts
- Instagram Reels: Same content, IG-specific hashtags, can be slightly longer
- YouTube Shorts: Add title card, slightly more educational tone

## Hashtag Strategy

**Brand-specific:** #DISURIBeauty #GlowLikeYouOwnTheCity #KoreanBarrierScience

**Product-specific:** #SnailMucinCream #TripleCollagen #KBeautyRoutine

**Strategic discovery:** #UrbanSkincare #BarrierRepair #KoreanSkincare #GlassSkin #SkincareRoutine

Avoid: #skincare #beauty #selfcare (too generic, low discovery value)

## Compliance Reminders

✅ "Helps improve the appearance of..."
✅ "Supports smoother, younger-looking skin"
✅ "Visible improvement with continued use"

❌ "Treats," "Cures," "Heals"
❌ "Repairs damaged skin" (medical claim)
❌ "Clinically proven" (without study citation)
❌ "FDA-approved" (cosmetics aren't FDA-approved)
