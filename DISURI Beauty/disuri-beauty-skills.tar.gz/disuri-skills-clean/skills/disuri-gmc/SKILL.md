---
name: disuri-gmc
description: Google Merchant Center product feed generation for DISURI Beauty skincare brand. Use when creating XML feeds, product listings, Google Shopping campaigns, or updating product data for DISURI Beauty's 7 SKUs (Snail Mucin Cream, Triple Collagen Cream, HA Cream, Foam, Toner, Eye Cream, Essence) and 3 bundles. Triggers on "Google Merchant Center", "GMC feed", "product feed", "Google Shopping", "DISURI products", or "product catalog".
---

# DISURI Beauty Google Merchant Center Skill

Generate compliant Google Merchant Center XML feeds for DISURI Beauty's Korean skincare products.

## Quick Reference

| Product | GTIN | Price | Size |
|---------|------|-------|------|
| Ultimate Snail Mucin Cream | 850064676372 | $34.99 | 1.76 oz |
| Triple Collagen Firming Cream | 850064676334 | $44.99 | 1.76 oz |
| Hyaluronic Acid Intense Cream | 850064676310 | $39.99 | 1.76 oz |
| Triple Collagen Firming Foam | 850064676365 | $14.99 | 4.05 oz |
| Triple Collagen Firming Toner | 850064676327 | $27.99 | 8.45 oz |
| Triple Collagen Firming Eye Cream | 850064676341 | $33.99 | 1.76 oz |
| Triple Collagen Firming Essence | 850066107188 | $19.99 | 5.07 oz |

**Bundles** (no GTINs - use `identifier_exists: no`):
- The Anti-Aging Power Duo: $76.48
- The Barrier Rescue System: $67.48  
- The Complete DISURI System: $101.97

## Workflow

### 1. Generate XML Feed

Run the feed generator script:
```bash
python3 scripts/generate_feed.py [--output /path/to/feed.xml] [--products all|individual|bundles]
```

Options:
- `--output`: Output path (default: `/mnt/user-data/outputs/disuri_feed.xml`)
- `--products`: Which products to include (default: `all`)

### 2. Validate Feed

Use Google's feed validator or check required fields:
- `id`, `title`, `description`, `link`, `image_link`, `price`, `availability`
- `gtin` (required for individual products)
- `brand`: DISURI Beauty
- `condition`: new

### 3. Customize Descriptions

For product-specific messaging, see:
- `references/product_catalog.md` - Complete product data with ingredients, benefits, messaging
- `references/brand_guidelines.md` - Voice, positioning, compliance rules

## Feed Specifications

**Required GMC Fields:**
```xml
<item>
  <g:id>SKU</g:id>
  <g:title>Product Title (max 150 chars)</g:title>
  <g:description>Product description (max 5000 chars)</g:description>
  <g:link>https://disuribeauty.com/products/[handle]</g:link>
  <g:image_link>https://disuribeauty.com/cdn/shop/files/[image]</g:image_link>
  <g:price>XX.XX USD</g:price>
  <g:availability>in_stock</g:availability>
  <g:brand>DISURI Beauty</g:brand>
  <g:gtin>850064676XXX</g:gtin>
  <g:condition>new</g:condition>
  <g:google_product_category>Health &amp; Beauty > Personal Care > Cosmetics > Skin Care</g:google_product_category>
</item>
```

**Optional Recommended Fields:**
- `g:product_type`: DISURI Beauty > Skincare > [Category]
- `g:shipping_weight`: [weight] oz
- `g:age_group`: adult
- `g:gender`: unisex
- `g:color`: (if applicable)

## Shopify Integration

Base URL: `https://disuribeauty.com`
CDN: `https://disuribeauty.com/cdn/shop/files/`

Product handles follow pattern: `[product-name-slug]`

## Compliance Notes

- All claims must be appearance-based (FDA cosmetic regulations)
- Use "helps improve appearance of" not "treats" or "cures"
- Korean FDA ingredient approvals (adenosine) ≠ US FDA product approval
- Disclose fragrance/colorant content where applicable
