#!/usr/bin/env python3
"""
DISURI Beauty Google Merchant Center Feed Generator

Generates XML product feeds compliant with Google Merchant Center specifications.
"""

import argparse
import xml.etree.ElementTree as ET
from xml.dom import minidom
from datetime import datetime
import os

# Product data
PRODUCTS = {
    "snail-mucin-cream": {
        "id": "snail-mucin-cream",
        "gtin": "850064676372",
        "title": "DISURI Beauty Ultimate Snail Mucin Cream - Korean Barrier Repair Moisturizer with 92% Snail Secretion Filtrate - 1.76 oz",
        "description": "Korean-formulated barrier repair cream with 92% snail secretion filtrate. Helps improve skin hydration, texture, and the appearance of fine lines while supporting barrier function. Contains adenosine and hyaluronic acid. Made in Korea.",
        "price": "34.99",
        "link": "https://disuribeauty.com/products/ultimate-snail-mucin-cream",
        "image_link": "https://disuribeauty.com/cdn/shop/files/snail-mucin-cream-main.jpg",
        "weight": "1.76 oz",
        "product_type": "DISURI Beauty > Skincare > Moisturizers > Barrier Repair",
        "google_category": "Health & Beauty > Personal Care > Cosmetics > Skin Care > Facial Moisturizers",
    },
    "triple-collagen-cream": {
        "id": "triple-collagen-cream",
        "gtin": "850064676334",
        "title": "DISURI Beauty Triple Collagen Firming Cream - Korean Anti-Aging Face Moisturizer with 3,500ppm Collagen + Adenosine - 1.76 oz",
        "description": "Rich Korean treatment cream with 3,500ppm Triple Collagen Complex (Soluble, Hydrolyzed, Extract). Helps improve the appearance of firmness, fine lines, and skin elasticity for face, neck, and décolletage. Contains adenosine. Made in Korea.",
        "price": "44.99",
        "link": "https://disuribeauty.com/products/triple-collagen-firming-cream",
        "image_link": "https://disuribeauty.com/cdn/shop/files/triple-collagen-cream-main.jpg",
        "weight": "1.76 oz",
        "product_type": "DISURI Beauty > Skincare > Moisturizers > Anti-Aging",
        "google_category": "Health & Beauty > Personal Care > Cosmetics > Skin Care > Anti-Aging Skin Care Products",
    },
    "ha-intense-cream": {
        "id": "ha-intense-cream",
        "gtin": "850064676310",
        "title": "DISURI Beauty Hyaluronic Acid Intense Hydration Cream - Korean Triple HA + 2% Niacinamide Barrier Repair - 1.76 oz",
        "description": "Korean lasting hydration system with Triple Hyaluronic Acid + 2% Niacinamide. Repairs barrier to help hydration last all day. Contains adenosine 450ppm, marine minerals. Regulates sebum for oily-but-dehydrated skin. Made in Korea.",
        "price": "39.99",
        "link": "https://disuribeauty.com/products/hyaluronic-acid-intense-hydration-cream",
        "image_link": "https://disuribeauty.com/cdn/shop/files/ha-intense-cream-main.jpg",
        "weight": "1.76 oz",
        "product_type": "DISURI Beauty > Skincare > Moisturizers > Hydration",
        "google_category": "Health & Beauty > Personal Care > Cosmetics > Skin Care > Facial Moisturizers",
    },
    "triple-collagen-foam": {
        "id": "triple-collagen-foam",
        "gtin": "850064676365",
        "title": "DISURI Beauty Triple Collagen Firming Foam Cleanser - Korean Anti-Aging Face Wash with 3,000ppm Collagen - 4.05 oz",
        "description": "Luxurious Korean foam cleanser with 3,000ppm Triple Collagen Complex. Cleanses while supporting the appearance of firmer, smoother skin. Rich cushiony foam with 8 Korean botanicals. Never strips. Made in Korea.",
        "price": "14.99",
        "link": "https://disuribeauty.com/products/triple-collagen-firming-foam",
        "image_link": "https://disuribeauty.com/cdn/shop/files/triple-collagen-foam-main.jpg",
        "weight": "4.05 oz",
        "product_type": "DISURI Beauty > Skincare > Cleansers > Foam",
        "google_category": "Health & Beauty > Personal Care > Cosmetics > Skin Care > Facial Cleansers",
    },
    "triple-collagen-toner": {
        "id": "triple-collagen-toner",
        "gtin": "850064676327",
        "title": "DISURI Beauty Triple Collagen Firming Toner - Korean Face Prep with 3,500ppm Collagen + 10,000ppm Hyaluronic Acid - 8.45 oz",
        "description": "Korean firming toner with 3,500ppm Triple Collagen + 10,000ppm Sodium Hyaluronate. Preps skin for better absorption while helping improve firmness appearance. Alcohol-free, pH-balanced. Contains bamboo and watermelon extracts. Made in Korea.",
        "price": "27.99",
        "link": "https://disuribeauty.com/products/triple-collagen-firming-toner",
        "image_link": "https://disuribeauty.com/cdn/shop/files/triple-collagen-toner-main.jpg",
        "weight": "8.45 oz",
        "product_type": "DISURI Beauty > Skincare > Toners",
        "google_category": "Health & Beauty > Personal Care > Cosmetics > Skin Care > Toners & Astringents",
    },
    "triple-collagen-eye-cream": {
        "id": "triple-collagen-eye-cream",
        "gtin": "850064676341",
        "title": "DISURI Beauty Triple Collagen Firming Eye Cream - Korean Under-Eye Treatment with 0.35% Collagen Complex - 1.76 oz",
        "description": "Korean under-eye treatment with 0.35% Triple Collagen Complex. Targets fine lines, crow's feet, and dryness. Rich formula with 7% Mineral Oil + 4% Glycerin for lasting moisture. Contains adenosine 0.04%. Made in Korea.",
        "price": "33.99",
        "link": "https://disuribeauty.com/products/triple-collagen-firming-eye-cream",
        "image_link": "https://disuribeauty.com/cdn/shop/files/triple-collagen-eye-cream-main.jpg",
        "weight": "1.76 oz",
        "product_type": "DISURI Beauty > Skincare > Eye Care",
        "google_category": "Health & Beauty > Personal Care > Cosmetics > Skin Care > Eye Treatments & Masks",
    },
    "triple-collagen-essence": {
        "id": "triple-collagen-essence",
        "gtin": "850066107188",
        "title": "DISURI Beauty Triple Collagen Hydrating Essence - Korean Face Treatment with 85% Water Base + 0.35% Collagen - 5.07 oz",
        "description": "Authentic Korean essence with 85.83% water base + 5% glycerin + 0.35% Triple Collagen Complex. Lightweight formula absorbs in seconds, preps skin for better product absorption. Contains 7 Korean botanicals. Made in Korea.",
        "price": "19.99",
        "link": "https://disuribeauty.com/products/triple-collagen-firming-essence",
        "image_link": "https://disuribeauty.com/cdn/shop/files/triple-collagen-essence-main.jpg",
        "weight": "5.07 oz",
        "product_type": "DISURI Beauty > Skincare > Essences",
        "google_category": "Health & Beauty > Personal Care > Cosmetics > Skin Care > Facial Serums & Treatments",
    },
}

BUNDLES = {
    "anti-aging-duo": {
        "id": "anti-aging-duo-bundle",
        "gtin": None,  # identifier_exists: no
        "title": "DISURI Beauty Anti-Aging Power Duo - Korean Triple Collagen Face + Eye Cream Bundle - Save 15%",
        "description": "Complete Korean anti-aging duo with Triple Collagen Firming Cream ($44.99) + Eye Cream ($33.99). Target face and under-eye aging signs together. Save 15% vs buying separately. Made in Korea.",
        "price": "76.48",
        "link": "https://disuribeauty.com/products/anti-aging-power-duo",
        "image_link": "https://disuribeauty.com/cdn/shop/files/anti-aging-duo-bundle-main.jpg",
        "weight": "3.52 oz",
        "product_type": "DISURI Beauty > Skincare > Bundles",
        "google_category": "Health & Beauty > Personal Care > Cosmetics > Skin Care > Skin Care Sets",
    },
    "barrier-rescue": {
        "id": "barrier-rescue-bundle",
        "gtin": None,
        "title": "DISURI Beauty Barrier Rescue System - Korean Snail Mucin + Eye Cream Bundle - Save 15%",
        "description": "Korean barrier repair duo with Ultimate Snail Mucin Cream ($34.99) + Triple Collagen Eye Cream ($33.99). Repair face and under-eye barrier together. Save 15% vs buying separately. Made in Korea.",
        "price": "67.48",
        "link": "https://disuribeauty.com/products/barrier-rescue-system",
        "image_link": "https://disuribeauty.com/cdn/shop/files/barrier-rescue-bundle-main.jpg",
        "weight": "3.52 oz",
        "product_type": "DISURI Beauty > Skincare > Bundles",
        "google_category": "Health & Beauty > Personal Care > Cosmetics > Skin Care > Skin Care Sets",
    },
    "complete-system": {
        "id": "complete-system-bundle",
        "gtin": None,
        "title": "DISURI Beauty Complete System - Korean Skincare Set with Snail Mucin + Collagen + HA Creams - Save 15%",
        "description": "Complete Korean skincare ritual with all three hero creams: Snail Mucin (barrier), Triple Collagen (firming), and Hyaluronic Acid (hydration). Save 15% vs buying separately. Subscribe for 33% savings. Made in Korea.",
        "price": "101.97",
        "link": "https://disuribeauty.com/products/complete-disuri-system",
        "image_link": "https://disuribeauty.com/cdn/shop/files/complete-system-bundle-main.jpg",
        "weight": "5.28 oz",
        "product_type": "DISURI Beauty > Skincare > Bundles",
        "google_category": "Health & Beauty > Personal Care > Cosmetics > Skin Care > Skin Care Sets",
    },
}

# Common attributes
BRAND = "DISURI Beauty"
CONDITION = "new"
AVAILABILITY = "in_stock"
AGE_GROUP = "adult"
GENDER = "unisex"
CURRENCY = "USD"


def create_item_element(product_data):
    """Create a single item element for the feed."""
    item = ET.Element("item")
    
    # Required fields (using g: prefix)
    ET.SubElement(item, "g:id").text = product_data["id"]
    ET.SubElement(item, "g:title").text = product_data["title"][:150]  # Max 150 chars
    ET.SubElement(item, "g:description").text = product_data["description"][:5000]  # Max 5000 chars
    ET.SubElement(item, "g:link").text = product_data["link"]
    ET.SubElement(item, "g:image_link").text = product_data["image_link"]
    ET.SubElement(item, "g:price").text = f"{product_data['price']} {CURRENCY}"
    ET.SubElement(item, "g:availability").text = AVAILABILITY
    ET.SubElement(item, "g:brand").text = BRAND
    ET.SubElement(item, "g:condition").text = CONDITION
    
    # GTIN or identifier_exists
    if product_data.get("gtin"):
        ET.SubElement(item, "g:gtin").text = product_data["gtin"]
    else:
        ET.SubElement(item, "g:identifier_exists").text = "no"
    
    # Google product category
    ET.SubElement(item, "g:google_product_category").text = product_data["google_category"]
    
    # Optional recommended fields
    if product_data.get("product_type"):
        ET.SubElement(item, "g:product_type").text = product_data["product_type"]
    
    if product_data.get("weight"):
        ET.SubElement(item, "g:shipping_weight").text = product_data["weight"]
    
    ET.SubElement(item, "g:age_group").text = AGE_GROUP
    ET.SubElement(item, "g:gender").text = GENDER
    
    return item


def generate_feed(output_path, include_products="all"):
    """Generate the Google Merchant Center XML feed."""
    
    # Build XML manually for proper namespace handling
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">',
        '  <channel>',
        '    <title>DISURI Beauty Product Feed</title>',
        '    <link>https://disuribeauty.com</link>',
        '    <description>Korean skincare products by DISURI Beauty</description>',
    ]
    
    # Add products based on selection
    products_to_add = {}
    
    if include_products in ["all", "individual"]:
        products_to_add.update(PRODUCTS)
    
    if include_products in ["all", "bundles"]:
        products_to_add.update(BUNDLES)
    
    for product_key, product_data in products_to_add.items():
        lines.append('    <item>')
        lines.append(f'      <g:id>{product_data["id"]}</g:id>')
        lines.append(f'      <g:title><![CDATA[{product_data["title"][:150]}]]></g:title>')
        lines.append(f'      <g:description><![CDATA[{product_data["description"][:5000]}]]></g:description>')
        lines.append(f'      <g:link>{product_data["link"]}</g:link>')
        lines.append(f'      <g:image_link>{product_data["image_link"]}</g:image_link>')
        lines.append(f'      <g:price>{product_data["price"]} {CURRENCY}</g:price>')
        lines.append(f'      <g:availability>{AVAILABILITY}</g:availability>')
        lines.append(f'      <g:brand>{BRAND}</g:brand>')
        lines.append(f'      <g:condition>{CONDITION}</g:condition>')
        
        if product_data.get("gtin"):
            lines.append(f'      <g:gtin>{product_data["gtin"]}</g:gtin>')
        else:
            lines.append('      <g:identifier_exists>no</g:identifier_exists>')
        
        lines.append(f'      <g:google_product_category><![CDATA[{product_data["google_category"]}]]></g:google_product_category>')
        
        if product_data.get("product_type"):
            lines.append(f'      <g:product_type><![CDATA[{product_data["product_type"]}]]></g:product_type>')
        
        if product_data.get("weight"):
            lines.append(f'      <g:shipping_weight>{product_data["weight"]}</g:shipping_weight>')
        
        lines.append(f'      <g:age_group>{AGE_GROUP}</g:age_group>')
        lines.append(f'      <g:gender>{GENDER}</g:gender>')
        lines.append('    </item>')
    
    lines.append('  </channel>')
    lines.append('</rss>')
    
    xml_content = '\n'.join(lines)
    
    # Write to file
    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(xml_content)
    
    print(f"✅ Feed generated: {output_path}")
    print(f"   Products included: {len(products_to_add)}")
    print(f"   Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    return output_path


def main():
    parser = argparse.ArgumentParser(
        description="Generate Google Merchant Center XML feed for DISURI Beauty"
    )
    parser.add_argument(
        "--output",
        "-o",
        default="/mnt/user-data/outputs/disuri_gmc_feed.xml",
        help="Output file path (default: /mnt/user-data/outputs/disuri_gmc_feed.xml)"
    )
    parser.add_argument(
        "--products",
        "-p",
        choices=["all", "individual", "bundles"],
        default="all",
        help="Which products to include (default: all)"
    )
    
    args = parser.parse_args()
    
    generate_feed(args.output, args.products)


if __name__ == "__main__":
    main()
