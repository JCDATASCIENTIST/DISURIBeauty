# DISURI Beauty Product Catalog

Complete product data for Google Merchant Center feeds and marketing.

## Individual Products (7 SKUs)

### 1. Ultimate Snail Mucin Cream

**Identifiers:**
- GTIN: 850064676372
- SKU: snail-mucin-cream
- Handle: ultimate-snail-mucin-cream

**Pricing & Size:**
- Price: $34.99 USD
- Size: 1.76 oz (50g)

**GMC Title (max 150 chars):**
DISURI Beauty Ultimate Snail Mucin Cream - Korean Barrier Repair Moisturizer with 92% Snail Secretion Filtrate - 1.76 oz

**Short Description:**
Korean-formulated barrier repair cream with 92% snail secretion filtrate. Helps improve skin hydration, texture, and the appearance of fine lines while supporting barrier function.

**Key Ingredients:**
- Snail Secretion Filtrate: 92%
- Contains: Allantoin, Glycolic Acid, Glycosaminoglycans, Collagen, Elastin
- Adenosine (KFDA-approved for wrinkle improvement)
- Hyaluronic Acid

**Target Audience:**
- Ages 25-38
- Urban professionals
- Barrier damage, dehydration, early aging signs
- K-beauty enthusiasts

**Google Product Category:**
Health & Beauty > Personal Care > Cosmetics > Skin Care > Facial Moisturizers

---

### 2. Triple Collagen Firming Cream

**Identifiers:**
- GTIN: 850064676334
- SKU: triple-collagen-cream
- Handle: triple-collagen-firming-cream

**Pricing & Size:**
- Price: $44.99 USD
- Size: 1.76 oz (50g)

**GMC Title (max 150 chars):**
DISURI Beauty Triple Collagen Firming Cream - Korean Anti-Aging Face Moisturizer with 3,500ppm Collagen + Adenosine - 1.76 oz

**Short Description:**
Rich Korean treatment cream with 3,500ppm Triple Collagen Complex. Helps improve the appearance of firmness, fine lines, and skin elasticity for face, neck, and décolletage.

**Key Ingredients:**
- Triple Collagen Complex: 3,500ppm total
  - Soluble Collagen: 2,000ppm
  - Hydrolyzed Collagen: 1,000ppm
  - Collagen Extract: 500ppm
- Adenosine: 0.04% (400ppm)
- Glycerin: ~5%
- Shea Butter, Mineral Oil (occlusives)
- Hyaluronic Acid

**Target Audience:**
- Ages 30-45
- Normal/dry/combination skin
- Loss of firmness, fine lines, "deflated" look
- Results timeline: 4-8 weeks

**Google Product Category:**
Health & Beauty > Personal Care > Cosmetics > Skin Care > Anti-Aging Skin Care Products

---

### 3. Hyaluronic Acid Intense Hydration Cream

**Identifiers:**
- GTIN: 850064676310
- SKU: ha-intense-cream
- Handle: hyaluronic-acid-intense-hydration-cream

**Pricing & Size:**
- Price: $39.99 USD
- Size: 1.76 oz (50g)

**GMC Title (max 150 chars):**
DISURI Beauty Hyaluronic Acid Intense Hydration Cream - Korean Triple HA + 2% Niacinamide Barrier Repair - 1.76 oz

**Short Description:**
Korean lasting hydration system with Triple Hyaluronic Acid + 2% Niacinamide. Repairs barrier to help hydration last all day, not just for hours. Regulates sebum for oily-but-dehydrated skin.

**Key Ingredients:**
- Triple Hyaluronic Acid System: ~16.65ppm total
  - Sodium Hyaluronate: 15ppm (high MW - surface)
  - Hydrolyzed HA: 1.5ppm (low MW - penetrates)
  - Sodium Acetylated HA: 0.15ppm (modified)
- Niacinamide: 2.0% (therapeutic barrier repair)
- Adenosine: 450ppm (0.045%)
- Allantoin: 500ppm
- Beta-Glucan: 0.5ppm
- Sea Water: 0.05% (marine minerals)
- Glycerin: 5.0%
- Mineral Oil: 7.0%

**Target Audience:**
- Ages 25-45
- "Everything evaporates" hydration seekers
- Oily-but-dehydrated paradox
- Retinol/active users needing buffer
- Glass skin seekers
- Sensitive/reactive skin

**Positioning:**
"Hydration That LASTS" - because niacinamide repairs the barrier that holds moisture in

**Google Product Category:**
Health & Beauty > Personal Care > Cosmetics > Skin Care > Facial Moisturizers

---

### 4. Triple Collagen Firming Foam

**Identifiers:**
- GTIN: 850064676365
- SKU: triple-collagen-foam
- Handle: triple-collagen-firming-foam

**Pricing & Size:**
- Price: $14.99 USD
- Size: 4.05 oz (120ml)

**GMC Title (max 150 chars):**
DISURI Beauty Triple Collagen Firming Foam Cleanser - Korean Anti-Aging Face Wash with 3,000ppm Collagen - 4.05 oz

**Short Description:**
Luxurious Korean foam cleanser with 3,000ppm Triple Collagen Complex. Cleanses while supporting the appearance of firmer, smoother skin. Rich cushiony foam, never strips.

**Key Ingredients:**
- Triple Collagen Complex: 3,000ppm total
  - Hydrolyzed Collagen: 1,000ppm
  - Soluble Collagen: 1,000ppm
  - Collagen Extract: 1,000ppm
- Glycerin: 5-10%
- Panthenol (Pro-Vitamin B5): 0.5-1%
- Allantoin: 0.1-0.5%
- 8 Korean Botanicals: Green Tea, Lotus, Rose, Jasmine, Iris, Edelweiss, Tiger Lily, Freesia

**Target Audience:**
- Ages 28-45
- Urban professionals
- Early aging signs, pollution exposure
- Daily makeup wearers

**Google Product Category:**
Health & Beauty > Personal Care > Cosmetics > Skin Care > Facial Cleansers

---

### 5. Triple Collagen Firming Toner

**Identifiers:**
- GTIN: 850064676327
- SKU: triple-collagen-toner
- Handle: triple-collagen-firming-toner

**Pricing & Size:**
- Price: $27.99 USD
- Size: 8.45 fl oz (250ml)

**GMC Title (max 150 chars):**
DISURI Beauty Triple Collagen Firming Toner - Korean Face Prep with 3,500ppm Collagen + 10,000ppm Hyaluronic Acid - 8.45 oz

**Short Description:**
Korean firming toner with 3,500ppm Triple Collagen + 10,000ppm Sodium Hyaluronate. Preps skin for better absorption while helping improve firmness appearance. Alcohol-free, pH-balanced.

**Key Ingredients:**
- Triple Collagen Complex: 3,500ppm
- Sodium Hyaluronate: 10,000ppm (rare high concentration)
- Bamboo Extract
- Watermelon Extract
- Adenosine

**Features:**
- Alcohol-Free
- Paraben-Free
- Sulfate-Free
- Phthalate-Free
- Model: CFT-01

**Target Audience:**
- Ages 25-55
- Urban skin (pollution, AC, dehydration)
- Bilingual/bicultural professionals

**Google Product Category:**
Health & Beauty > Personal Care > Cosmetics > Skin Care > Toners & Astringents

---

### 6. Triple Collagen Firming Eye Cream

**Identifiers:**
- GTIN: 850064676341
- ASIN: B0DJ1SC3TW
- SKU: triple-collagen-eye-cream
- Handle: triple-collagen-firming-eye-cream

**Pricing & Size:**
- Price: $33.99 USD
- Size: 1.76 oz (50g)

**GMC Title (max 150 chars):**
DISURI Beauty Triple Collagen Firming Eye Cream - Korean Under-Eye Treatment with 0.35% Collagen Complex - 1.76 oz

**Short Description:**
Korean under-eye treatment with 0.35% Triple Collagen Complex. Targets fine lines, crow's feet, and dryness. Rich formula with 7% Mineral Oil + 4% Glycerin for lasting moisture.

**Key Ingredients:**
- Triple Collagen Complex: 0.35% (3,500ppm)
  - Soluble Collagen: 0.20% (2,000ppm)
  - Hydrolyzed Collagen: 0.10% (1,000ppm)
  - Collagen Extract: 0.05% (500ppm)
- Deep Moisture Complex: 21% total
  - Mineral Oil: 7%
  - Butylene Glycol: 5%
  - Glycerin: 4%
  - Cetyl Ethylhexanoate: 3%
  - Hydrogenated Polydecene: 2%
- Adenosine: 0.04%
- Allantoin: 0.05%
- 7 Korean Botanicals: 0.50% total
- Fragrance: 0.30%
- Yellow 5: 0.023%

**Target Audience:**
- Ages 25-45 (primary), 45-65 (secondary)
- Dry under-eye skin
- Fine lines, crow's feet, concealer creasing
- Prefers rich textures

**Google Product Category:**
Health & Beauty > Personal Care > Cosmetics > Skin Care > Eye Treatments & Masks

---

### 7. Triple Collagen Firming Essence

**Identifiers:**
- GTIN: 850066107188
- SKU: triple-collagen-essence
- Handle: triple-collagen-firming-essence

**Pricing & Size:**
- Price: $19.99 USD
- Size: 5.07 oz (150ml)

**GMC Title (max 150 chars):**
DISURI Beauty Triple Collagen Hydrating Essence - Korean Face Treatment with 85% Water Base + 0.35% Collagen - 5.07 oz

**Short Description:**
Authentic Korean essence with 85.83% water base + 5% glycerin + 0.35% Triple Collagen Complex. Lightweight formula absorbs in seconds, preps skin for better product absorption.

**Key Ingredients:**
- Water: 85.83%
- Glycerin: 5.00%
- Dipropylene Glycol: 3.00%
- Methylpropanediol: 3.00%
- Triple Collagen Complex: 0.35%
  - Soluble Collagen: 0.20%
  - Hydrolyzed Collagen: 0.10%
  - Collagen Extract: 0.05%
- Korean Botanicals: 0.50% (7 extracts)
- Betaine: 0.50%
- Adenosine: 0.04%
- Allantoin: 0.10%
- Fragrance: 0.08%
- Yellow 5: 0.15%

**Target Audience:**
- Ages 25-55
- All skin types (especially dehydrated, oily, combination)
- K-beauty beginners and routine optimizers
- Glass skin seekers

**Positioning:**
"The 85% Hydration Boost Your Skin Craves"

**Google Product Category:**
Health & Beauty > Personal Care > Cosmetics > Skin Care > Facial Serums & Treatments

---

## Bundle Products (3 SKUs)

### 8. The Anti-Aging Power Duo

**Identifiers:**
- GTIN: None (identifier_exists: no)
- SKU: anti-aging-duo-bundle
- Handle: anti-aging-power-duo

**Pricing:**
- Price: $76.48 USD
- Individual Total: $89.98
- Savings: 15%

**Contents:**
1. Triple Collagen Firming Cream ($44.99)
2. Triple Collagen Firming Eye Cream ($33.99)
   - Eye cream price adjusted to $31.49 for bundle

**GMC Title:**
DISURI Beauty Anti-Aging Power Duo - Korean Triple Collagen Face + Eye Cream Bundle - Save 15%

**Short Description:**
Complete Korean anti-aging duo with Triple Collagen Firming Cream + Eye Cream. Target face and under-eye aging signs together. Save 15% vs buying separately.

**Google Product Category:**
Health & Beauty > Personal Care > Cosmetics > Skin Care > Skin Care Sets

---

### 9. The Barrier Rescue System

**Identifiers:**
- GTIN: None (identifier_exists: no)
- SKU: barrier-rescue-bundle
- Handle: barrier-rescue-system

**Pricing:**
- Price: $67.48 USD
- Individual Total: $79.98
- Savings: 15.6%

**Contents:**
1. Ultimate Snail Mucin Cream ($34.99)
2. Triple Collagen Firming Eye Cream ($33.99)
   - Eye cream price adjusted to $32.49 for bundle

**GMC Title:**
DISURI Beauty Barrier Rescue System - Korean Snail Mucin + Eye Cream Bundle - Save 15%

**Short Description:**
Korean barrier repair duo with Ultimate Snail Mucin Cream + Triple Collagen Eye Cream. Repair face and under-eye barrier together. Save 15% vs buying separately.

**Google Product Category:**
Health & Beauty > Personal Care > Cosmetics > Skin Care > Skin Care Sets

---

### 10. The Complete DISURI System

**Identifiers:**
- GTIN: None (identifier_exists: no)
- SKU: complete-system-bundle
- Handle: complete-disuri-system

**Pricing:**
- Price: $101.97 USD
- Subscribe & Save: $79.99 (33% savings)
- Individual Total: ~$119.96
- Savings: 15%

**Contents:**
1. Ultimate Snail Mucin Cream ($34.99)
2. Triple Collagen Firming Cream ($44.99)
3. Hyaluronic Acid Intense Hydration Cream ($39.99)
   - Bundle prices adjusted proportionally

**GMC Title:**
DISURI Beauty Complete System - Korean Skincare Set with Snail Mucin + Collagen + HA Creams - Save 15%

**Short Description:**
Complete Korean skincare ritual with all three hero creams: Snail Mucin (barrier), Triple Collagen (firming), and Hyaluronic Acid (hydration). Save 15% or 33% with subscription.

**Google Product Category:**
Health & Beauty > Personal Care > Cosmetics > Skin Care > Skin Care Sets

---

## Common Product Attributes

**Brand:** DISURI Beauty
**Manufacturer:** GK Cosmetic Co., Ltd.
**Country of Origin:** Republic of Korea (Made in Korea)
**Condition:** new
**Availability:** in_stock
**Age Group:** adult
**Gender:** unisex

**Certifications:**
- Made in Korea (ISO 22716:2007 GMP certified facilities)
- Cruelty-Free (Leaping Bunny pending)
- Paraben-Free
- Sulfate-Free
- Phthalate-Free
- Dermatologist Tested (select products)

**Shipping:**
- Free shipping over $50
- Ships to: US, Canada, Dominican Republic
- 30-day money-back guarantee

**Shopify Store:**
- Domain: disuribeauty.com
- CDN: disuribeauty.com/cdn/shop/files/
- Currency: USD (primary), CAD, DOP
