# DISURI Beauty Brand Guidelines

## Brand Identity

**Tagline:** "Glow Like You Own The City"

**Positioning:** Korean barrier-science skincare as urban performance equipment. Accessible luxury with cultural soul.

**Core Message:** Multi-benefit clinical actives + authentic K-beauty formulation expertise + bilingual community-driven movement.

## Visual Identity

**Primary Colors:**
- Power Crimson: #B82024
- Midnight Blue: #1f3f5c
- Molten Copper: #bf6738
- Soft Porcelain: #f4f2ee
- Deep Charcoal: #2a2a2a

**Typography:**
- Headlines: Bodoni Book
- Subheads: Mrs Eaves
- Body: Frutiger

**Logo:** Primary silhouette with red accent bar
- Minimum size: 120px digital / 1" print

**Mood:** Urban luxury, NYC energy (NOT spa vibes), premium but accessible, bilingual-ready

## Target Audience

**Primary:** Urban professional women, ages 25-38
- $60K-$150K income
- Bilingual/bicultural (English/Spanish)
- NYC, LA, Miami, Chicago, Houston, Mexico City, Bogotá, Medellín, São Paulo
- Skincare-as-investment mindset
- Research-driven (reads ingredients/studies)

**Key Personas:**
- Chen: Surgeon (Evidence-Driven)
- Johnson: Evidence-Driven
- Patel: Innovation-Seeker
- Williams: Patient-Centered
- Torres: Detail-Focused
- Reynolds: Efficiency-Focused

**Skin Concerns:**
- Barrier damage from urban stressors
- Hyperpigmentation/uneven tone
- Fine lines/loss of firmness
- Dehydration/dullness

## Voice & Tone

**Characteristics:**
- Empowering, not preachy
- Science-backed, not clinical
- Culturally fluent, not performative
- No-nonsense, confident
- Warm but direct

**Language Rules:**
- Use "helps improve appearance of" not "treats" or "cures"
- Use "supports" not "repairs" (when possible)
- Disclose ingredient concentrations when differentiating
- Always include "Made in Korea"
- Bilingual content encouraged (English/Spanish)

## Regulatory Compliance

### FDA Cosmetic Rules

**Approved Claim Language:**
✅ "Helps improve the appearance of..."
✅ "Supports smoother, younger-looking skin"
✅ "Helps reduce the appearance of fine lines"
✅ "Visible improvement with continued use"
✅ "Dermatologist tested"
✅ "Non-comedogenic"

**Prohibited Language:**
❌ "Treats," "Cures," "Heals"
❌ "Repairs damaged skin/barrier" (medical claim)
❌ "FDA-approved" (cosmetics aren't FDA-approved)
❌ "Eliminates wrinkles"
❌ "Anti-aging" without "appearance of"
❌ "Clinically proven" (without study citation)

### Ingredient Claims

**Adenosine:** Korean FDA (MFDS) approved for wrinkle improvement
- Can say: "Adenosine (Korean FDA-approved functional ingredient)"
- Cannot say: "US FDA-approved"

**Snail Mucin:** User perception studies
- Can say: "94% saw visible improvement" (if study exists)
- Cannot say: "Clinically proven to repair barrier"

**Niacinamide:** Well-documented in literature
- Can say: "2% niacinamide helps support barrier function"
- Cannot say: "Repairs damaged barrier"

**Collagen:** Topical conditioning agent
- Can say: "Triple Collagen Complex helps improve firmness appearance"
- Cannot say: "Rebuilds collagen" or "Restores collagen levels"

### Required Disclaimers

**General:**
"For external use only. Avoid direct contact with eyes. If irritation occurs, discontinue use and consult a physician. Results may vary."

**FDA Standard:**
"These statements have not been evaluated by the Food and Drug Administration. This product is not intended to diagnose, treat, cure, or prevent any disease."

**Fragrance/Colorant Disclosure:**
Products containing fragrance or colorants must disclose in product description.

## GMC-Specific Guidelines

### Title Best Practices

**Format:** [Brand] [Product Name] - [Key Benefit/Ingredient] - [Size]

**Character Limit:** 150 characters max

**Include:**
- Brand name (DISURI Beauty)
- Product category
- Key differentiating ingredient with concentration
- Size
- "Made in Korea" if space allows

**Example:**
"DISURI Beauty Triple Collagen Firming Cream - Korean Anti-Aging Face Moisturizer with 3,500ppm Collagen + Adenosine - 1.76 oz"

### Description Best Practices

**Character Limit:** 5,000 characters max

**Structure:**
1. Opening hook with key benefit
2. Key ingredients with concentrations
3. Target skin concerns
4. How to use (brief)
5. Made in Korea quality statement

**Avoid:**
- ALL CAPS
- Excessive punctuation (!!!)
- Promotional language ("Best ever!", "Amazing!")
- Price in description
- HTML tags

### Product Category

**Primary:** Health & Beauty > Personal Care > Cosmetics > Skin Care

**Sub-categories by product type:**
- Creams → Facial Moisturizers or Anti-Aging Skin Care Products
- Cleansers → Facial Cleansers
- Toners → Toners & Astringents
- Eye Creams → Eye Treatments & Masks
- Essences → Facial Serums & Treatments
- Bundles → Skin Care Sets

### Image Requirements

**Main Image:**
- White background
- Product fills 75-90% of frame
- High resolution (minimum 800x800, recommended 2000x2000)
- No text, logos, or watermarks on main image

**Additional Images:**
- Lifestyle/usage images allowed
- Ingredient callouts
- Before/after (with disclaimers)
- Texture shots

## Shopify Integration

**Base URL:** https://disuribeauty.com
**CDN:** https://disuribeauty.com/cdn/shop/files/
**Product URL Pattern:** https://disuribeauty.com/products/[handle]

**Handle Conventions:**
- Lowercase
- Hyphens between words
- No special characters
- Match product name

**Examples:**
- ultimate-snail-mucin-cream
- triple-collagen-firming-cream
- hyaluronic-acid-intense-hydration-cream
