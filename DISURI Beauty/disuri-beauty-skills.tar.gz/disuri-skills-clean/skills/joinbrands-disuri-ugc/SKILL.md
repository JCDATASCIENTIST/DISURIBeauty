---
name: joinbrands-disuri-ugc
description: "Generate complete JoinBrands.com UGC campaign briefs for DISURI Beauty products. Use when the user asks to create UGC content for DISURI Beauty on JoinBrands.com, create creator briefs, generate scripts for DISURI products, or set up UGC campaigns. Takes product name, target audience, and messaging angle as input. Outputs ready-to-paste campaign brief including: product description, key talking points, viral hook, 3 UGC scripts with storyboards, brand guidelines, and reference links. Automatically integrates DISURI brand voice, FDA-compliant claims, and calls the senior-ugc-strategist skill. Triggers on: 'JoinBrands campaign', 'DISURI UGC', 'create campaign for [DISURI product]', 'JoinBrands brief', or similar requests for DISURI Beauty UGC content."
---

# JoinBrands DISURI UGC Campaign Generator

Generate complete, ready-to-paste JoinBrands.com campaign briefs for DISURI Beauty products including viral hooks, multiple UGC scripts, storyboards, brand guidelines, and reference links.

## When to Use

Use this skill when the user requests:
- JoinBrands campaign for any DISURI Beauty product
- UGC creator briefs for DISURI products
- Scripts and storyboards for DISURI Beauty
- Complete campaign setup for JoinBrands.com

## Required Information

Ask the user for:
1. **Product name** (e.g., "Ultimate Snail Mucin Cream", "Triple Collagen Firming Cream")
2. **Target audience** (e.g., "busy professionals with dry skin", "urban women 25-35 with barrier damage")
3. **Key messaging angle** (e.g., "emphasize hydration that lasts", "focus on barrier repair", "highlight K-beauty formulation")

Optional:
- Campaign objective (Content Only vs. Content + Posting) - Default: Content Only
- Content type (TikTok, Instagram, YouTube Shorts) - Default: TikTok + Instagram
- Video length preference - Default: 30-60s

## Workflow

### Step 1: Load Product Information
Read `references/disuri_products.md` to get:
- Product key ingredients
- Benefits and target concerns
- FDA-compliant claim language
- Specific concentrations (ppm/percentages)

### Step 2: Load Brand Guidelines
The DISURI brand voice is defined in the existing `disuri-social-media` skill at `/mnt/skills/user/disuri-social-media/references/brand_voice.md`. Key points:
- Tagline: "Glow Like You Own The City"
- Voice: Empowering, science-backed, culturally fluent, no-nonsense, warm but direct
- Compliance: Use "helps improve appearance of", avoid "treats/cures/heals"
- Mood: Urban luxury, NYC energy, confident (NOT spa vibes)

### Step 3: Generate Viral Hook
Consult `references/viral_hooks.md` for hook formulas. Create ONE specific hook based on:
- Product benefit
- Target audience pain point
- DISURI brand positioning (barrier science, K-beauty authority, or urban performance)

Hook must be:
- 3-10 words maximum
- Platform-native (TikTok/Instagram style)
- Specific to the product and angle
- Pattern interrupt that stops the scroll

### Step 4: Generate 3 UGC Scripts with Storyboards

**Call the senior-ugc-strategist skill** three times to generate 3 different script approaches:

For each script iteration, provide:
- Brand: DISURI Beauty
- Product: [User-specified product]
- Industry: Consumer goods (K-beauty skincare)
- Target Persona: [User-specified audience]
- Platform: [User preference or default to TikTok]
- Objective: Conversion
- Video Length: 30-60s
- Compliance Notes: FDA cosmetic compliance - use "helps improve appearance of", avoid "treats/cures/heals", must include "Made in Korea"

**Three script variations should differ by approach:**
1. **Script 1**: Before/after transformation angle (personal story)
2. **Script 2**: Ingredient education angle (science-backed authority)
3. **Script 3**: Urban lifestyle/routine integration angle (relatable use case)

Each script from senior-ugc-strategist will include:
- Creative brief
- Full script with beat markers
- Storyboard in table format + creator-friendly format

### Step 5: Generate Reference Links

Consult `references/viral_hooks.md` for reference link guidance. Provide 3-5 suggested search terms for the user to find reference videos:

Example format:
```
Reference Video Suggestions (find on TikTok/Instagram):
1. Search: "snail mucin before after TikTok" - for transformation style
2. Search: "Korean skincare barrier repair" - for routine integration
3. Search: "K-beauty ingredient breakdown" - for educational approach
```

### Step 6: Format JoinBrands Campaign Brief

Structure the complete brief in this order:

```
=== JOINBRANDS CAMPAIGN BRIEF ===

CAMPAIGN SETTINGS:
- Business Type: Other (Beauty Brand)
- Campaign Objective: [Content Only or Content + Posting based on user preference]
- Content Type: [TikTok/Instagram Reels/YouTube Shorts based on user preference]
- Package: [Suggest appropriate tier based on scope]

---

PRODUCT DESCRIPTION:
[2-3 sentence overview including product name, key ingredients with concentrations, main benefit, Made in Korea]

---

KEY TALKING POINTS:
• [Benefit 1 with specific ingredient/concentration]
• [Benefit 2 with claim-safe language]
• [Benefit 3 with barrier science or K-beauty angle]
• [Target concern addressed]

---

VIRAL HOOK CONCEPT:
"[Single hook for creators to adapt]"

---

SCRIPT 1: [Before/After Transformation Angle]
[Full creative brief from senior-ugc-strategist]
[Full script with beats]
[Storyboard in creator-friendly format]

---

SCRIPT 2: [Ingredient Education Angle]
[Full creative brief from senior-ugc-strategist]
[Full script with beats]
[Storyboard in creator-friendly format]

---

SCRIPT 3: [Urban Lifestyle/Routine Angle]
[Full creative brief from senior-ugc-strategist]
[Full script with beats]
[Storyboard in creator-friendly format]

---

BRAND VOICE & COMPLIANCE:
Voice: Empowering, science-backed, no-nonsense. Urban luxury energy (NOT spa vibes).
Must Include: "Made in Korea"
Must Use: "Helps improve appearance of", "supports", "helps reduce appearance of"
Must Avoid: "Treats", "cures", "heals", "repairs damaged skin" (medical claims)
Tagline: "Glow Like You Own The City"

---

REFERENCE VIDEOS:
Find inspiration from these searches on TikTok/Instagram:
1. [Search term 1] - [Style guidance]
2. [Search term 2] - [Style guidance]
3. [Search term 3] - [Style guidance]

=== END CAMPAIGN BRIEF ===
```

### Step 7: Provide Usage Instructions

After generating the brief, tell the user:

"**Ready to paste into JoinBrands.com!**

**How to use:**
1. Copy everything between === JOINBRANDS CAMPAIGN BRIEF === markers
2. Paste into the 'Content Brief' field (10,000 character limit)
3. Optional: Add specific creator requirements in 'Special Requirements' field
4. Optional: Add reference video URLs once you find them using the search suggestions
5. Set your campaign name and launch!

**Need adjustments?** Let me know if you want to:
- Change the hook angle
- Emphasize different benefits
- Adjust script lengths
- Add special creator requirements"

## Best Practices

- **Always use FDA-compliant language** from the product catalog
- **Include specific concentrations** (e.g., "92% snail mucin", "10,000ppm HA")
- **Maintain DISURI brand voice** (urban energy, not spa vibes)
- **Keep hooks specific** (not generic skincare hooks)
- **Allow creator freedom** in the scripts (beats, not word-for-word)
- **Emphasize barrier science** when relevant (core DISURI positioning)

## Files Structure

- `SKILL.md` - This file, main workflow
- `references/disuri_products.md` - Complete product catalog with ingredients and claims
- `references/joinbrands_specs.md` - JoinBrands platform requirements and best practices
- `references/viral_hooks.md` - Hook formulas and reference link guidance
