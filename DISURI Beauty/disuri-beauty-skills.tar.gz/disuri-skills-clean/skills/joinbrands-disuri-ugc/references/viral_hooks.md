# Viral Skincare UGC Hooks & References

## Proven Hook Formulas for Skincare UGC

### 1. Before/After Transformation
- "POV: You finally found the [product] that works"
- "2 weeks ago vs. today 😳"
- "The glow-up nobody asked about but everyone noticed"
- "My skin before vs. after [X ingredient]"

### 2. Pain Point Recognition
- "If your skin feels dry by 10am, watch this"
- "Why does everything you put on your face evaporate?"
- "Your moisturizer isn't the problem..."
- "When your barrier is screaming for help"

### 3. Ingredient Education
- "Korean skincare ingredient you've never heard of"
- "92% of WHAT?! Let me explain..."
- "Snail mucin sounds gross but here's why it works"
- "The science behind why this actually works"

### 4. K-Beauty Authority
- "The Korean difference your skin will feel"
- "Why Korean skincare does hydration differently"
- "Made in Korea. There's a reason."
- "Korean formulators been knew 👀"

### 5. Urban Lifestyle Relatability
- "City skin is different. Here's why."
- "Your commute vs. your skin barrier"
- "7am meeting to 11pm drinks. Your skin needs this."
- "Pollution-proof your skincare routine"

### 6. Myth-Busting
- "Everything you heard about [ingredient] is wrong"
- "Collagen in skincare doesn't work? Let me explain."
- "Your dermatologist didn't tell you this about..."
- "Why you've been doing [routine step] wrong"

### 7. Social Proof
- "I didn't believe the reviews until..."
- "My skin therapist told me to buy this immediately"
- "Why everyone on K-beauty TikTok is obsessed"
- "The product I gatekept for 3 months"

### 8. Problem-Agitate-Solution
- "Do you wake up with dry skin even after moisturizing?"
- "Your skin barrier is broken. Here's how to know."
- "Stop wasting money on products that evaporate"
- "If serums don't absorb, your barrier is the issue"

---

## Reference Video Categories

### Excellent Skincare UGC Examples

**Ingredient Education Style:**
- Search: "snail mucin explained" + "skincare ingredient breakdown"
- Tone: Educational, authoritative, science-backed
- Length: 30-60s
- Example creators: @skincarebyhyram, @labmuffinbeautyscience

**Before/After Testimonials:**
- Search: "skincare transformation 2 weeks" + "K-beauty results"
- Tone: Personal, authentic, surprised/delighted
- Length: 15-30s
- Example creators: @glowwithava, @skinbyellie

**Routine/How-To:**
- Search: "Korean skincare routine" + "barrier repair routine"
- Tone: Tutorial, step-by-step, relatable
- Length: 30-60s
- Example creators: @koreanbeauty, @skincarebysami

**Urban Lifestyle Angle:**
- Search: "skincare for city life" + "pollution skincare"
- Tone: Relatable, empowering, problem-solving
- Length: 15-30s
- Example: Morning/evening routine for busy professionals

**Product Unboxing/First Impressions:**
- Search: "Korean skincare unboxing" + "trying new K-beauty"
- Tone: Excited, genuine, first reaction
- Length: 30-45s
- Shows: Packaging, texture, first application

---

## Platform-Specific Viral Patterns

### TikTok
**Current Trends (Evergreen Patterns):**
- POV format + relatable scenario
- "Hear me out" + unconventional tip
- Stitch/duet with skincare myths
- "Get ready with me" showing routine
- "Day in the life" featuring product

**Successful Formats:**
- Fast cuts showing application
- Text overlay with minimal voiceover
- Trending audio with skincare message
- Split screen before/after
- Close-up texture shots

### Instagram Reels
**Top Performers:**
- Carousel-style routine breakdown
- Hook + 3-step process
- Close-up application demo
- Morning vs. night comparison
- "What's in my skincare fridge"

**Visual Style:**
- Cleaner aesthetic than TikTok
- Natural lighting preferred
- Organized/curated appearance
- Emphasis on packaging aesthetics

### YouTube Shorts
**Best Approaches:**
- Longer educational hooks (3-5s)
- More detailed explanations
- "Part of larger video" teasers
- In-depth ingredient breakdown
- Comparison tests

---

## Reference Link Examples (Update These for Actual Campaigns)

### Recommended Search Terms for Reference Gathering:
1. "Korean snail mucin review TikTok"
2. "barrier repair skincare routine YouTube"
3. "best K-beauty products Instagram"
4. "before after snail cream TikTok"
5. "Korean skincare haul unboxing"

### How to Find Good References:
1. Search the above terms
2. Filter by views (100K+ for TikTok/Reels)
3. Look for authentic, non-sponsored feel
4. Check creator engagement rate
5. Select 3-5 videos with style you want to emulate

### Reference Link Template for Brief:
```
Reference Videos (inspiration for style and tone):
1. [Link] - Example of ingredient education approach
2. [Link] - Example of before/after testimonial style
3. [Link] - Example of routine integration
4. [Link] - Example of urban lifestyle angle
5. [Link] - Example of visual style and pacing
```

---

## DISURI-Specific Hook Angles

### Barrier Science Focus:
- "Your barrier is why your products don't work"
- "Barrier damage = everything evaporates by noon"
- "Fix your barrier, fix everything else"

### K-Beauty Formulation Authority:
- "92% snail mucin. Korean formulators don't mess around."
- "10,000ppm HA. We tell you exactly what's in it."
- "3,500ppm collagen. Made in Korea for a reason."

### Urban Performance Positioning:
- "City life is brutal on skin. Your skincare should match."
- "From 7am subway to 11pm drinks. Your barrier needs backup."
- "Pollution-proof your glow."

### Ingredient Transparency:
- "We don't hide behind proprietary blends"
- "92%, 10,000ppm, 3,500ppm. Numbers matter."
- "Korean science meets urban performance"
