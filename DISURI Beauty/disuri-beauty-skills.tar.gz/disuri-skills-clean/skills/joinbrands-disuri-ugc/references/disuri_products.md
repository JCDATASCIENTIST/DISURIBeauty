# DISURI Beauty Product Catalog

## Ultimate Snail Mucin Cream (50ml)

**Key Ingredients:**
- 92% Snail Secretion Filtrate
- 0.04% Adenosine (Korean FDA-approved functional ingredient)
- 2% Niacinamide

**Benefits:**
- Helps improve the appearance of fine lines and wrinkles
- Supports barrier function and hydration retention
- Helps reduce the appearance of redness and irritation
- Supports smoother, more even-looking skin texture

**Target Concerns:**
- Barrier damage
- Dehydration
- Fine lines
- Uneven texture
- Urban environmental stress

**Claim-Safe Language:**
- "92% snail secretion filtrate helps support barrier function"
- "Adenosine (Korean FDA-approved functional ingredient) helps improve the appearance of wrinkles"
- "2% niacinamide helps support barrier function"

---

## Triple Collagen Firming Cream (50ml)

**Key Ingredients:**
- Triple Collagen Complex (3,500ppm total)
  - Hydrolyzed Collagen
  - Collagen Extract
  - Soluble Collagen
- 0.04% Adenosine
- 2% Niacinamide

**Benefits:**
- Helps improve the appearance of firmness
- Supports skin elasticity appearance
- Helps reduce the appearance of fine lines
- Supports barrier function

**Target Concerns:**
- Loss of firmness
- Fine lines
- Elasticity concerns
- Barrier damage

**Claim-Safe Language:**
- "Triple Collagen Complex (3 molecular weights) helps improve firmness appearance"
- "3,500ppm total collagen complex"
- "Adenosine helps improve the appearance of wrinkles"

---

## HA Intense Hydrating Cream (50ml)

**Key Ingredients:**
- 10,000ppm Hyaluronic Acid (5 molecular weights)
- 2% Niacinamide
- Ceramide Complex

**Benefits:**
- Intense hydration that lasts
- Helps support barrier function
- Plumps appearance of fine lines
- Locks in moisture

**Target Concerns:**
- Dehydration
- Barrier damage
- Fine lines from dryness
- Moisture loss throughout the day

**Claim-Safe Language:**
- "10,000ppm Hyaluronic Acid (5 molecular weights) for multi-layer hydration"
- "2% niacinamide helps support barrier function"
- "Ceramide complex helps lock in moisture"

---

## Collagen Boost Foam Cleanser (150ml)

**Key Ingredients:**
- Hydrolyzed Collagen
- Amino Acid-based surfactants
- pH-balanced formula (5.5)

**Benefits:**
- Cleanses without stripping
- Maintains barrier integrity during cleansing
- Rich, creamy lather
- Leaves skin soft, not tight

**Target Concerns:**
- Barrier damage from harsh cleansers
- Tightness after cleansing
- Loss of hydration during cleansing

**Claim-Safe Language:**
- "Hydrolyzed collagen helps maintain moisture during cleansing"
- "pH-balanced (5.5) to support barrier health"
- "Amino acid surfactants cleanse gently"

---

## Barrier Prep Toner (150ml)

**Key Ingredients:**
- 10,000ppm Hyaluronic Acid
- Centella Asiatica Extract
- pH-balanced (5.5)

**Benefits:**
- Preps skin for better product absorption
- Helps support barrier function
- Instantly refreshing hydration
- Balances skin pH after cleansing

**Target Concerns:**
- Poor product absorption
- Barrier imbalance
- Dehydration
- Post-cleanse tightness

**Claim-Safe Language:**
- "10,000ppm HA preps skin for optimal absorption"
- "Centella Asiatica helps soothe and support barrier"
- "pH-balanced (5.5) to restore skin's natural state"

---

## Radiance Eye Cream (15ml)

**Key Ingredients:**
- Caffeine
- Peptide Complex
- Hyaluronic Acid
- Adenosine

**Benefits:**
- Helps reduce the appearance of dark circles
- Supports firmness around eye area
- Helps minimize the appearance of fine lines
- Brightens eye area appearance

**Target Concerns:**
- Dark circles
- Puffiness
- Fine lines around eyes
- Tired-looking eyes

**Claim-Safe Language:**
- "Caffeine helps reduce the appearance of puffiness"
- "Peptide complex helps support firmness appearance"
- "Adenosine helps improve the appearance of fine lines"

---

## Barrier Recovery Essence (50ml)

**Key Ingredients:**
- 85% Water-based essence
- Panthenol (Vitamin B5)
- Beta-Glucan
- Madecassoside

**Benefits:**
- Rapid absorption
- Supports barrier recovery
- Calms irritated-looking skin
- Prepares skin for next steps

**Target Concerns:**
- Barrier damage
- Irritation
- Redness
- Environmental stress

**Claim-Safe Language:**
- "85% water-based for instant absorption"
- "Panthenol helps support barrier recovery"
- "Madecassoside helps calm the appearance of irritation"

---

## Common Key Messages Across All Products

**Made in Korea Quality:**
- "Formulated in Korea by experts who've studied barrier science for decades"
- "Korean formulation expertise meets urban performance skincare"

**Barrier-First Philosophy:**
- "Your barrier is the foundation. Fix the barrier, fix everything else."
- "Barrier damage = why your products don't work"

**Urban Performance Positioning:**
- "City life is hard on skin. Your skincare should be tougher."
- "Performance skincare for urban life. Not spa vibes."

**Concentration Transparency:**
- Always include specific concentrations (e.g., "92% snail mucin", "10,000ppm HA")
- "We tell you exactly what's in it. No hiding behind proprietary blends."
