# JoinBrands Platform Specifications

## Campaign Structure

### Business Type
Default: **Other** (beauty brand)

### Campaign Objectives (Select One)

1. **Content + Posting** (from $100/post)
   - Creator produces content AND publishes to their account
   - Includes content rights + organic reach
   - Best for: Brand awareness, authentic reach

2. **Content Only** (from $15)
   - Creator produces content, you own it
   - Use for: Your own channels, paid ads, website
   - Most cost-effective for owned media

3. **Social Blasts** (from $9/post, non-refundable)
   - Quick amplification through creator network
   - Lower investment, less control

4. **Lives** (from $50)
   - Live streaming content

5. **Retainer Creators** (from $100/month)
   - Ongoing relationship with select creators

### Content Types

**Video Platforms:**
- TikTok
- TikTok Shop
- Instagram Reels
- YouTube Shorts
- YouTube Videos

**Other:**
- Amazon
- Selfie/Photo content

### Package Tiers (Video Content)

Bulk pricing structure:
- **25 Videos**: $35.00 per video (12.5% discount)
- **50 Videos**: $30.00 per video (25% discount)
- **100 Videos**: $25.00 per video (37.5% discount)

## Content Brief Field

**Character Limit:** 10,000 characters

**Recommended Structure:**
1. Product Overview (100-200 chars)
2. Key Talking Points (200-300 chars)
3. Hook Concept (50-100 chars)
4. Full Scripts with Storyboards (bulk of content)
5. Brand Voice & Compliance Guidelines (200-300 chars)

**Best Practices:**
- Be specific but allow creative freedom
- Include must-haves vs. nice-to-haves
- Reference specific features/benefits clearly
- Add compliance notes at the end

## Special Requirements Field (Optional)

Examples of what to include:
- "Must show product packaging clearly"
- "Must demonstrate application"
- "Must mention [specific ingredient]"
- "Avoid medical claims"
- "Include FDA-compliant language"
- Creator demographics (age, location, niche)

## Video Description Field (Optional)

**Character Limit:** 5,000 characters

What to include:
- Caption template creators can adapt
- Hashtag recommendations
- Emojis to use
- Call-to-action language
- @mention instructions

## Video Title Field (Optional)

**Character Limit:** 100 characters

Best practices:
- Emoji use
- Hashtags
- Trending audio references
- Brand @mention

## References Field (Optional)

**Purpose:** Link to examples of content style you want

Good reference links:
- Competitor UGC videos you admire
- Your own top-performing content
- Viral skincare content in similar category
- Visual style references

**Recommended number:** 3-5 links

---

## JoinBrands Creator Expectations

### What Creators Need in a Brief:

1. **Clear product benefit** - What does it do?
2. **Target audience** - Who is this for?
3. **Key message** - One main point to communicate
4. **Visual requirements** - What must be shown?
5. **Don'ts** - What to avoid (medical claims, competitor mentions, etc.)
6. **Creative freedom zones** - Where they can personalize

### What Makes a Good JoinBrands Brief:

✅ Specific benefit, not just features
✅ Example hooks or angles
✅ Clear compliance boundaries
✅ Reference videos for style
✅ Flexible scripting (beats, not word-for-word)

❌ Too prescriptive (kills authenticity)
❌ Feature lists without benefits
❌ No compliance guidance
❌ Vague objectives
