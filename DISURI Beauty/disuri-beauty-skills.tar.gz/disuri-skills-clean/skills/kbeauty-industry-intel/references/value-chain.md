# K-Beauty Value Chain

## Table of Contents
- [Value Chain Overview](#value-chain-overview)
- [Raw Materials & Ingredients](#raw-materials--ingredients)
- [Manufacturing (OEM/ODM)](#manufacturing-oemodm)
- [Brand Owners](#brand-owners)
- [Distribution & Retail](#distribution--retail)
- [Profit Pool Distribution](#profit-pool-distribution)

---

## Value Chain Overview

```
Raw Materials → Manufacturing → Brand → Distribution → Retail → Consumer
(Ingredients)   (OEM/ODM)      (Marketing) (Logistics)  (Channels)
```

Each layer adds cost and captures margin. Well-run beauty companies can be highly profitable, but launching requires significant upfront investment in marketing, distribution, and inventory.

---

## Raw Materials & Ingredients

### Ingredient Innovation Leadership
Korea maintains a **10-12 year technology lead** in ingredient innovation, particularly in fermentation and biotechnology.

### Traditional K-Beauty Ingredients
- Snail mucin (hydration, repair)
- Bee venom (anti-inflammatory)
- Starfish extract
- Pig collagen
- Pearl extracts (brightening)
- Bee propolis (nourishing)

### K-Beauty 3.0 Biotech Ingredients
Lab-grown, bio-engineered alternatives replacing traditional extracts:
- **Exosomes** - Cell communication, regeneration
- **PDRN** - DNA repair, wound healing
- **Lab-grown ginseng** - Standardized efficacy
- **Synthetic snail mucin** - Consistent quality
- **Fermented ceramides** - Barrier repair
- **Lactobacillus boosters** - Microbiome support
- **EGF (Epidermal Growth Factor)** - Cell regeneration
- **Tranexamic acid** - Brightening
- **Dexpanthenol** - Healing

### Supplier Ecosystem
- Chemical companies supplying active ingredients (hyaluronic acid, etc.)
- Equipment suppliers (mixing vessels, filling machines, testing instruments)
- Packaging suppliers (tubes, bottles, labeling equipment)

---

## Manufacturing (OEM/ODM)

### The "Structurally Advantaged" Layer
OEM/ODM manufacturers are the backbone of K-beauty's global success—they enable rapid innovation and scale for both conglomerates and indie brands.

### Major Manufacturers

**Kolmar Korea**
- One of world's largest cosmetics OEM/ODM
- Clients include global luxury brands
- Full-service: formulation → production → packaging

**Cosmax**
- Global footprint with Korean innovation core
- Clients: Major global brands (Dior, NARS, etc.)
- Key innovations originated here (BB cream, cushion compact)

### Manufacturing Capabilities
- Private label production
- Custom formulation development
- Packaging design
- Stability and efficacy testing
- Preservative effectiveness testing
- Clinical trials (for functional cosmetics)

### Innovation Flow
Korean OEM/ODMs → Global brands adopt → Mass market penetration

Examples of Korean-originated innovations:
- BB cream
- Cushion compact
- Sheet masks
- 10-step routine products
- Essence category

---

## Brand Owners

### Legacy Conglomerates (Struggling)

**Amorepacific Group**
- Brands: Sulwhasoo, Laneige, Innisfree, Etude
- Challenge: Heavy China dependence
- Performance: Down 20-35% from 2021 peaks

**LG Household & Health Care**
- Brands: The History of Whoo, Su:m37, Belif
- Challenge: China market exposure
- Market cap: Surpassed by APR Co.

### High-Growth Disruptors (Winning)

**APR Co. (Medicube)**
- Market cap: $4.7B (surpassed LG H&H)
- Strategy: Device + skincare integration
- Achievement: #1 Amazon Prime Day 2025

**Goodai Global (Beauty of Joseon)**
- 2024 sales: ₩935 billion
- Strategy: Aggressive M&A, Western focus
- Approach: Heritage branding + modern formulation

**COSRX**
- Channel dominance: Amazon leader
- Strategy: Affordable efficacy
- Target: Western consumer accessibility

### Brand Strategy Divergence
| Factor | Legacy Conglomerates | Disruptors |
|--------|---------------------|------------|
| Geographic focus | China-heavy | US/West-first |
| Channel | Department stores, duty-free | E-commerce, DTC |
| Speed | Slow portfolio pivot | Rapid iteration |
| Tech integration | Limited | Device + skincare |

---

## Distribution & Retail

### Distribution Models

**Traditional (European style):**
- Long-term official distributor partnerships
- Slower market entry
- Stable but inflexible

**Korean Model:**
- Direct wholesale to retailers
- Own retail/e-commerce stores
- No official distributors abroad
- Faster market opportunity capture

### Major Retailers

**Olive Young (CJ)**
- South Korea's dominant beauty chain
- 2026: US physical retail entry planned
- Japan subsidiary established May 2024

**Sephora**
- Dedicated K-Beauty departments
- Premium positioning
- Education-focused retail

**UMMA**
- B2B wholesale platform
- 180+ K-beauty brands
- Serves online resellers, retailers, drugstores

### E-Commerce Platforms
- Amazon (52.5% of K-beauty sales online)
- YesStyle (cross-border specialist)
- Soko Glam (curated discovery)
- Brand DTC sites

---

## Profit Pool Distribution

### Margin Structure Example
For a product retailing at $46:

| Layer | Price Point | Margin |
|-------|-------------|--------|
| Retail price | $46 | - |
| Wholesale to retailer | $23 | 50% retail |
| Distributor/rep fee | 5-30% of wholesale | ~$1-7 |
| Brand net (pre-COGS) | ~$16 | ~35% of wholesale |

### Value Capture by Layer
- **Brand owners**: Largest share (marketing, positioning)
- **Retailers**: Large share (customer access, experience)
- **Manufacturers**: Steady margins, volume-driven
- **Distributors**: 10-20% margins
- **Ingredient suppliers**: Commodity to specialty pricing

### Strategic Implications
- Vertical integration increases margin capture
- DTC models bypass distributor/retailer layers
- Device integration (APR/Medicube model) adds high-margin hardware revenue
