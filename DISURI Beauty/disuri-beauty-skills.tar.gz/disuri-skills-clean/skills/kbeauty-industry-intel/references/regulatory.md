# K-Beauty Regulatory Framework

## Table of Contents
- [Korean Regulatory Authority (MFDS)](#korean-regulatory-authority-mfds)
- [Product Classifications](#product-classifications)
- [Ingredient Regulations](#ingredient-regulations)
- [Labeling Requirements](#labeling-requirements)
- [Export Compliance](#export-compliance)
- [Animal Testing](#animal-testing)

---

## Korean Regulatory Authority (MFDS)

### Overview
**Ministry of Food and Drug Safety (MFDS)** is the competent authority for cosmetics regulation in South Korea.

### Regulatory Framework Established
- **July 1, 2000:** Cosmetics Act enacted
- Purpose: Safety control, international trade facilitation
- Scope: Manufacturing, importing, safety evaluation

### Key Functions
- Enacts and executes cosmetic regulations
- Maintains approved ingredient list
- Registers functional cosmetics
- Conducts post-market surveillance
- Approves alternative testing methods

---

## Product Classifications

### Two-Tier System

**1. General Cosmetics**
- Subject to post-market surveillance
- Can be manufactured/imported WITHOUT pre-registration
- Examples: Cleansers, moisturizers, makeup

**2. Functional Cosmetics**
- Requires MFDS approval BEFORE manufacturing/importing
- Must obtain approval letter
- Requires clinical trials to support claims

### Functional Cosmetics Categories
Products claiming specific skin/hair improvements:
- Whitening/brightening products
- Anti-wrinkle products
- Sunscreens (UV protection)
- Hair dyes
- Epilating agents
- Acne treatment products

### Regulatory Burden Comparison
| Type | Pre-Market | Clinical Trials | Claims |
|------|------------|-----------------|--------|
| General | No registration | Not required | Limited |
| Functional | MFDS approval | Required | Specific allowed |

---

## Ingredient Regulations

### Approved Ingredients
MFDS maintains official list of approved cosmetic ingredients with:
- Permitted concentrations
- Restrictions on use
- Allergen labeling requirements

### Prohibited Ingredients
**~1,030 ingredients banned** in Korean cosmetics, including:
- Hydroquinone (above certain concentrations)
- Formaldehyde (certain uses)
- Various carcinogens, mutagens
- Reproductive toxicants

### Restricted Ingredients
Subject to concentration limits or specific use conditions:
- Preservatives (concentration caps)
- Colorants (approved list)
- UV filters (specific types/levels)
- Fragrances (allergen disclosure)

### Ingredient Innovation
Korea maintains 10-12 year technology lead in:
- Fermentation technology
- Biotech ingredients
- Novel delivery systems

---

## Labeling Requirements

### Domestic Market (Korean Language Required)

**Mandatory Label Elements:**
- Product name
- Manufacturer details
- Ingredient list (descending concentration order)
- Net weight/volume
- Usage instructions
- Expiration date
- Common allergens (clearly listed)

### Export Markets (Bilingual Acceptable)
- Korean + target country language
- Must comply with destination country regulations

### Specific Requirements

**Period After Opening (PAO):**
- Products with shelf life >30 months: PAO symbol required
- Products with shelf life <30 months: Exact expiry date required

**Allergen Disclosure:**
- Common allergens must be clearly listed
- Fragrance allergens specifically identified

---

## Export Compliance

### EU Market Requirements
- **CPNP Registration:** Required for EU market entry
- **EU Cosmetics Regulation compliance:**
  - Banned substance alignment
  - Ingredient listing in EU languages
  - Strict claims substantiation
  - PAO symbol requirements

**Strategic Advantage:** Korea has been aligning regulations with EU standards, easing export compliance.

### US FDA Requirements
- No mandatory expiration dates
- No PAO symbol requirement
- Less strict pre-market requirements
- Functional cosmetics ≈ OTC drugs (different pathway)

### Compliance Comparison
| Requirement | Korea | EU | USA |
|------------|-------|-----|-----|
| Pre-market registration | Functional only | CPNP | Varies |
| Expiration dating | Required | PAO system | Not required |
| Animal testing | Banned | Banned | Allowed |
| Claims substantiation | Required | Required | Less strict |

---

## Animal Testing

### Korean Ban
- Animal testing **banned** for cosmetics
- Applies to domestically produced AND imported products
- Imported cosmetics must comply regardless of origin country testing

### Alternative Testing
MFDS has published **29 guidelines** on alternative testing methods:
- In-vitro testing protocols
- Computational models
- Human volunteer studies
- Reconstructed tissue models

### Strategic Implications
- Aligns with EU standards
- Enables seamless EU market entry
- Marketing advantage: "Cruelty-free" claims
- Challenges for brands relying on animal testing

---

## Content & Marketing Implications

### Claim Substantiation
- All claims must be substantiated
- Functional claims require clinical data
- Avoid unsubstantiated efficacy claims
- "May help" vs. definitive statements

### Approved Claim Categories
For functional cosmetics, can claim:
- Anti-wrinkle effects
- Whitening/brightening
- UV protection (SPF ratings)
- Hair growth (specific products)

### Prohibited/Restricted Claims
- Disease treatment claims
- Medical terminology (without approval)
- Unsubstantiated superlatives
- Misleading before/after representations

### Labeling for Marketing
- Ingredient transparency expected
- "Clean" positioning requires verification
- Allergen-free claims must be accurate
- Country of origin disclosure

---

## Regulatory Trends

### Alignment Direction
Korea increasingly aligning with:
- EU regulatory standards
- International safety protocols
- Sustainable packaging requirements
- Transparency mandates

### Future Expectations
- Stricter sustainability requirements
- Enhanced ingredient traceability
- Digital compliance tools
- Cross-border regulatory harmonization
