# K-Beauty Competitive Landscape

## Table of Contents
- [Industry Structure](#industry-structure)
- [Legacy Conglomerates](#legacy-conglomerates)
- [High-Growth Disruptors](#high-growth-disruptors)
- [OEM/ODM Powerhouses](#oemodm-powerhouses)
- [Western Strategic Interest](#western-strategic-interest)
- [Competitive Dynamics](#competitive-dynamics)

---

## Industry Structure

The K-beauty competitive landscape divides into clear tiers:

1. **Legacy Conglomerates** - Established giants, China-dependent, struggling
2. **High-Growth Disruptors** - Agile, US-focused, tech-integrated
3. **OEM/ODM Manufacturers** - Structurally advantaged, supply both tiers
4. **Specialty Retailers** - Channel controllers (Olive Young, Sephora)
5. **Western Acquirers** - L'Oréal, Estée Lauder seeking Korean innovation

---

## Legacy Conglomerates

### Amorepacific Group
**Status:** Struggling | **Performance:** Down 20-35% from 2021 peaks

**Brand Portfolio:**
- Sulwhasoo (luxury, heritage)
- Laneige (hydration-focused)
- Innisfree (natural/eco)
- Etude (youth/color)
- Mamonde, Primera, IOPE

**Challenges:**
- Heavy China market dependence
- Slow pivot to Western markets
- Traditional retail channel focus
- Portfolio complexity

**Strengths:**
- Deep R&D capabilities
- Brand heritage and recognition
- Manufacturing scale

---

### LG Household & Health Care
**Status:** Struggling | **Market Cap:** Surpassed by APR Co.

**Brand Portfolio:**
- The History of Whoo (luxury hanbang)
- Su:m37 (fermentation)
- Belif (herbal)
- CNP Laboratory (derma)

**Challenges:**
- China duty-free dependence
- Premium positioning less accessible
- Slower digital transformation

**Strengths:**
- Premium brand equity
- Fermentation technology leadership
- Strong Asian luxury positioning

---

## High-Growth Disruptors

### APR Co. (Medicube)
**Status:** Winner | **Market Cap:** $4.7B (surpassed LG H&H)

**Key Metrics:**
- #1 Amazon Prime Day 2025
- Device + skincare integration model
- Rapid US market penetration

**Strategy:**
- AGE-R device line (LED, microcurrent)
- Skincare formulated for device synergy
- DTC + Amazon channel focus
- Mature consumer efficacy positioning

**Why They're Winning:**
- Tech integration creates switching costs
- Higher margins on devices
- Appeals to efficacy-seeking demographics

---

### Goodai Global (Beauty of Joseon)
**Status:** Winner | **2024 Sales:** ₩935 billion

**Strategy:**
- Heritage branding (Joseon dynasty aesthetic)
- Modern formulations (rice, ginseng, propolis)
- Aggressive M&A for growth
- Western market prioritization

**Key Products:**
- Glow Serum (propolis + niacinamide)
- Dynasty Cream
- Revive Eye Serum

**Why They're Winning:**
- Strong brand storytelling
- Accessible price points
- Instagram/TikTok viral moments

---

### COSRX
**Status:** Winner | **Channel:** Amazon dominant

**Strategy:**
- Affordable efficacy
- Simplified routines
- Ingredient-forward branding
- Western accessibility focus

**Key Products:**
- Snail Mucin Essence (cult status)
- BHA Blackhead Power Liquid
- Advanced Snail 96 Mucin

**Why They're Winning:**
- Clear ingredient communication
- Value positioning
- Strong Amazon SEO/reviews

---

## OEM/ODM Powerhouses

### Kolmar Korea
**Role:** Manufacturing backbone

**Capabilities:**
- Full-service OEM/ODM
- Formulation to packaging
- Global luxury brand clients
- Innovation development

**Strategic Position:**
- Benefits regardless of which brands win
- Enables indie brand scaling
- Exports Korean innovation globally

---

### Cosmax
**Role:** Global innovation engine

**Capabilities:**
- BB cream originator
- Cushion compact developer
- Clients include Dior, NARS
- Global manufacturing footprint

**Strategic Position:**
- Technology licensor
- Trend setter through client work
- R&D investment leader

---

## Western Strategic Interest

### L'Oréal
**2025 Activity:** Acquired Korean manufacturing division

**Strategic Intent:**
- Access Korean R&D capabilities
- Biotech ingredient pipeline
- Speed-to-market innovation

### Estée Lauder
**Historical Interest:** Multiple Korean brand acquisitions/investments

**Strategic Intent:**
- K-beauty trend capture
- Asian market positioning
- Innovation pipeline

### Implications
- Validates Korean beauty tech leadership
- Potential acquisition targets: Mid-size disruptors
- R&D talent competition intensifying

---

## Competitive Dynamics

### Winners vs. Losers Framework

| Factor | Winners | Losers |
|--------|---------|--------|
| **Geographic Focus** | US/West-first | China-dependent |
| **Channel Strategy** | E-commerce, DTC | Department stores, duty-free |
| **Speed** | Rapid iteration | Slow portfolio pivot |
| **Tech Integration** | Device + skincare | Topicals only |
| **Target Demo** | Mature + male expansion | Traditional female youth |
| **Brand Story** | Clear, viral-ready | Complex, heritage-heavy |

### Commoditization Risk (2026)
K-beauty moving from niche trend to mainstream:
- Major retailers all have K-beauty sections
- Olive Young US entry increases competition
- "K-beauty" label alone no longer differentiating
- Unique brand stories required to stand out

### Strategic Recommendations

**For Content Positioning:**
- Emphasize specific efficacy claims over "K-beauty" generics
- Highlight biotech/innovation credentials
- Target mature consumer segments (less crowded)
- Focus on device integration narratives

**For Competitive Analysis:**
- Track disruptor growth rates, not conglomerate stability
- Monitor Amazon rankings as market signal
- Watch for M&A activity (consolidation accelerating)
- Follow OEM/ODM innovation pipelines for trend signals
