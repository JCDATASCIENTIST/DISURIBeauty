# K-Beauty Market Dynamics

## Table of Contents
- [Market Size & Growth](#market-size--growth)
- [Export Performance](#export-performance)
- [Geographic Shift: China to USA](#geographic-shift-china-to-usa)
- [Regional Markets](#regional-markets)
- [Distribution Channels](#distribution-channels)

---

## Market Size & Growth

**Global K-Beauty Market:**
- 2024 value: $14.61 billion
- 2025 projected: $16.26 billion
- 2032-2033 projected: $30-38 billion
- CAGR: 11.3% (2025-2033)

**USA K-Beauty Market:**
- 2024 value: $2.4 billion
- Growth rate: 10% annually
- USA share of global online sales: 51% (up from 18% in 2022)

**Segment Growth Rates:**
- Skincare: 66% of market (dominant category)
- Cleansers: 12.7% CAGR (fastest-growing product)
- Male grooming: 14.2% CAGR (fastest-growing demographic)

---

## Export Performance

**2024 Record Performance:**
- Total exports: $10.2 billion (record high)
- YoY growth: +20.6%
- Global ranking: #2 cosmetics exporter (behind France, surpassed USA)

**Q1 2025:**
- Korea exports: $3.61 billion
- USA exports: $3.75 billion (Korea narrowly trailing)

**Key Export Markets (2024):**
| Market | Value | YoY Change |
|--------|-------|------------|
| China | $2.5B | Declining share |
| USA | $1.9B | +57% |
| Japan | Growing | Expanding |
| Southeast Asia | Growing | Rising middle class |
| Europe | Growing | Clean beauty alignment |

---

## Geographic Shift: China to USA

**The defining structural transformation of 2022-2025:**

**China Decline:**
- Share of online sales: 69% → 23%
- Drivers: C-beauty competition, regulatory friction, strategic brand pivot

**USA Ascent:**
- Share of online sales: 18% → 51%
- Now #1 market globally (overtook China in 2024)
- Drivers: Hallyu penetration, e-commerce infrastructure, social commerce

**Strategic Implications:**
- China-dependent brands struggling (Amorepacific, LG H&H down 20-35%)
- US-oriented brands thriving (APR Co., Goodai Global, COSRX)
- Physical retail entering US: Olive Young planned 2026 entry

---

## Regional Markets

### United States
- 51% of global online sales
- Primary growth engine
- Social commerce dominant (TikTok, Instagram)
- Amazon as major channel (COSRX, Medicube dominate)

### China
- Declined from #1 to secondary market
- C-beauty brands (local competition) gaining share
- Regulatory complexities increasing
- Still $2.5B market but declining strategically

### Japan
- CJ Olive Young subsidiary established May 2024
- Growing K-beauty adoption
- Strong cultural affinity

### Southeast Asia
- Rising middle class driving demand
- Hallyu influence strong
- High-growth potential market

### Europe
- Alignment with "clean beauty" standards
- Sustainability focus matches EU priorities
- Growing market penetration

---

## Distribution Channels

**Channel Mix (2024):**
- Online retail: 52.5% (dominant)
- Specialty/monobrand stores: Growing
- Supermarket/hypermarket: Convenience-driven

**Key Platforms:**
- Amazon (COSRX, Medicube dominant)
- YesStyle (cross-border e-commerce)
- Soko Glam (curated K-beauty)
- Olive Young (Korean specialty retail, entering US 2026)
- Sephora (K-Beauty department)

**Distribution Model Differences:**
- European brands: Long-term distributor partnerships
- Korean brands: Direct wholesale or own retail/e-commerce
- Flexibility enables rapid market entry

**Margin Structure:**
| Layer | Typical Margin |
|-------|---------------|
| Distributor | 10-20% |
| Retailer | ~50% of retail |
| Brand (net after COGS) | ~35% of wholesale |
