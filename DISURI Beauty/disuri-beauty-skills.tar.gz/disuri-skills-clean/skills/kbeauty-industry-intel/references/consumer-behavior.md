# K-Beauty Consumer Behavior

## Table of Contents
- [Demographic Segments](#demographic-segments)
- [The Mature Consumer](#the-mature-consumer)
- [Male Grooming Expansion](#male-grooming-expansion)
- [Gen Z Discovery Engine](#gen-z-discovery-engine)
- [Purchase Behavior & Channels](#purchase-behavior--channels)
- [Behavioral Shifts](#behavioral-shifts)

---

## Demographic Segments

### Segment Overview
| Segment | Role | Growth Rate | Value Driver |
|---------|------|-------------|--------------|
| Gen Z (18-26) | Discovery, virality | Moderate | Trend creation |
| Millennials (27-42) | Core purchasers | Strong | Volume + value |
| Mature (30-50+) | Meaningful growth | Highest value | Premium, efficacy |
| Male | Fastest growing | 14.2% CAGR | Market expansion |

### Key Insight
While Gen Z drives **discovery and virality**, the most **meaningful financial growth** comes from the 30-50+ demographic seeking efficacy over trends.

---

## The Mature Consumer

### Profile: Ages 30-50+
**Primary Growth Driver** for the K-beauty industry

### Behavioral Characteristics

**Efficacy Over Trendiness**
- Seeks proven results, not viral moments
- Values clinical evidence and ingredient science
- Willing to pay premium for performance
- Less influenced by packaging aesthetics

**Product Preferences**
- Functional cosmetics (anti-wrinkle, brightening, SPF)
- Biotech ingredients (PDRN, exosomes, peptides)
- High-concentration actives
- Professional-grade results at home

**Routine Approach**
- Skinimalism adoption (fewer, better products)
- Long-term consistency over experimentation
- Investment mindset toward skincare
- Device integration for enhanced results

### Purchase Behavior
- Higher average order value
- Lower churn rates
- Research-driven decisions
- Brand loyalty when results delivered

### Content Strategy Implications
- Lead with efficacy claims and clinical backing
- Avoid trend-chasing language
- Emphasize ingredient science
- Highlight mature skin concerns directly
- Professional/sophisticated tone

---

## Male Grooming Expansion

### Market Position
**Fastest-growing end-user segment: 14.2% CAGR**

### Drivers of Growth

**Generational Shift**
- Younger men view skincare as gender-neutral
- Stigma around male grooming disappearing
- K-pop/Hallyu influence normalizing male beauty

**Entry Products**
- Cleansers (lowest barrier)
- Moisturizers with SPF
- Under-eye treatments
- Simple multi-step routines

### Behavioral Patterns
- Preference for simple, efficient routines
- Multi-functional products popular
- Less brand loyalty (newer to category)
- Discovery through female partners, social media

### Content Strategy Implications
- Normalize without over-feminizing
- Emphasize simplicity and efficiency
- Focus on skin health, not "beauty"
- Performance and results language
- Avoid complicated routines

---

## Gen Z Discovery Engine

### Role in Ecosystem
- **Primary function:** Trend creation, virality, discovery
- **Secondary function:** Volume purchasing (lower AOV)

### Discovery Channels
- TikTok (primary)
- Instagram Reels
- YouTube Shorts
- Peer recommendations

### Behavioral Characteristics
- Trend-responsive
- Ingredient-curious
- Value-conscious
- Authenticity-seeking
- Skeptical of traditional advertising

### Content Preferences
- Short-form video
- Before/after demonstrations
- Ingredient education
- Honest reviews (flaws acknowledged)
- Creator/influencer recommendations

### Strategic Value
- Creates cultural moments
- Drives initial product awareness
- Sets trend direction
- Influences older demographics
- Lower customer lifetime value individually

---

## Purchase Behavior & Channels

### Channel Mix (2024)
- **Online/E-commerce:** 52.5% (dominant)
- **Specialty stores:** Growing
- **Supermarket/hypermarket:** Convenience segment

### Online Behavior

**Discovery → Purchase Journey:**
1. Social media discovery (TikTok, Instagram)
2. Research phase (reviews, ingredients)
3. Platform comparison (Amazon, brand DTC, specialty)
4. Purchase (often impulse after content trigger)

**Key Platforms:**
- Amazon (dominant for accessibility)
- Brand DTC sites (loyalty programs)
- YesStyle (discovery, variety)
- Soko Glam (curated, education)

### Physical Retail Behavior

**Why Physical Still Matters:**
- Product testing (texture, scent)
- Expert consultation
- Immediate gratification
- Gift purchases

**2026 Shift:** Olive Young US entry bringing Korean specialty retail experience

### Subscription Behavior
- Replenishment subscriptions growing
- Discovery boxes less popular than peak
- Brand loyalty programs effective for retention

---

## Behavioral Shifts

### From 10-Step to Skinimalism
| Old Behavior | New Behavior |
|--------------|--------------|
| 10+ products | 3-5 products |
| Product collection | Curated essentials |
| Trend following | Results focus |
| Quantity | Quality |

### From Coverage to Glow
- Heavy makeup coverage declining
- "Gwang" (healthy glow) prioritized
- Skincare results > cosmetic masking
- Natural appearance valued

### From Passive to Tech-Integrated
- Beauty devices entering daily routines
- AI skin analysis adoption growing
- Connected skincare ecosystems
- Data-driven personalization expected

### From Generic to Personalized
- One-size-fits-all declining
- Personalized recommendations expected
- Skin concern-specific solutions
- Climate/lifestyle adaptation

---

## Consumer Segments: Content Strategy Matrix

| Segment | Content Tone | Key Messages | Channels |
|---------|--------------|--------------|----------|
| **Mature (30-50+)** | Professional, scientific | Efficacy, results, innovation | Editorial, email, targeted social |
| **Male** | Straightforward, efficient | Simplicity, performance, health | YouTube, Reddit, direct messaging |
| **Gen Z** | Authentic, educational | Ingredients, trends, value | TikTok, Instagram Reels, creators |
| **Millennials** | Balanced, aspirational | Quality, sustainability, routine | Instagram, blogs, Amazon reviews |

### Universal Truths Across Segments
1. Ingredient transparency expected
2. Results must be demonstrable
3. Sustainability baseline (not differentiator)
4. Authenticity over polish
5. Value consciousness (not necessarily cheap)
