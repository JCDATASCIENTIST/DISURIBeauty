# K-Beauty Historical Milestones

## Table of Contents
- [Timeline Overview](#timeline-overview)
- [Foundational Era (2000-2010)](#foundational-era-2000-2010)
- [Global Breakout (2011-2016)](#global-breakout-2011-2016)
- [Peak Hype to Maturation (2017-2021)](#peak-hype-to-maturation-2017-2021)
- [Structural Transformation (2022-Present)](#structural-transformation-2022-present)
- [Key Disruptions Analysis](#key-disruptions-analysis)

---

## Timeline Overview

| Era | Period | Defining Characteristic |
|-----|--------|------------------------|
| Foundation | 2000-2010 | Regulatory framework, domestic innovation |
| Breakout | 2011-2016 | Global discovery, Hallyu effect |
| Peak/Maturation | 2017-2021 | China boom, consolidation |
| Transformation | 2022-Present | Geographic pivot, disruptor rise |

---

## Foundational Era (2000-2010)

### 2000: Regulatory Foundation
**July 1, 2000 - Cosmetics Act Enacted**
- Established MFDS oversight
- Created functional cosmetics category
- Enabled quality standardization
- Built foundation for export credibility

### Key Developments
- OEM/ODM manufacturing ecosystem matures
- Amorepacific and LG H&H establish dominance
- Domestic market sophistication increases
- Innovation pipeline begins (BB cream development)

### Innovation Origins
- **BB Cream** developed in Korea (originally German concept, Korean perfection)
- Sheet mask popularization begins
- Multi-step routine culture established
- Fermentation skincare pioneered

---

## Global Breakout (2011-2016)

### 2011-2012: K-Pop Catalyst
**Hallyu Wave reaches global critical mass**
- K-pop groups gain international fanbases
- Korean drama global streaming begins
- Beauty standards exported via entertainment
- "Glass skin" aesthetic goes viral

### 2014: Cushion Compact Revolution
**Amorepacific patents cushion technology**
- Disrupts foundation application globally
- Licensed to L'Oréal, Lancôme, others
- Demonstrates Korean innovation leadership
- Creates new product category

### 2015-2016: Western Retail Adoption
**Major retailers launch K-beauty sections**
- Sephora introduces K-Beauty department
- Urban Outfitters, Target add sections
- Soko Glam founded (2012), gains traction
- Sheet masks become mainstream globally

### Export Surge
- Korean cosmetics exports grow 20%+ annually
- China emerges as dominant market
- Duty-free shopping becomes major channel
- Tourism-driven sales peak

---

## Peak Hype to Maturation (2017-2021)

### 2017-2019: China Dependency Peak
**Chinese market reaches 69% of online sales**
- Daigou (personal shoppers) fuel growth
- Chinese tourist duty-free purchases surge
- Brands optimize for Chinese preferences
- Infrastructure investment in China increases

### 2020: COVID-19 Disruption
**Global beauty industry shocks**
- Duty-free/tourism channels collapse
- E-commerce acceleration
- Skincare focus increases (mask-wearing effects)
- At-home beauty device interest grows

### 2021: Peak Performance, Warning Signs
**Record valuations, but cracks emerge**
- Amorepacific, LG H&H at market cap peaks
- China regulatory tightening begins
- C-beauty brands gaining share
- US market quietly accelerating

---

## Structural Transformation (2022-Present)

### 2022: The Great Pivot Begins
**China share collapses: 69% → declining**
- C-beauty competition intensifies
- Regulatory friction increases
- Korean brands begin strategic retreat
- US emerges as growth market

**US share surges: 18% → growing**
- TikTok drives discovery
- Amazon becomes major channel
- Social commerce acceleration
- Younger US consumers adopt K-beauty

### 2024: Historic Milestones

**Record Export Performance**
- $10.2 billion exports (record high)
- +20.6% year-over-year growth
- #2 global cosmetics exporter (surpassed USA)
- Only behind France

**Market Leadership Shift**
- US overtakes China as #1 market
- US reaches 51% of global online sales
- China drops to 23%

**Corporate Disruption**
- APR Co. (Medicube) market cap surpasses LG H&H
- Goodai Global reaches ₩935 billion sales
- Legacy conglomerates down 20-35% from 2021

### 2025: Consolidation & Expansion

**Q1 2025 Export Performance**
- Korea: $3.61 billion
- Narrowly trails US ($3.75 billion)
- Maintains #2 global position

**Strategic Moves**
- L'Oréal acquires Korean manufacturing division
- Olive Young plans US physical retail entry (2026)
- CJ Olive Young establishes Japan subsidiary (May 2024)

**K-Beauty 3.0 Emergence**
- Biotech ingredients mainstream
- Device integration accelerates
- AI personalization scales

---

## Key Disruptions Analysis

### Disruption 1: Hallyu Effect (2011-2016)
**Impact:** Created global demand for Korean beauty standards
**Mechanism:** Entertainment exports → Beauty standard adoption → Product demand
**Winners:** All Korean beauty brands, OEM/ODMs
**Lasting Effect:** Permanent global awareness of Korean beauty

### Disruption 2: Cushion Compact (2014)
**Impact:** Demonstrated Korean innovation could lead global categories
**Mechanism:** Patent → Licensing → Global adoption
**Winners:** Amorepacific (patent holder), Korean innovation reputation
**Lasting Effect:** Established Korea as beauty innovation leader

### Disruption 3: China Regulatory/Competitive Shift (2021-2022)
**Impact:** Forced strategic geographic reorientation
**Mechanism:** C-beauty competition + regulatory friction → Market exit
**Winners:** US-focused brands, agile disruptors
**Losers:** China-dependent conglomerates
**Lasting Effect:** Permanent market structure change

### Disruption 4: Social Commerce Rise (2020-Present)
**Impact:** Changed discovery and purchase pathways
**Mechanism:** TikTok/Instagram → Viral moments → Direct purchase
**Winners:** Digitally-native brands (COSRX, Beauty of Joseon)
**Losers:** Traditional retail-dependent brands
**Lasting Effect:** DTC and Amazon now primary channels

### Disruption 5: Device Integration (2023-Present)
**Impact:** Creating new product category and margin structure
**Mechanism:** LED/microcurrent devices → Synergistic skincare → Ecosystem lock-in
**Winners:** APR Co. (Medicube) - market cap exceeds LG H&H
**Lasting Effect:** Redefining what "skincare brand" means

---

## Lessons for Content Strategy

### Historical Narratives to Leverage
1. **Innovation heritage:** Korea leads global beauty innovation (BB cream, cushion, biotech)
2. **Quality standards:** MFDS regulation since 2000 ensures safety
3. **Cultural authenticity:** Rooted in Korean beauty philosophy ("gwang," glass skin)
4. **Proven results:** Decades of efficacy-driven development

### Cautionary Patterns
1. **Market dependency risk:** China collapse teaches geographic diversification
2. **Trend commoditization:** K-beauty label alone no longer differentiating
3. **Legacy burden:** Large portfolios slow adaptation
4. **Channel disruption:** Must meet consumers where they discover
