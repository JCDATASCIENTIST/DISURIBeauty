---
name: kbeauty-industry-intel
description: K-beauty industry intelligence for strategic content creation and competitive analysis. Use when creating marketing content that requires K-beauty market context, answering questions about Korean skincare industry dynamics, analyzing competitive positioning, understanding value chains, or citing industry trends and data. Triggers on "K-beauty market", "Korean skincare industry", "K-beauty trends", "K-beauty competitors", industry positioning questions, or requests for market-informed content strategy.
---

# K-Beauty Industry Intelligence

Strategic market intelligence for the Korean skincare industry (2024-2026).

## Quick Reference Data

**Market Size:** $14.6B (2024) → $30-38B (2032-33) | CAGR: 11.3%
**Export Rank:** #2 globally ($10.2B in 2024, +20.6% YoY)
**Geographic Shift:** US now 51% of online sales (was 18% in 2022); China collapsed from 69% → 23%

**Winning Segments:**
- Skincare: 66% of market
- Male grooming: 14.2% CAGR (fastest demographic)
- Cleansers: 12.7% CAGR (fastest product)

**Industry Phase:** K-Beauty 3.0 (biotech era) — lab-grown ingredients, device integration, AI personalization

## Workflow

### For Market Questions
1. Identify the domain (market size, competitors, trends, regulations, consumer behavior)
2. Read the relevant reference file from `references/`
3. Cite specific data points with context

### For Content Creation
1. Identify target audience segment (mature 30-50+, male, Gen Z, millennial)
2. Read `references/consumer-behavior.md` for segment insights
3. Read `references/trends-2026.md` for current positioning hooks
4. Apply market context to content strategy

### For Competitive Analysis
1. Read `references/competitive-landscape.md` for player mapping
2. Read `references/value-chain.md` for structural positioning
3. Identify winners vs. losers framework application

## Reference Files

| File | Use When |
|------|----------|
| `references/market-dynamics.md` | Market size, CAGR, exports, geographic distribution, channels |
| `references/value-chain.md` | Suppliers, OEM/ODMs, brands, distributors, margins |
| `references/competitive-landscape.md` | Key players, conglomerates vs. disruptors, M&A |
| `references/trends-2026.md` | K-Beauty 3.0, biotech, AI, sustainability, skinimalism |
| `references/consumer-behavior.md` | Demographics, mature consumers, male grooming, purchase patterns |
| `references/regulatory.md` | MFDS, FDA, EU compliance, functional cosmetics |
| `references/historical-milestones.md` | Timeline, disruptions, innovation origins |

## Key Competitive Insight

**Winners:** US-focused, e-commerce native, device-integrated (APR/Medicube, COSRX, Beauty of Joseon)
**Losers:** China-dependent, traditional retail (Amorepacific, LG H&H down 20-35%)

## Content Strategy Principles

**For Mature Consumers (Primary Growth):**
- Lead with efficacy and clinical backing
- Emphasize biotech ingredients (PDRN, exosomes)
- Professional tone, results-focused

**For Male Segment (Fastest Growing):**
- Simplicity and efficiency
- Skin health framing (not "beauty")
- Straightforward, no-nonsense tone

**Avoid:**
- Generic "K-beauty" positioning (commoditized)
- Sustainability as differentiator (now baseline)
- Trend-chasing without efficacy substance
