# DISURI Beauty — Claude Skills Repository

Custom Claude skills built for **DISURI Beauty**, a K-beauty inspired skincare brand. These skills power marketing automation, content creation, Queen ambassador management, and brand compliance.

## Skills Inventory

| Skill | Description |
|---|---|
| `disuri-social-media` | Social media content creation across Instagram, TikTok, YouTube Shorts |
| `disuri-email-marketing` | Email flows for B2C customers and B2B Queen ambassadors (Klaviyo) |
| `disuri-gmc` | Google Merchant Center product feed generation (7 SKUs + 3 bundles) |
| `disuri-queen-onboarding` | Complete onboarding packages for new Queen ambassadors (3 tiers) |
| `joinbrands-disuri-ugc` | JoinBrands.com UGC campaign brief generator |
| `kbeauty-industry-intel` | K-beauty market intelligence for competitive positioning |
| `senior-ugc-strategist` | UGC video scriptwriting and storyboarding (used by DISURI UGC skills) |

## Brand Voice & Frameworks

| File | Description |
|---|---|
| `brand-voice/brand-voice-guidelines.md` | DISURI Brand Voice Guidelines v3 (confidence 0.97) |
| `frameworks/DISURI-Founder-Voice-Transition-Plan.md` | 3-phase founder-to-brand voice transition model |
| `frameworks/DISURI-Queen-Content-Compliance-Framework.md` | 7-question pre-publish compliance checklist |

## Installation

Copy the `skills/` directory into your Claude Code project's `.claude/skills/` folder, or install individual skills as needed.

## Products Covered

Snail Mucin Cream, Triple Collagen Cream, Hyaluronic Acid Cream, Foam Cleanser, Hydrating Toner, Eye Cream, Essence, and 3 bundles (Starter, Complete, Ultimate).
