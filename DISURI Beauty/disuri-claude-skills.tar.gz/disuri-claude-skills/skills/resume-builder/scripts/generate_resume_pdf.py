#!/usr/bin/env python3
"""
Generate ATS-optimized PDF resume using ReportLab.
"""

from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak,
    Table, TableStyle, KeepTogether
)
from reportlab.lib import colors
from typing import Dict, List
import os


class ResumeBuilder:
    """ATS-optimized PDF resume builder"""
    
    def __init__(self, output_path: str):
        self.output_path = output_path
        self.doc = SimpleDocTemplate(
            output_path,
            pagesize=letter,
            leftMargin=0.75*inch,
            rightMargin=0.75*inch,
            topMargin=0.75*inch,
            bottomMargin=0.75*inch
        )
        self.styles = self._create_styles()
        self.story = []
    
    def _create_styles(self):
        """Create custom paragraph styles for ATS compatibility"""
        styles = getSampleStyleSheet()
        
        # Name style
        styles.add(ParagraphStyle(
            name='Name',
            parent=styles['Heading1'],
            fontSize=16,
            textColor=colors.HexColor('#000000'),
            spaceAfter=6,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        ))
        
        # Contact info style
        styles.add(ParagraphStyle(
            name='Contact',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#000000'),
            spaceAfter=12,
            alignment=TA_CENTER,
            fontName='Helvetica'
        ))
        
        # Section header style
        styles.add(ParagraphStyle(
            name='SectionHeader',
            parent=styles['Heading2'],
            fontSize=12,
            textColor=colors.HexColor('#000000'),
            spaceAfter=6,
            spaceBefore=12,
            fontName='Helvetica-Bold'
        ))
        
        # Job title style
        styles.add(ParagraphStyle(
            name='JobTitle',
            parent=styles['Normal'],
            fontSize=11,
            textColor=colors.HexColor('#000000'),
            spaceAfter=3,
            fontName='Helvetica-Bold'
        ))
        
        # Company/date style
        styles.add(ParagraphStyle(
            name='CompanyDate',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#333333'),
            spaceAfter=6,
            fontName='Helvetica'
        ))
        
        # Bullet point style
        styles.add(ParagraphStyle(
            name='ResumeBullet',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#000000'),
            spaceAfter=4,
            leftIndent=20,
            bulletIndent=10,
            fontName='Helvetica'
        ))
        
        # Summary style
        styles.add(ParagraphStyle(
            name='Summary',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#000000'),
            spaceAfter=10,
            fontName='Helvetica'
        ))
        
        return styles
    
    def add_header(self, name: str, location: str, phone: str, email: str, linkedin: str):
        """Add resume header with contact information"""
        # Name
        self.story.append(Paragraph(name.upper(), self.styles['Name']))
        
        # Contact info - single line, ATS-friendly
        contact_parts = [location, phone, email]
        if linkedin:
            contact_parts.append(linkedin)
        contact_text = " | ".join(contact_parts)
        
        self.story.append(Paragraph(contact_text, self.styles['Contact']))
        self.story.append(Spacer(1, 0.1*inch))
    
    def add_summary(self, summary_text: str):
        """Add professional summary"""
        self.story.append(Paragraph("PROFESSIONAL SUMMARY", self.styles['SectionHeader']))
        self.story.append(Paragraph(summary_text, self.styles['Summary']))
    
    def add_experience_section(self, experiences: List[Dict]):
        """Add work experience section"""
        self.story.append(Paragraph("PROFESSIONAL EXPERIENCE", self.styles['SectionHeader']))
        
        for exp in experiences:
            # Job title
            self.story.append(Paragraph(exp['title'], self.styles['JobTitle']))
            
            # Company and dates
            company_date = f"{exp['company']} | {exp['location']} | {exp['dates']}"
            self.story.append(Paragraph(company_date, self.styles['CompanyDate']))
            
            # Achievements/responsibilities
            for bullet in exp['bullets']:
                bullet_text = f"• {bullet}"
                self.story.append(Paragraph(bullet_text, self.styles['ResumeBullet']))
            
            self.story.append(Spacer(1, 0.1*inch))
    
    def add_skills_section(self, skills: Dict[str, List[str]]):
        """Add skills section with categories"""
        self.story.append(Paragraph("TECHNICAL SKILLS & EXPERTISE", self.styles['SectionHeader']))
        
        for category, skill_list in skills.items():
            skills_text = f"<b>{category}:</b> {', '.join(skill_list)}"
            self.story.append(Paragraph(skills_text, self.styles['Summary']))
    
    def add_education_section(self, education: List[Dict]):
        """Add education and certifications"""
        self.story.append(Paragraph("EDUCATION & CERTIFICATIONS", self.styles['SectionHeader']))
        
        for edu in education:
            if 'degree' in edu:
                edu_text = f"<b>{edu['degree']}</b>, {edu.get('major', '')}"
                if 'institution' in edu:
                    edu_text += f" | {edu['institution']}"
                if 'year' in edu:
                    edu_text += f" | {edu['year']}"
                self.story.append(Paragraph(edu_text, self.styles['Summary']))
            elif 'certification' in edu:
                cert_text = f"<b>{edu['certification']}</b>"
                if 'issuer' in edu:
                    cert_text += f" | {edu['issuer']}"
                if 'year' in edu:
                    cert_text += f" | {edu['year']}"
                self.story.append(Paragraph(cert_text, self.styles['Summary']))
    
    def build(self):
        """Build the PDF document"""
        self.doc.build(self.story)
        return self.output_path


def generate_resume_pdf(resume_data: Dict, output_path: str) -> str:
    """
    Generate ATS-optimized PDF resume.
    
    Args:
        resume_data: Dictionary containing all resume sections
        output_path: Path where PDF should be saved
        
    Returns:
        Path to generated PDF
    """
    builder = ResumeBuilder(output_path)
    
    # Add header
    builder.add_header(
        name=resume_data['name'],
        location=resume_data['location'],
        phone=resume_data['phone'],
        email=resume_data['email'],
        linkedin=resume_data.get('linkedin', '')
    )
    
    # Add summary if provided
    if 'summary' in resume_data and resume_data['summary']:
        builder.add_summary(resume_data['summary'])
    
    # Add experience
    if 'experience' in resume_data:
        builder.add_experience_section(resume_data['experience'])
    
    # Add skills
    if 'skills' in resume_data:
        builder.add_skills_section(resume_data['skills'])
    
    # Add education
    if 'education' in resume_data:
        builder.add_education_section(resume_data['education'])
    
    # Build and return
    return builder.build()


def main():
    """Example usage"""
    sample_data = {
        'name': 'Joel Castillo',
        'location': 'Lake Worth, FL',
        'phone': '(555) 123-4567',
        'email': 'joel@example.com',
        'linkedin': 'linkedin.com/in/joelcastillo',
        'summary': 'Strategic AI Product Leader with 15 years driving commercial growth for life sciences. Architected platforms delivering $11.6M+ in managed media, $4.5M+ in pipeline.',
        'experience': [
            {
                'title': 'Senior Product Manager',
                'company': 'ZimVie',
                'location': 'Palm Beach Gardens, FL',
                'dates': 'Jan 2020 - Present',
                'bullets': [
                    'Architected ABM platform delivering 45% improvement in MQL-to-SQL conversion and $4.5M in marketing-sourced pipeline',
                    'Led GTM strategy for three pharma launches, driving 35% faster time-to-market and $12M+ first-year revenue',
                    'Reduced campaign setup time by 90% through AI-powered automation platform supporting $10M+ annual programmatic media'
                ]
            }
        ],
        'skills': {
            'Marketing Technology': ['HubSpot', 'Salesforce', '6sense', 'DV360', 'CM360'],
            'AI/ML': ['Machine Learning', 'Predictive Analytics', 'AI Product Development'],
            'Strategy': ['Product Strategy', 'ABM', 'GTM Planning', 'Demand Generation']
        },
        'education': [
            {'certification': 'Machine Learning Specialization', 'issuer': 'Stanford University'},
            {'certification': 'HubSpot Marketing Automation', 'issuer': 'HubSpot Academy'}
        ]
    }
    
    output = generate_resume_pdf(sample_data, 'Joel_Castillo_Resume.pdf')
    print(f"Resume generated: {output}")


if __name__ == "__main__":
    main()
