#!/usr/bin/env python3
"""
Match candidate skills to job requirements and suggest emphasis areas.
"""

import json
from typing import Dict, List, Set
from difflib import SequenceMatcher


def normalize_skill(skill: str) -> str:
    """Normalize skill names for better matching"""
    return skill.lower().strip().replace('-', ' ').replace('_', ' ')


def calculate_similarity(str1: str, str2: str) -> float:
    """Calculate similarity between two strings"""
    return SequenceMatcher(None, normalize_skill(str1), normalize_skill(str2)).ratio()


def match_skills(candidate_skills: Dict, job_requirements: Dict) -> Dict:
    """
    Match candidate skills to job requirements.
    
    Args:
        candidate_skills: Dictionary of candidate's skills by category
        job_requirements: Dictionary from extract_job_keywords output
        
    Returns:
        Dictionary with matched skills, gaps, and emphasis recommendations
    """
    
    # Extract all candidate skills into searchable format
    all_candidate_skills = set()
    
    if 'technical_platforms' in candidate_skills:
        all_candidate_skills.update([normalize_skill(s) for s in candidate_skills['technical_platforms']])
    if 'ai_ml' in candidate_skills:
        all_candidate_skills.update([normalize_skill(s) for s in candidate_skills['ai_ml']])
    if 'marketing_platforms' in candidate_skills:
        all_candidate_skills.update([normalize_skill(s) for s in candidate_skills['marketing_platforms']])
    if 'strategic_capabilities' in candidate_skills:
        all_candidate_skills.update([normalize_skill(s) for s in candidate_skills['strategic_capabilities']])
    
    # Get required skills from job
    required_skills = set()
    required_skills.update([normalize_skill(s) for s in job_requirements.get('tech_skills', [])])
    required_skills.update([normalize_skill(s) for s in job_requirements.get('marketing_skills', [])])
    required_skills.update([normalize_skill(s) for s in job_requirements.get('leadership_skills', [])])
    
    # Direct matches
    direct_matches = []
    for required in required_skills:
        for candidate in all_candidate_skills:
            if required in candidate or candidate in required:
                direct_matches.append({
                    'required': required,
                    'candidate': candidate,
                    'match_type': 'direct'
                })
                break
    
    # Fuzzy matches (similarity > 0.7)
    fuzzy_matches = []
    for required in required_skills:
        best_match = None
        best_similarity = 0.7
        
        for candidate in all_candidate_skills:
            similarity = calculate_similarity(required, candidate)
            if similarity > best_similarity:
                best_match = candidate
                best_similarity = similarity
        
        if best_match:
            fuzzy_matches.append({
                'required': required,
                'candidate': best_match,
                'similarity': round(best_similarity, 2),
                'match_type': 'fuzzy'
            })
    
    # All matches combined
    all_matches = direct_matches + fuzzy_matches
    matched_required_skills = {m['required'] for m in all_matches}
    
    # Skills gaps
    skill_gaps = [s for s in required_skills if s not in matched_required_skills]
    
    # Calculate match percentage
    match_percentage = 0
    if required_skills:
        match_percentage = round((len(matched_required_skills) / len(required_skills)) * 100)
    
    # Determine emphasis areas based on job focus
    emphasis_recommendations = []
    
    focus_areas = job_requirements.get('focus_areas', [])
    job_level = job_requirements.get('job_level', 'mid')
    
    # Recommendations based on focus areas
    if 'Product Management' in focus_areas:
        emphasis_recommendations.append({
            'area': 'Product Leadership',
            'reason': 'Job emphasizes product management',
            'projects_to_highlight': ['NPI Lookup Tool', 'CampaignGen AI', 'ABM Orchestration Engine'],
            'skills_to_emphasize': ['Product Strategy', 'Platform Architecture', 'Cross-functional Leadership']
        })
    
    if 'Marketing' in focus_areas or 'Growth/Revenue' in focus_areas:
        emphasis_recommendations.append({
            'area': 'Marketing & Growth',
            'reason': 'Job emphasizes marketing/revenue generation',
            'projects_to_highlight': ['ABM Orchestration Engine', 'GTM Strategy Platform', 'UTM Builder'],
            'skills_to_emphasize': ['ABM Strategy', 'Demand Generation', 'Pipeline Acceleration']
        })
    
    if 'AI/ML' in focus_areas:
        emphasis_recommendations.append({
            'area': 'AI/ML Expertise',
            'reason': 'Job emphasizes AI/ML capabilities',
            'projects_to_highlight': ['NPI Lookup Tool', 'ABM Orchestration Engine', 'CampaignGen AI'],
            'skills_to_emphasize': ['Machine Learning', 'AI Product Development', 'Predictive Analytics']
        })
    
    if 'Healthcare/Life Sciences' in focus_areas:
        emphasis_recommendations.append({
            'area': 'Life Sciences Domain',
            'reason': 'Job is in healthcare/pharma industry',
            'projects_to_highlight': ['All projects (pharma-focused)', 'NPI Lookup Tool', 'GTM Strategy Platform'],
            'skills_to_emphasize': ['Healthcare Data', 'HCP Targeting', 'Regulatory Compliance', 'Pharma GTM']
        })
    
    # Level-based recommendations
    if job_level == 'executive':
        emphasis_recommendations.append({
            'area': 'Executive Impact',
            'reason': 'Senior/executive-level position',
            'focus': 'Strategic vision, P&L impact, organizational transformation',
            'metrics_to_emphasize': ['$12M+ first-year revenue', '$11.6M+ managed portfolio', '35% faster time-to-market']
        })
    elif job_level == 'senior':
        emphasis_recommendations.append({
            'area': 'Senior Leadership',
            'reason': 'Senior-level position',
            'focus': 'Cross-functional leadership, scalable solutions, business impact',
            'metrics_to_emphasize': ['45% conversion improvement', '3.2x pipeline velocity', '$4.5M pipeline']
        })
    
    # Generate overall recommendations
    overall_recommendations = []
    
    if match_percentage >= 80:
        overall_recommendations.append("Excellent skill match - highlight matching capabilities prominently")
    elif match_percentage >= 60:
        overall_recommendations.append("Good skill match - emphasize relevant experience and transferable skills")
    else:
        overall_recommendations.append("Moderate match - focus on transferable skills and relevant achievements")
    
    if skill_gaps:
        overall_recommendations.append(f"Address {len(skill_gaps)} skill gaps by emphasizing related experience")
    
    return {
        'match_percentage': match_percentage,
        'direct_matches': direct_matches,
        'fuzzy_matches': fuzzy_matches,
        'total_matches': len(all_matches),
        'skill_gaps': skill_gaps,
        'emphasis_recommendations': emphasis_recommendations,
        'overall_recommendations': overall_recommendations
    }


def main():
    """Example usage"""
    candidate_skills = {
        'technical_platforms': ['HubSpot', 'Salesforce', 'Python', 'SQL'],
        'ai_ml': ['Machine Learning', 'Predictive Analytics'],
        'marketing_platforms': ['DV360', 'CM360', 'Google Ads'],
        'strategic_capabilities': ['Product Strategy', 'ABM', 'Demand Generation']
    }
    
    job_requirements = {
        'tech_skills': ['Salesforce', 'HubSpot', 'Python'],
        'marketing_skills': ['ABM', 'Demand Generation', 'Marketing Automation'],
        'leadership_skills': ['Product Strategy', 'Cross-functional'],
        'focus_areas': ['Product Management', 'Marketing'],
        'job_level': 'senior'
    }
    
    results = match_skills(candidate_skills, job_requirements)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
