#!/usr/bin/env python3
"""
Extract keywords, requirements, and skills from job descriptions.
"""

import re
import json
from typing import Dict, List, Set
from collections import Counter


def extract_keywords(job_description: str) -> Dict[str, any]:
    """
    Extract keywords, skills, and requirements from a job description.
    
    Args:
        job_description: The raw job description text
        
    Returns:
        Dictionary containing extracted keywords, skills, requirements, and other metadata
    """
    
    # Common skill patterns
    tech_skills_patterns = [
        r'\b(Python|Java|JavaScript|TypeScript|SQL|R|C\+\+|Go|Ruby|PHP|Swift)\b',
        r'\b(HubSpot|Salesforce|Marketo|Pardot|Eloqua|Adobe|Oracle)\b',
        r'\b(DV360|CM360|Trade Desk|Amazon DSP|Google Ads|Facebook Ads)\b',
        r'\b(Tableau|Power BI|Looker|Google Analytics|Adobe Analytics)\b',
        r'\b(AWS|Azure|GCP|Docker|Kubernetes|Jenkins|Git)\b',
        r'\b(Machine Learning|ML|AI|NLP|Deep Learning|Neural Networks)\b',
        r'\b(React|Angular|Vue|Node\.js|Django|Flask|Spring)\b',
        r'\b(API|REST|GraphQL|Microservices|CI/CD|DevOps)\b',
    ]
    
    marketing_skills_patterns = [
        r'\b(ABM|Account-Based Marketing|Demand Generation|Lead Generation)\b',
        r'\b(SEO|SEM|PPC|Paid Search|Programmatic|Display Advertising)\b',
        r'\b(Marketing Automation|Email Marketing|Nurture Campaigns)\b',
        r'\b(CRM|Customer Relationship Management|Lead Scoring)\b',
        r'\b(GTM|Go-to-Market|Product Launch|Product Marketing)\b',
        r'\b(Content Marketing|Social Media|Brand Marketing)\b',
        r'\b(Analytics|Attribution|ROI|KPI|Metrics)\b',
        r'\b(A/B Testing|Conversion Optimization|CRO|Funnel Optimization)\b',
    ]
    
    # Product/leadership keywords
    leadership_patterns = [
        r'\b(Product Strategy|Product Management|Product Development)\b',
        r'\b(Roadmap|Vision|Strategy|Strategic Planning)\b',
        r'\b(Cross-functional|Stakeholder Management|Executive)\b',
        r'\b(Team Leadership|People Management|Mentoring)\b',
        r'\b(Budget|P&L|Profit and Loss|Financial)\b',
        r'\b(Agile|Scrum|Sprint|Kanban)\b',
    ]
    
    # Extract all skills
    tech_skills = set()
    marketing_skills = set()
    leadership_skills = set()
    
    for pattern in tech_skills_patterns:
        matches = re.findall(pattern, job_description, re.IGNORECASE)
        tech_skills.update([m.strip() for m in matches])
    
    for pattern in marketing_skills_patterns:
        matches = re.findall(pattern, job_description, re.IGNORECASE)
        marketing_skills.update([m.strip() for m in matches])
    
    for pattern in leadership_patterns:
        matches = re.findall(pattern, job_description, re.IGNORECASE)
        leadership_skills.update([m.strip() for m in matches])
    
    # Extract years of experience required
    experience_match = re.search(r'(\d+)\+?\s*years?\s*(of)?\s*experience', job_description, re.IGNORECASE)
    years_experience = experience_match.group(1) if experience_match else None
    
    # Extract education requirements
    education_keywords = []
    if re.search(r'\b(Bachelor|BA|BS|B\.S\.|B\.A\.)\b', job_description, re.IGNORECASE):
        education_keywords.append("Bachelor's Degree")
    if re.search(r'\b(Master|MBA|MS|M\.S\.|M\.B\.A\.)\b', job_description, re.IGNORECASE):
        education_keywords.append("Master's Degree")
    if re.search(r'\b(PhD|Ph\.D\.|Doctorate)\b', job_description, re.IGNORECASE):
        education_keywords.append("PhD")
    
    # Extract key action verbs (for matching to resume)
    action_verbs = set()
    action_verb_patterns = [
        r'\b(Lead|Manage|Drive|Build|Develop|Create|Design|Implement)\b',
        r'\b(Optimize|Improve|Scale|Grow|Launch|Execute|Deliver)\b',
        r'\b(Architect|Engineer|Establish|Transform|Accelerate)\b',
        r'\b(Collaborate|Partner|Align|Influence|Present)\b',
    ]
    
    for pattern in action_verb_patterns:
        matches = re.findall(pattern, job_description, re.IGNORECASE)
        action_verbs.update([m.strip() for m in matches])
    
    # Extract key phrases (2-4 word sequences that appear multiple times)
    words = re.findall(r'\b[a-z]+\b', job_description.lower())
    phrases = []
    for i in range(len(words) - 3):
        phrase_2 = ' '.join(words[i:i+2])
        phrase_3 = ' '.join(words[i:i+3])
        phrases.extend([phrase_2, phrase_3])
    
    phrase_counts = Counter(phrases)
    # Get phrases that appear 2+ times and are relevant (filter common words)
    stop_phrases = {'and the', 'of the', 'to the', 'in the', 'for the', 'with the', 
                    'will be', 'you will', 'we are', 'is a', 'this is'}
    key_phrases = {phrase: count for phrase, count in phrase_counts.most_common(20) 
                   if count >= 2 and phrase not in stop_phrases}
    
    # Determine job level
    job_level = "mid"
    if any(word in job_description.lower() for word in ['senior', 'sr.', 'lead', 'principal']):
        job_level = "senior"
    if any(word in job_description.lower() for word in ['director', 'vp', 'vice president', 'head of', 'chief']):
        job_level = "executive"
    if any(word in job_description.lower() for word in ['junior', 'jr.', 'entry', 'associate']):
        job_level = "junior"
    
    # Determine primary focus areas
    focus_areas = []
    if any(skill.lower() in job_description.lower() for skill in ['product', 'roadmap', 'strategy']):
        focus_areas.append("Product Management")
    if any(skill.lower() in job_description.lower() for skill in ['marketing', 'campaign', 'demand gen']):
        focus_areas.append("Marketing")
    if any(skill.lower() in job_description.lower() for skill in ['ai', 'machine learning', 'ml', 'data science']):
        focus_areas.append("AI/ML")
    if any(skill.lower() in job_description.lower() for skill in ['growth', 'revenue', 'pipeline']):
        focus_areas.append("Growth/Revenue")
    if any(skill.lower() in job_description.lower() for skill in ['pharma', 'healthcare', 'life sciences', 'medical']):
        focus_areas.append("Healthcare/Life Sciences")
    
    return {
        "tech_skills": sorted(list(tech_skills)),
        "marketing_skills": sorted(list(marketing_skills)),
        "leadership_skills": sorted(list(leadership_skills)),
        "years_experience": years_experience,
        "education_requirements": education_keywords,
        "action_verbs": sorted(list(action_verbs)),
        "key_phrases": key_phrases,
        "job_level": job_level,
        "focus_areas": focus_areas,
        "all_skills": sorted(list(tech_skills | marketing_skills | leadership_skills))
    }


def main():
    """Example usage"""
    sample_job_desc = """
    We are seeking a Senior Product Manager with 8+ years of experience to lead our AI-powered 
    marketing platform. You will drive product strategy, work with cross-functional teams, and 
    deliver innovative solutions using machine learning and data analytics.
    
    Requirements:
    - 8+ years in product management or related field
    - Experience with Salesforce, HubSpot, or similar CRM platforms
    - Strong understanding of AI/ML and data-driven marketing
    - Bachelor's degree required, MBA preferred
    - Experience with Agile/Scrum methodologies
    """
    
    results = extract_keywords(sample_job_desc)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
