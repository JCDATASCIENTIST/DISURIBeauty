#!/usr/bin/env python3
"""
Generate ATS-optimized Word document resume using python-docx.
"""

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from typing import Dict, List


class DocxResumeBuilder:
    """ATS-optimized Word document resume builder"""
    
    def __init__(self):
        self.doc = Document()
        self._setup_document()
    
    def _setup_document(self):
        """Setup document margins and default styles"""
        # Set margins (0.75 inches all around)
        sections = self.doc.sections
        for section in sections:
            section.top_margin = Inches(0.75)
            section.bottom_margin = Inches(0.75)
            section.left_margin = Inches(0.75)
            section.right_margin = Inches(0.75)
    
    def _add_styled_paragraph(self, text: str, style_type: str = 'normal'):
        """Add a paragraph with specific styling"""
        para = self.doc.add_paragraph()
        run = para.add_run(text)
        
        if style_type == 'name':
            run.font.size = Pt(16)
            run.font.bold = True
            run.font.name = 'Arial'
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        elif style_type == 'contact':
            run.font.size = Pt(10)
            run.font.name = 'Arial'
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        elif style_type == 'section_header':
            run.font.size = Pt(12)
            run.font.bold = True
            run.font.name = 'Arial'
            para.space_before = Pt(12)
            para.space_after = Pt(6)
        
        elif style_type == 'job_title':
            run.font.size = Pt(11)
            run.font.bold = True
            run.font.name = 'Arial'
            para.space_after = Pt(3)
        
        elif style_type == 'company_date':
            run.font.size = Pt(10)
            run.font.name = 'Arial'
            run.font.color.rgb = RGBColor(80, 80, 80)
            para.space_after = Pt(6)
        
        elif style_type == 'bullet':
            run.font.size = Pt(10)
            run.font.name = 'Arial'
            para.paragraph_format.left_indent = Inches(0.25)
            para.paragraph_format.space_after = Pt(4)
        
        else:  # normal
            run.font.size = Pt(10)
            run.font.name = 'Arial'
            para.space_after = Pt(6)
        
        return para
    
    def add_header(self, name: str, location: str, phone: str, email: str, linkedin: str = ''):
        """Add resume header with contact information"""
        # Name
        self._add_styled_paragraph(name.upper(), 'name')
        
        # Contact info
        contact_parts = [location, phone, email]
        if linkedin:
            contact_parts.append(linkedin)
        contact_text = " | ".join(contact_parts)
        
        self._add_styled_paragraph(contact_text, 'contact')
        
        # Add spacing
        self.doc.add_paragraph()
    
    def add_summary(self, summary_text: str):
        """Add professional summary section"""
        self._add_styled_paragraph("PROFESSIONAL SUMMARY", 'section_header')
        self._add_styled_paragraph(summary_text, 'normal')
    
    def add_experience_section(self, experiences: List[Dict]):
        """Add work experience section"""
        self._add_styled_paragraph("PROFESSIONAL EXPERIENCE", 'section_header')
        
        for i, exp in enumerate(experiences):
            # Job title
            self._add_styled_paragraph(exp['title'], 'job_title')
            
            # Company and dates
            company_date = f"{exp['company']} | {exp['location']} | {exp['dates']}"
            self._add_styled_paragraph(company_date, 'company_date')
            
            # Achievements/responsibilities (bullets)
            for bullet in exp['bullets']:
                para = self.doc.add_paragraph(style='List Bullet')
                run = para.add_run(bullet)
                run.font.size = Pt(10)
                run.font.name = 'Arial'
                para.paragraph_format.space_after = Pt(4)
            
            # Add spacing between jobs (except after last one)
            if i < len(experiences) - 1:
                self.doc.add_paragraph()
    
    def add_skills_section(self, skills: Dict[str, List[str]]):
        """Add skills section with categories"""
        self._add_styled_paragraph("TECHNICAL SKILLS & EXPERTISE", 'section_header')
        
        for category, skill_list in skills.items():
            para = self.doc.add_paragraph()
            
            # Category (bold)
            cat_run = para.add_run(f"{category}: ")
            cat_run.font.bold = True
            cat_run.font.size = Pt(10)
            cat_run.font.name = 'Arial'
            
            # Skills (normal)
            skills_run = para.add_run(", ".join(skill_list))
            skills_run.font.size = Pt(10)
            skills_run.font.name = 'Arial'
            
            para.paragraph_format.space_after = Pt(4)
    
    def add_education_section(self, education: List[Dict]):
        """Add education and certifications section"""
        self._add_styled_paragraph("EDUCATION & CERTIFICATIONS", 'section_header')
        
        for edu in education:
            para = self.doc.add_paragraph()
            
            if 'degree' in edu:
                # Degree (bold)
                degree_run = para.add_run(edu['degree'])
                degree_run.font.bold = True
                degree_run.font.size = Pt(10)
                degree_run.font.name = 'Arial'
                
                # Additional info
                parts = []
                if 'major' in edu:
                    parts.append(edu['major'])
                if 'institution' in edu:
                    parts.append(edu['institution'])
                if 'year' in edu:
                    parts.append(str(edu['year']))
                
                if parts:
                    info_run = para.add_run(f", {' | '.join(parts)}")
                    info_run.font.size = Pt(10)
                    info_run.font.name = 'Arial'
            
            elif 'certification' in edu:
                # Certification (bold)
                cert_run = para.add_run(edu['certification'])
                cert_run.font.bold = True
                cert_run.font.size = Pt(10)
                cert_run.font.name = 'Arial'
                
                # Additional info
                parts = []
                if 'issuer' in edu:
                    parts.append(edu['issuer'])
                if 'year' in edu:
                    parts.append(str(edu['year']))
                
                if parts:
                    info_run = para.add_run(f" | {' | '.join(parts)}")
                    info_run.font.size = Pt(10)
                    info_run.font.name = 'Arial'
            
            para.paragraph_format.space_after = Pt(4)
    
    def save(self, output_path: str):
        """Save the document"""
        self.doc.save(output_path)
        return output_path


def generate_resume_docx(resume_data: Dict, output_path: str) -> str:
    """
    Generate ATS-optimized Word document resume.
    
    Args:
        resume_data: Dictionary containing all resume sections
        output_path: Path where Word doc should be saved
        
    Returns:
        Path to generated Word document
    """
    builder = DocxResumeBuilder()
    
    # Add header
    builder.add_header(
        name=resume_data['name'],
        location=resume_data['location'],
        phone=resume_data['phone'],
        email=resume_data['email'],
        linkedin=resume_data.get('linkedin', '')
    )
    
    # Add summary if provided
    if 'summary' in resume_data and resume_data['summary']:
        builder.add_summary(resume_data['summary'])
    
    # Add experience
    if 'experience' in resume_data:
        builder.add_experience_section(resume_data['experience'])
    
    # Add skills
    if 'skills' in resume_data:
        builder.add_skills_section(resume_data['skills'])
    
    # Add education
    if 'education' in resume_data:
        builder.add_education_section(resume_data['education'])
    
    # Save and return
    return builder.save(output_path)


def main():
    """Example usage"""
    sample_data = {
        'name': 'Joel Castillo',
        'location': 'Lake Worth, FL',
        'phone': '(555) 123-4567',
        'email': 'joel@example.com',
        'linkedin': 'linkedin.com/in/joelcastillo',
        'summary': 'Strategic AI Product Leader with 15 years driving commercial growth for life sciences. Architected platforms delivering $11.6M+ in managed media, $4.5M+ in pipeline.',
        'experience': [
            {
                'title': 'Senior Product Manager',
                'company': 'ZimVie',
                'location': 'Palm Beach Gardens, FL',
                'dates': 'Jan 2020 - Present',
                'bullets': [
                    'Architected ABM platform delivering 45% improvement in MQL-to-SQL conversion and $4.5M in marketing-sourced pipeline',
                    'Led GTM strategy for three pharma launches, driving 35% faster time-to-market and $12M+ first-year revenue',
                    'Reduced campaign setup time by 90% through AI-powered automation platform supporting $10M+ annual programmatic media'
                ]
            }
        ],
        'skills': {
            'Marketing Technology': ['HubSpot', 'Salesforce', '6sense', 'DV360', 'CM360'],
            'AI/ML': ['Machine Learning', 'Predictive Analytics', 'AI Product Development'],
            'Strategy': ['Product Strategy', 'ABM', 'GTM Planning', 'Demand Generation']
        },
        'education': [
            {'certification': 'Machine Learning Specialization', 'issuer': 'Stanford University'},
            {'certification': 'HubSpot Marketing Automation', 'issuer': 'HubSpot Academy'}
        ]
    }
    
    output = generate_resume_docx(sample_data, 'Joel_Castillo_Resume.docx')
    print(f"Resume generated: {output}")


if __name__ == "__main__":
    main()
