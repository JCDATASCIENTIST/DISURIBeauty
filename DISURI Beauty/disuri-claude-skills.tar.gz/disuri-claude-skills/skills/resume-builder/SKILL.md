---
name: resume-builder
description: Generate ATS-optimized resumes tailored to specific job postings. Use when the user requests resume creation, resume updates, or asks to build/generate/create a resume for a specific role or job description. This skill extracts keywords from job descriptions, matches candidate skills, and produces professional PDF and Word document resumes optimized for both ATS systems and human reviewers. Trigger phrases include "build me a resume for", "create a resume targeting", "generate resume for [job title]", or "update my resume for [position]".
---

# Resume Builder Skill

Generate ATS-optimized, professionally formatted resumes tailored to specific job descriptions. This skill automates the entire resume creation workflow—from analyzing job requirements to producing polished PDF and Word documents that pass ATS screening and impress hiring managers.

## Workflow Overview

Follow this sequential workflow to generate a customized resume:

### Step 1: Gather Job Requirements
Ask the user for the job description or job posting. This can be:
- Full job description text (paste into chat)
- Job posting URL (fetch and extract content)
- Brief job title and key requirements (user provides highlights)

### Step 2: Extract Job Keywords and Requirements
Use `scripts/extract_job_keywords.py` to analyze the job description:

```python
from scripts.extract_job_keywords import extract_keywords

job_description = """[job posting text]"""
job_requirements = extract_keywords(job_description)
```

This extracts:
- Technical skills (platforms, tools, languages)
- Marketing/business skills
- Leadership capabilities
- Required years of experience
- Education requirements
- Job level (junior/mid/senior/executive)
- Focus areas (Product, Marketing, AI/ML, Healthcare, etc.)
- Key action verbs and phrases

### Step 3: Match Skills to Job
Use `scripts/match_skills_to_job.py` to map Joel's skills to the job requirements:

```python
from scripts.match_skills_to_job import match_skills

# Load Joel's skills from references/joel_skills_inventory.md
candidate_skills = {
    'technical_platforms': [...],
    'ai_ml': [...],
    'marketing_platforms': [...],
    'strategic_capabilities': [...]
}

match_results = match_skills(candidate_skills, job_requirements)
```

This provides:
- Match percentage (how well skills align)
- Direct and fuzzy skill matches
- Skill gaps to address
- **Emphasis recommendations** - which projects/experiences to highlight
- Strategic positioning advice based on job level and focus areas

### Step 4: Customize Resume Content
Based on the match results, customize the resume by:

1. **Select relevant projects** - Prioritize projects from emphasis recommendations
2. **Tailor the summary** - Adjust professional summary to match job focus areas
3. **Emphasize matching skills** - Highlight skills that directly match job requirements
4. **Quantify relevant metrics** - Choose metrics that align with job priorities
5. **Adjust experience bullets** - Lead with achievements relevant to the role

**Refer to these guidelines:**
- `references/tech_resume_guidelines.md` - For content strategy, writing style, and section formatting
- `references/ats_best_practices.md` - For ATS compliance and formatting rules
- `references/joel_skills_inventory.md` - For Joel's complete experience, projects, and achievements

### Step 5: Structure Resume Data
Create a structured dictionary with all resume sections:

```python
resume_data = {
    'name': 'Joel Castillo',
    'location': 'Lake Worth, FL',
    'phone': '[phone]',
    'email': '[email]',
    'linkedin': 'linkedin.com/in/joelcastillo',
    
    'summary': '[Tailored 2-3 line summary based on job focus]',
    
    'experience': [
        {
            'title': '[Job Title]',
            'company': '[Company]',
            'location': '[Location]',
            'dates': '[Start Date] - [End Date]',
            'bullets': [
                '[Achievement with metric aligned to job requirements]',
                '[Another achievement emphasizing relevant skills]',
                '[Strategic accomplishment showing leadership/impact]'
            ]
        },
        # Additional positions as relevant
    ],
    
    'skills': {
        '[Category 1]': ['skill1', 'skill2', 'skill3'],
        '[Category 2]': ['skill1', 'skill2', 'skill3'],
        # Organize by relevance to job
    },
    
    'education': [
        {'certification': '[Cert Name]', 'issuer': '[Organization]', 'year': '[Year]'},
        # List relevant certifications from joel_skills_inventory.md
    ]
}
```

**Key Customization Rules:**
- **For Product Management roles**: Lead with product strategy achievements, platform architecture, cross-functional leadership
- **For Marketing/Growth roles**: Lead with revenue/pipeline metrics, campaign results, channel expertise
- **For AI/ML roles**: Emphasize ML projects (NPI Lookup Tool, ABM Engine), technical depth
- **For Healthcare/Pharma roles**: Highlight all pharma projects, HCP targeting, regulatory compliance
- **For Executive roles**: Focus on strategic vision, P&L impact, organizational transformation

### Step 6: Generate Resume Files
Use both PDF and Word document generators:

```python
from scripts.generate_resume_pdf import generate_resume_pdf
from scripts.generate_resume_docx import generate_resume_docx

# Generate PDF
pdf_path = generate_resume_pdf(resume_data, '/mnt/user-data/outputs/Joel_Castillo_Resume.pdf')

# Generate Word doc
docx_path = generate_resume_docx(resume_data, '/mnt/user-data/outputs/Joel_Castillo_Resume.docx')
```

### Step 7: Present to User
Use the `present_files` tool to share both files:
- PDF version (for most applications)
- Word doc version (for systems requiring .docx)

Provide a brief summary of:
- Match percentage with job requirements
- Key skills emphasized
- Major projects highlighted
- Any recommendations for further customization

## Important Considerations

### ATS Compliance
Always follow the rules in `references/ats_best_practices.md`:
- Single column layout (no tables for structure)
- Standard fonts only (Arial, Calibri)
- No headers/footers, images, or graphics
- Standard section headers
- Keyword optimization based on job description

### Content Strategy

**Length Guidelines:**
- 1 page for <10 years experience
- 2 pages for senior/executive roles (Joel should use 2 pages)

**Bullet Point Formula:**
[Action Verb] + [What You Did] + [Metric/Impact] + [Business Context]

Example: "Architected enterprise ABM platform unifying HubSpot/Salesforce workflows—delivered 45% improvement in MQL-to-SQL conversion and $4.5M in marketing-sourced pipeline"

**Metrics Priority:**
1. Revenue/pipeline ($)
2. Efficiency gains (% or time)
3. Scale (volume, accounts, users)
4. Performance improvement (conversion rates, ROI)

### Skill Emphasis Strategy

**Match Score 80%+**: 
- Highlight matching capabilities prominently in summary
- Lead with matching skills in skills section
- Choose projects that demonstrate required competencies

**Match Score 60-80%**:
- Emphasize transferable skills
- Show how related experience applies to new role
- Address potential gaps with relevant achievements

**Match Score <60%**:
- Focus on strategic thinking and problem-solving
- Highlight learning agility and adaptability
- Demonstrate domain expertise where it overlaps

## Example Usage

**User Request:**
"Build me a resume for a Director of Product Management role at a healthcare tech company"

**Workflow:**
1. Extract keywords from job description → Identifies: Product Strategy, Healthcare, AI/ML, GTM
2. Match skills → 85% match, emphasizes Product Management + Healthcare
3. Customize content:
   - Summary: Lead with "Strategic AI Product Leader" and healthcare focus
   - Experience: Lead with NPI Lookup Tool, GTM Strategy Platform, ABM Engine
   - Skills: Prioritize Product Strategy, Healthcare Data, AI/ML platforms
   - Projects: Emphasize healthcare domain expertise and strategic leadership
4. Generate PDF and Word docs
5. Present both files to user

## Reference Files

- **[ats_best_practices.md](references/ats_best_practices.md)** - ATS formatting rules and optimization strategies
- **[tech_resume_guidelines.md](references/tech_resume_guidelines.md)** - Tech industry resume standards, writing style, and content strategy
- **[joel_skills_inventory.md](references/joel_skills_inventory.md)** - Complete inventory of Joel's experience, projects, skills, and achievements

## Scripts

- **[extract_job_keywords.py](scripts/extract_job_keywords.py)** - Analyze job descriptions and extract requirements
- **[match_skills_to_job.py](scripts/match_skills_to_job.py)** - Match candidate skills to job and recommend emphasis areas
- **[generate_resume_pdf.py](scripts/generate_resume_pdf.py)** - Generate ATS-optimized PDF resume
- **[generate_resume_docx.py](scripts/generate_resume_docx.py)** - Generate ATS-optimized Word document resume
