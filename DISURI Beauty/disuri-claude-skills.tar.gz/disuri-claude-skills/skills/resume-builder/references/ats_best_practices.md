# ATS Best Practices

## Critical ATS Formatting Rules

### File Format
- **PDF**: Use standard PDF/A format with selectable text (never image-based PDFs)
- **Word Doc**: Use .docx format (Office 2007+), not .doc

### Fonts & Typography
- **Safe fonts only**: Arial, Calibri, Georgia, Times New Roman, Trebuchet MS
- **Font size**: 10-12pt for body text, 14-16pt for name/headers
- **Avoid**: Fancy fonts, multiple font families, excessive styling

### Layout & Structure
- **Single column layout**: Most ATS systems struggle with multi-column formats
- **Standard section headers**: Use conventional names like "Work Experience", "Education", "Skills"
- **No text boxes**: Never use text boxes, shapes, or floating elements
- **No tables**: Avoid tables for content layout (simple tables for skills lists may work)
- **No headers/footers**: Keep all content in main body
- **No images/graphics**: Including photos, logos, or decorative elements

### Content Organization
- **Reverse chronological order**: Most recent experience first
- **Clear section breaks**: Use standard section headers
- **Consistent formatting**: Same style for all job titles, dates, etc.
- **Bullet points**: Use standard bullet characters (•, -, *)

### Keyword Optimization
- **Exact keyword matching**: Use exact phrases from job description where relevant
- **Industry terminology**: Include both acronyms and full terms (e.g., "SEO (Search Engine Optimization)")
- **Skills section**: Create dedicated skills section with relevant keywords
- **Context keywords**: Weave keywords naturally into experience descriptions
- **Action verbs**: Start bullet points with strong action verbs

### Contact Information
- **Standard format**: Name at top, followed by contact info
- **Include**: Phone, email, LinkedIn, location (city/state)
- **Avoid**: Full street address (city/state sufficient)

### File Naming
- **Format**: FirstName_LastName_Resume.pdf
- **Avoid**: Generic names like "resume.pdf" or "CV.docx"

### Common ATS Killers
- ❌ Graphics, charts, or visual elements
- ❌ Headers and footers with critical info
- ❌ Multiple columns
- ❌ Text boxes or shapes
- ❌ Special characters or symbols (except bullets)
- ❌ Tables for layout structure
- ❌ Fancy borders or lines
- ❌ Abbreviations without context
- ❌ Unconventional section names

## ATS Parsing Priorities

ATS systems typically parse in this order:
1. Contact information
2. Work experience (job titles, companies, dates)
3. Education (degrees, institutions, dates)
4. Skills section
5. Certifications

Ensure these sections use standard formatting and clear labels.
