# Tech Industry Resume Guidelines

## Resume Layout & Structure

### Overall Format
- **Length**: 1-2 pages (1 page for <10 years experience, 2 pages for senior roles)
- **Layout**: Single column, clean, scannable
- **Spacing**: Consistent margins (0.5-1 inch), adequate white space
- **Density**: Balance between comprehensive and concise

### Section Order (Standard)
1. **Header**: Name, contact info, LinkedIn
2. **Professional Summary** (2-3 lines, optional but recommended for senior roles)
3. **Work Experience** (most important - lead with this)
4. **Skills & Technical Expertise**
5. **Education & Certifications**
6. **Projects/Portfolio** (if applicable)

### Header Format
```
JOEL CASTILLO
City, State | phone | email | linkedin.com/in/profile
```

### Professional Summary (Optional - Use for Senior Roles)
- 2-3 lines maximum
- Lead with role/title positioning
- Highlight unique value proposition
- Include quantifiable achievements
- Focus on strategic impact, not tactical tasks

**Example:**
"Strategic AI Product Leader with 15 years driving commercial growth for life sciences organizations. Architected platforms delivering $11.6M+ in managed media, $4.5M+ in marketing-sourced pipeline. Expert in ABM orchestration, programmatic automation, and AI-powered product launches."

## Work Experience Section

### Job Entry Format
```
Job Title | Company Name | Location | Date Range
- Achievement-focused bullet point with metric
- Another achievement showing impact
- Technical/strategic accomplishment with result
```

### Writing Strong Bullets
1. **Start with action verb**: Led, Architected, Drove, Established, Delivered
2. **Include metrics**: Numbers, percentages, dollar amounts, timeframes
3. **Show impact**: Connect action to business outcome
4. **Use technical context**: Reference platforms, frameworks, methodologies

**Weak bullet:**
"Managed marketing automation platform"

**Strong bullet:**
"Architected enterprise ABM platform unifying HubSpot/Salesforce workflows—delivered 45% improvement in MQL-to-SQL conversion and $4.5M in marketing-sourced pipeline"

### Metrics That Matter
- Revenue impact ($ generated, % increase)
- Efficiency gains (time saved, % reduction)
- Scale (users, accounts, volume managed)
- Performance improvement (conversion rates, ROI %)
- Team/cross-functional impact (stakeholders aligned, teams led)

## Skills Section

### Format Options

**Option 1: Categorized Skills**
```
Technical Platforms: HubSpot, Salesforce, DV360, CM360, 6sense, Demandbase
AI/ML: Machine Learning, Predictive Analytics, NLP, Model Training
Marketing Strategy: ABM, Demand Generation, Programmatic Media, GTM Planning
```

**Option 2: Comprehensive List**
```
Skills: Python, Machine Learning, HubSpot, Salesforce, ABM Strategy, Programmatic Media (DV360, CM360), Data Analysis, Product Management, GTM Planning, Marketing Automation, CRM Integration, AI/ML Product Development
```

### Skills Section Best Practices
- **Include acronyms and full terms**: "ABM (Account-Based Marketing)"
- **Mix hard and soft skills**: Technical platforms + strategic capabilities
- **Match job description keywords**: Prioritize skills from job posting
- **Group logically**: By category or skill type
- **Be specific**: "DV360, CM360" instead of just "programmatic platforms"

## Education & Certifications

### Format
```
Degree Name, Major | University Name | Graduation Year
Relevant Certifications | Issuing Organization | Year
```

### Certification Guidelines
- List relevant certifications (HubSpot, Salesforce, Google, etc.)
- Include year if recent (within 3 years)
- Prioritize industry-recognized certs
- Group related certifications together

## Tech Resume Content Strategy

### For Product/Technical Leadership Roles
- Lead with product/platform achievements
- Emphasize architecture, strategy, and scalability
- Show cross-functional leadership
- Highlight technical depth + business acumen

### For Marketing/Growth Roles
- Lead with revenue/pipeline metrics
- Emphasize channel expertise and campaign results
- Show data-driven decision making
- Balance strategic vision with execution

### For Senior/Director/VP Roles
- Emphasize strategic impact over tactical execution
- Show organizational influence and cross-functional leadership
- Highlight P&L ownership, budget management
- Include transformation/change management achievements

## Writing Style

### Voice & Tone
- **Active, not passive**: "Led" not "Was responsible for"
- **Concise**: Remove filler words and unnecessary adjectives
- **Confident**: Avoid "helped with" or "assisted in"
- **Specific**: Replace vague terms with concrete details

### Numbers & Metrics
- **Be precise**: "$4.5M" not "millions of dollars"
- **Use %**: "45% improvement" vs "significant improvement"
- **Show scale**: "across 200+ accounts" or "managing $11.6M portfolio"
- **Include timeframes**: "in 6 months" or "year-over-year"

### Technical Terminology
- Use industry-standard terms
- Spell out acronyms on first use (optional in skills section)
- Reference specific platforms/tools by name
- Show technical depth without overwhelming

## Common Mistakes to Avoid

❌ **Generic descriptions**: "Managed marketing campaigns"
✅ **Specific achievements**: "Orchestrated $11.6M programmatic media portfolio across DV360/CM360, delivering 20% ROI improvement"

❌ **Responsibilities focus**: "Responsible for CRM management"
✅ **Impact focus**: "Architected HubSpot/Salesforce automation reducing manual operations by 80%"

❌ **Passive voice**: "Was involved in product launches"
✅ **Active voice**: "Led GTM strategy for three pharma product launches, accelerating time-to-market by 35%"

❌ **Vague metrics**: "Improved performance significantly"
✅ **Specific metrics**: "Increased MQL-to-SQL conversion by 45% and pipeline velocity by 3.2x"

## Visual Design Principles

### Typography
- Use 1-2 font families maximum
- Consistent font sizes for similar elements
- Bold for emphasis on titles/companies only
- Adequate line spacing (1.0-1.15)

### White Space
- Margins: 0.5-1 inch on all sides
- Section breaks: Clear visual separation
- Line spacing: Room to breathe between entries
- Not too dense: Prioritize readability over cramming

### Hierarchy
- Name: Largest text (16-18pt)
- Section headers: Bold, slightly larger (12-14pt)
- Job titles: Bold (11pt)
- Body text: Regular weight (10-11pt)

## Tech Industry Preferences

- **LinkedIn**: Always include LinkedIn profile link
- **GitHub**: Include if relevant technical portfolio
- **Portfolio/Projects**: Optional section for PMs or technical roles
- **Publications/Patents**: Include if relevant to role
- **Avoid**: Objectives statements, references line, photos
