---
description: Dental Device Skill Version History
---

# Dental Device Expert Skill — Version History

## v1.0 — 2026-02-20 — FINALIZED ✅

### Status: Deploy ready. 8/8 evals passing (100%).

### Contents
- `SKILL.md` — Router, ZimVie product priority map, intake questions, output quality checklist
- `references/` — 8 reference files covering implants, regenerative, digital, clinical, competitive, regulatory, equipment, and API integration
- `evals/` — 8 evals with machine-readable evals.json and human-readable EVAL-GUIDE.md

### Reference Files
| File | Coverage |
|------|---------|
| `implant-systems.md` | ZimVie TSV / Trabecular Metal, competitive implant landscape, connections, loading protocols |
| `regenerative-products.md` | Full ZimVie graft + membrane portfolio, GBR/GTR, sinus lift, socket preservation, biologics |
| `digital-dentistry.md` | RealGUIDE all modules, CBCT workflow, surgical guide types, competitive digital platforms |
| `clinical-workflows.md` | Patient selection, risk assessment, full treatment planning and surgical sequence, complication management |
| `device-categories.md` | Handpieces, delivery units, CBCT/IOS imaging, sterilization, infection control, equipment selection |
| `competitive-landscape.md` | Straumann, Nobel Biocare, Dentsply Sirona, Osstem — product-level comparison + ZimVie positioning |
| `regulatory-safety.md` | FDA device classification, ADA standards, CDC infection control, reprocessing, HIPAA |
| `api-integration-guide.md` | MCP/REST connector architecture, tool definitions, PHI handling, ZimVie-specific API notes |

### Eval Results
| Eval | Topic | Result |
|------|-------|--------|
| DD-1 | Implant Loading Protocol | ✅ 6/6 |
| DD-2 | Graft + Membrane Selection | ✅ 6/6 |
| DD-3 | RealGUIDE vs. DTX Studio | ✅ 6/6 |
| DD-4 | Handpiece Reprocessing Safety | ✅ 6/6 |
| DD-5 | Full-Arch vs. All-on-4 | ✅ 6/6 |
| DD-6 | Puros FDA Classification | ✅ 6/6 |
| DD-7 | Bisphosphonate Risk Assessment | ✅ 7/7 |
| DD-8 | TSV vs. BLX Comparison | ✅ 7/7 |

### Design Principles
- **Source labeling**: All responses tag content as [Manufacturer], [ADA/Standards], [FDA/CDC], or [Independent CE]
- **Educational framing**: Clinical content is educational only — never prescriptive or a substitute for IFUs
- **ZimVie-first, not ZimVie-only**: Competitive landscape is addressed honestly and balanced
- **Safety-critical urgency**: Patient safety questions (reprocessing, contraindications) receive appropriately urgent responses

### Changelog
- **v1.0**: Initial release. All 8 reference files, 8 evals, full eval suite passed first run.

### Known Gaps for v1.1
- GTR membrane selection for periodontal defects (vs. GBR for implants) — eval candidate
- Sinus augmentation for large vertical deficiency >8mm — eval candidate  
- Peri-implantitis staging and treatment decision — eval candidate
- Patient-facing vs. HCP-facing language — same product, different audience — eval candidate
- ZimVie distribution channel question (Henry Schein, Patterson, Benco) — eval candidate
- CBCT dose optimization for patients with heavy metallic restorations — eval candidate
