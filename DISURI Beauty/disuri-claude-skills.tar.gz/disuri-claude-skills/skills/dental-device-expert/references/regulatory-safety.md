---
description: Regulatory and Safety Reference
---

# Regulatory & Safety — FDA, ADA, CDC Standards for Dental Devices

## FDA Device Classification

### Class I, II, III Framework

| Class | Risk Level | Examples | Regulatory Pathway |
|-------|-----------|---------|-------------------|
| **Class I** | Low risk | Dental mirrors, impression trays, some handpieces | General controls only; most exempt from premarket review |
| **Class II** | Moderate risk | Dental implants, bone grafts, surgical guides, imaging systems | General controls + special controls; 510(k) clearance typically required |
| **Class III** | High risk | Devices sustaining/supporting life; new technology without predicate | Premarket Approval (PMA) — most rigorous path |

### Dental Implants — FDA Status
- Most dental implants are **Class II** devices
- Cleared via **510(k)** (demonstrating substantial equivalence to a predicate device)
- Manufacturer must maintain: Device listing, establishment registration, MDR (Medical Device Reporting) for adverse events
- **Labeling requirements**: Indications for use, contraindications, warnings, IFU must be cleared

### Bone Graft Materials — FDA Status
- **Allografts**: Regulated as human cells/tissues under **21 CFR Part 1271** (HCT/P) — donor screening, processing, and labeling requirements
- **Xenografts and alloplasts**: Regulated as **Class II devices** — 510(k) required
- **Biologics** (BMP-2, rhPDGF): Regulated as biologics under FDA CBER/CDER — BLA or PLA required

### What Clearance ≠ Approval
- 510(k) clearance ≠ FDA approval; it means "substantially equivalent to a predicate device"
- Cleared devices can still be used off-label by clinicians (clinical judgment)
- Manufacturers cannot promote off-label uses in marketing materials


## ADA Standards

### Role of ADA in Device Standards
- ADA develops **ANSI/ADA Standards** for dental materials and devices
- These are voluntary consensus standards but widely adopted by manufacturers and regulators
- ADA's Standards Committee on Dental Products coordinates US standards with ISO

### Key ADA/ANSI Standards for Dental Devices
- **ADA Standard No. 48** — Dental implant assemblies (dimensions, materials, testing)
- **ANSI/ADA Specification No. 57** — Endosseous implants
- **ADA Technical Reports** on reprocessing burs, handpieces, and instruments

### ADA Clinical Evaluators (ACE) Program
- Independent product evaluations by practicing dentists
- ACE seal indicates product has been evaluated and met criteria
- Useful for product selection decisions; seen as third-party validation


## CDC Infection Control in Dental Settings

### Core Standard Precautions
Apply to ALL patients, every appointment:
- Hand hygiene (before glove, after glove removal, after patient contact)
- Personal protective equipment (gloves, mask, protective eyewear, gown)
- Respiratory hygiene/cough etiquette
- Safe injection practices (single-dose vials, no needle recap)
- Proper sharps handling and disposal

### Sterilization and Disinfection Hierarchy (Spaulding Classification)

| Category | Definition | Examples | Required Process |
|----------|-----------|---------|-----------------|
| **Critical** | Penetrates soft tissue or bone | Implant fixtures, surgical instruments, needles | **Sterilization** |
| **Semi-critical** | Contacts mucous membranes or non-intact skin | Mouth mirrors, impression trays, handpieces | **High-level disinfection or sterilization** |
| **Non-critical** | Contacts intact skin only | Blood pressure cuffs, X-ray equipment exterior | **Low/intermediate-level disinfection** |

### Handpiece Reprocessing
- Handpieces that enter the oral cavity are **semi-critical**
- CDC and ADA recommend **heat sterilization between every patient**
- Manufacturer IFU must be followed — not all handpieces tolerate autoclave cycles
- Important: External wiping/disinfection alone is insufficient; internal channels require heat sterilization

### Sterilization Methods
| Method | Temperature | Cycle Time | Best For |
|--------|------------|-----------|---------|
| **Steam autoclave (gravity)** | 121°C (250°F) | 15–30 min | Most wrapped instruments |
| **Steam autoclave (dynamic air removal/pre-vacuum)** | 132°C (270°F) | 3–10 min | Hollow instruments, handpieces |
| **Dry heat** | 160–170°C | 60–120 min | Heat-tolerant instruments; oils |
| **Chemical vapor** | 132°C | 20 min | Carbon steel instruments |


## Reprocessing Reusable Devices — Key Principles

### FDA Guidance on Reprocessing
- Manufacturers must provide **validated reprocessing instructions** in the IFU
- FDA expects validation testing demonstrating cleaning + sterilization achieves sterility assurance level (SAL) of 10⁻⁶
- For complex devices (narrow lumens, hinged joints), validation is especially critical

### The Critical Rule: Follow the IFU
The ADA has emphasized: **Manufacturer instructions guide purchase AND use**.
- If you cannot adequately clean and sterilize a device per the IFU, do not purchase that device
- "Cannot be sterilized" per IFU = single-use only; never attempt reprocessing
- Failure to follow IFU = potential patient safety risk, liability exposure, and regulatory violation

### Single-Use Devices (SUDs)
- Labeled single-use = must not be reprocessed
- Some practices attempt to reuse SUDs for cost savings — this is a regulatory and safety violation
- FDA has strict requirements for any entity that reprocesses labeled SUDs


## HIPAA and PHI in Dental Device Context

### Relevant When
- Practice management system integration (patient data flows through device/software)
- Digital imaging systems store patient CBCT/X-ray data
- API integrations connecting device data to patient records

### Core Requirements for Device Software
- **De-identify data** when possible for training, analytics, or non-clinical purposes
- **Business Associate Agreements (BAAs)** required with any software vendor handling PHI
- **Access controls**: Role-based access to patient imaging and records
- **Audit trails**: Log access to patient data

### For RealGUIDE / Digital Planning Platforms
- Patient data (name, CBCT, treatment plan) processed in cloud = PHI
- ZimVie/RealGUIDE must maintain BAA with practices
- Clinician responsibility: Use HIPAA-compliant export/sharing when sending cases to labs


## Adverse Event Reporting — MDR Requirements

### When Manufacturers Must Report to FDA
- Device malfunction that could cause serious injury if it recurred
- Device caused or contributed to serious injury or death
- Reporting timeframe: 30 days (5 days for urgent events)

### When Clinicians Should Report
- Voluntary MedWatch reporting for adverse events with any medical device
- Implant failure, unexpected complications, device malfunction
- Reporting supports FDA surveillance and post-market safety monitoring


## Key Regulatory Principles for Marketing

- **Never promote off-label uses** — Manufacturer marketing must stay within cleared indications
- **Clinical claims require substantiation** — Any efficacy or outcome claim needs supporting data
- **Fair balance** — For medical device advertising, risk information must be reasonably prominent
- **"FDA cleared" vs. "FDA approved"** — Use correct terminology; misuse is a regulatory violation
- **Testimonials** — Must be truthful and representative; cannot imply results typical if they're not

*Source types: FDA device regulations [FDA/CDC], ADA Standards Committee documentation [ADA/Standards], CDC infection control guidelines [FDA/CDC]*
