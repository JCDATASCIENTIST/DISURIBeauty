---
description: Implant Systems Reference
---

# Implant Systems — Clinical Reference

## Implant Anatomy Fundamentals

### Core Components (Every System)
- **Fixture/Implant body** — The titanium or zirconia screw placed in bone
- **Abutment** — Connector between implant and crown; defines emergence profile
- **Crown/Prosthesis** — The visible tooth restoration
- **Connection interface** — Where implant meets abutment; determines stability and prosthetic flexibility

### Key Design Variables
| Variable | Options | Clinical Significance |
|----------|---------|----------------------|
| **Connection type** | Internal hex, external hex, conical/Morse taper | Affects rotational stability, microgap, cement vs. screw retention |
| **Surface treatment** | SLA, SLActive, TiUnite, Osseospeed, ZimVie proprietary | Influences osseointegration speed and quality |
| **Thread design** | Tapered, parallel, hybrid | Affects primary stability in different bone densities |
| **Platform** | Narrow (≤3.3mm), regular (3.75-4.1mm), wide (≥4.5mm) | Dictates restorative options and soft tissue management |
| **Material** | Titanium (cp Ti or Ti-6Al-4V), Zirconia | Titanium = standard; Zirconia = metal-free aesthetic option |


## ZimVie Implant Portfolio

### Tapered Screw-Vent (TSV) — Flagship System
- **Connection**: Internal hex with 3° reverse taper
- **Key feature**: Consistent internal geometry across all diameters — one driver fits all
- **Thread design**: Dual-lead tapered thread for high primary stability
- **Bone applications**: Works well in D1–D3 bone; excellent for healed ridges
- **Diameter range**: 3.7mm, 4.7mm, 5.7mm, 6.0mm
- **Prosthetic flexibility**: Compatible with full range of ZimVie abutments and restorative components
- **Clinical indication**: Broad — single-tooth, multiple-unit, full-arch

### Full Arch / Trabecular Metal
- **Material**: Tantalum-based Trabecular Metal structure (not standard titanium)
- **Key feature**: Highly porous interconnected structure mimics cancellous bone morphology
- **Osseointegration**: Bone grows into the pores — mechanical interlock in addition to surface bonding
- **Primary use**: Full-arch rehabilitation (All-on-4/All-on-6 style), complex cases with compromised bone
- **Clinical advantage**: Can achieve high primary stability in softer bone types

### SwissPlus (Legacy)
- Tissue-level implant with external hex connection
- Long clinical track record in the European market
- Still supported but not primary line for new cases


## Competitive Implant Landscape

### Straumann Group
- **Bone Level Tapered (BLX)**: Highly condensing thread design; excellent primary stability in soft bone; dual-thread macro design
- **Tissue Level (TL)**: Classic Swiss implant; polished collar above bone; time-tested with 40+ years data
- **SLActive surface**: Hydrophilic surface chemistry — faster osseointegration (3–4 weeks vs 6–8 weeks)
- **Roxolid**: Ti-Zr alloy for narrow diameters without sacrificing strength
- **Key differentiator**: Surface science (SLActive), narrow diameter expertise (Roxolid), broad product family

### Nobel Biocare
- **NobelActive**: Self-tapping, aggressive thread; excellent in soft bone; used heavily in All-on-4
- **NobelReplace**: Tapered internal; versatile for most clinical situations
- **All-on-4 treatment concept**: Nobel's proprietary full-arch protocol with tilted posterior implants
- **Key differentiator**: All-on-4 concept ownership, Nobel Clinician app, strong digital integration (DTX Studio)

### Envista (Implant Direct + Nobel Biocare parent)
- **Implant Direct**: Value-tier implants with broad compatibility claims
- **Key differentiator**: Price point; multi-unit practice economics

### Dentsply Sirona — Implant Division
- **Ankylos**: Conical Morse taper connection; known for soft tissue stability and bone preservation
- **Xive**: Internal hex; established system with long history
- **Key differentiator**: Ankylos conical connection (1.5° taper) — strong clinical data on crestal bone preservation

### Osstem (Korean market leader, growing globally)
- **TS III, GS, MS systems**: Growing presence in US market
- **Key differentiator**: Value pricing with improving clinical evidence; strong in high-volume practices


## Connection Types Deep Dive

### Internal Hex
- Most common modern connection
- Hex inside the implant body receives abutment
- Prevents rotation; straightforward prosthetic workflow
- Used by: ZimVie TSV, Straumann BLX, Nobel NobelReplace

### Conical/Morse Taper
- Friction-fit between implant and abutment
- Minimizes microgap → better soft tissue response, less bone resorption
- More technique-sensitive seating
- Used by: Dentsply Ankylos (1.5°), Straumann tissue level, Bicon (11°)

### Platform Switching
- Using a smaller-diameter abutment on a wider-platform implant
- Moves the microgap away from the crestal bone
- Reduces crestal bone resorption over time
- Now standard practice in modern implant systems


## Primary Stability Considerations

Primary stability at placement predicts osseointegration success. Influenced by:

| Factor | Higher Stability | Lower Stability |
|--------|-----------------|-----------------|
| **Bone density** | D1 (cortical) | D4 (soft trabecular) |
| **Thread design** | Aggressive/condensing | Conservative |
| **Implant diameter** | Wider | Narrower |
| **Implant length** | Longer | Shorter |
| **Surgical technique** | Undersized drilling | Full-diameter drilling |

**ISQ (Implant Stability Quotient)**: Measured with resonance frequency analysis (Osstell). ISQ >70 = high stability; ISQ <60 = requires caution with loading protocol.

### Loading Protocols by Stability
- **Immediate loading** (same day): ISQ ≥70, D1-D2 bone, experienced surgeon
- **Early loading** (1–6 weeks): ISQ 60–70, good bone quality
- **Conventional loading** (8–16 weeks): Low ISQ, compromised bone, grafted sites


## Prosthetic Connections & Restorative Considerations

### Cement vs. Screw Retention
| | Cement-Retained | Screw-Retained |
|--|----------------|----------------|
| **Esthetics** | Better (no access hole) | Access hole visible |
| **Retrievability** | Difficult | Easy |
| **Cement excess risk** | Yes — peri-implant disease | None |
| **Current trend** | Declining | Increasing (preferred) |

### Emergence Profile
- The contour of the restoration from implant platform to crown margin
- Critical for soft tissue health and esthetics
- Custom abutments allow precise emergence profile design
- Stock abutments: faster/cheaper but less customizable


## Key Clinical Pearls

- **Bone quality matters more than quantity** — a narrow ridge that can accept a 3.7mm implant in D2 bone is preferable to a 5mm implant in D4 bone
- **Surface treatment ≠ magic** — primary stability at placement still predicts outcomes more than surface chemistry
- **Platform switching** is now a near-universal recommendation in modern implant dentistry
- **Tissue-level vs bone-level** is a philosophical debate with clinical data supporting both — case selection and surgeon preference are legitimate factors
- **Competition is fierce but difference is real** — Straumann SLActive, Nobel All-on-4 protocol, and ZimVie Trabecular Metal each offer genuinely differentiated clinical evidence

*Source types: ZimVie clinical documentation [Manufacturer], Nobel Biocare CE [Manufacturer], Straumann education [Manufacturer], independent clinical literature [Independent CE]*
