---
description: Clinical Workflows Reference
---

# Clinical Workflows — Treatment Planning, Patient Selection & Surgical Sequences

## The Foundational Principle: Prosthetically Driven Planning

All implant treatment planning begins with the end in mind — the final restoration. The crown position determines everything downstream: implant position, angulation, depth, diameter, abutment selection, and whether bone grafting is required.

**Never plan implant position based on bone availability alone.** Plan the ideal prosthetic outcome first, then determine what hard and soft tissue work is needed to support it.


## Patient Selection & Risk Assessment

### Absolute Contraindications
- **Recent radiation therapy to the jaw** — impaired vascularization and healing; osseointegration failure rates dramatically elevated
- **Active bisphosphonate therapy (IV)** — high MRONJ (Medication-Related Osteonecrosis of the Jaw) risk; typically contraindicates surgery
- **Active chemotherapy** — immune suppression, impaired healing
- **Uncontrolled systemic disease** — surgery should be deferred until stable

### Relative Contraindications (Manage, Don't Exclude)
| Factor | Clinical Consideration | Mitigation |
|--------|----------------------|------------|
| **Diabetes (uncontrolled HbA1c >8%)** | Impaired osseointegration, higher infection risk | Optimize glycemic control before surgery; HbA1c <7% target |
| **Smoking** | 2–3x higher implant failure rate; impaired wound healing | Cessation ideally 4+ weeks pre/post; informed consent |
| **Oral bisphosphonates (low-dose)** | Lower MRONJ risk than IV; still elevated vs. general population | Drug holiday discussion with prescribing MD; document |
| **Osteoporosis** | Affects bone quality, not necessarily implant success | Not a contraindication; assess local bone density |
| **Immunosuppression** | Impaired healing, infection susceptibility | Coordinate with MD; prophylactic antibiotics |
| **Bruxism / parafunction** | Mechanical overload on implants and prosthetics | Night guard; consider additional implants; inform patient |
| **Inadequate oral hygiene** | Peri-implantitis risk | Oral hygiene improvement required pre-treatment |

### Medical History Red Flags to Screen
- Anticoagulant therapy (Warfarin, novel agents) — assess INR; coordinate with prescribing MD for surgical planning
- Heart valve disease or joint replacement — antibiotic prophylaxis considerations (AHA guidelines)
- Bisphosphonate history (duration, dose, IV vs. oral, drug holiday status)
- Previous head/neck radiation (dose, field, time since)
- Current smoking status and pack-year history


## Comprehensive Treatment Planning Sequence

### Stage 1: Diagnostic Workup
1. **Medical and dental history** — Risk factor screening (above)
2. **Clinical examination** — Periodontal probing, caries assessment, occlusal evaluation, soft tissue quality/quantity
3. **Radiographic assessment**
   - Periapical X-rays: Initial screening
   - Panoramic (OPG): Overview of bone levels, anatomy, pathology
   - CBCT: Required for implant site assessment — bone height, width, density, vital structure proximity
4. **Study models / digital scans** — Assess occlusion, space, restorative options
5. **Diagnostic wax-up or digital setup** — Visualize the final restoration before any surgery

### Stage 2: Treatment Sequence Planning
After diagnosis, sequence treatment to address disease before reconstruction:

1. **Disease control phase** — Caries treatment, periodontal therapy, extractions of hopeless teeth
2. **Healing / re-evaluation** — Confirm stability before proceeding
3. **Pre-implant surgery** — Bone grafting, ridge augmentation if needed (may add 4–12 months)
4. **Implant placement** — After graft healing confirmed
5. **Osseointegration period** — 6–16 weeks depending on bone quality, graft status, loading protocol
6. **Prosthetic phase** — Abutment connection, impressions, final restoration delivery
7. **Maintenance** — Implant recall protocol (peri-implant health monitoring)

### Stage 3: Site-Specific Planning Checklist
For each implant site, confirm:
- [ ] Sufficient bone volume (height AND width) for chosen implant dimension
- [ ] Safe distance from inferior alveolar nerve (minimum 2mm recommended)
- [ ] Adequate distance from adjacent teeth (minimum 1.5mm recommended)
- [ ] Adequate distance from adjacent implants (minimum 3mm center-to-center)
- [ ] Keratinized tissue presence or plan for soft tissue management
- [ ] Occlusal forces assessed — loading protocol and prosthetic design confirmed


## Implant Placement Surgical Sequence

### Pre-Operative
- Informed consent documented
- Pre-operative antibiotics (if protocol calls for it — amoxicillin 2g or clindamycin 600mg 1hr pre-op)
- CBCT reviewed; surgical guide seated and verified (if guided surgery)
- Implant, abutment, and restorative components confirmed and available

### Surgical Sequence (Freehand)
1. **Local anesthesia** — Adequate block and infiltration; confirm profound anesthesia
2. **Incision** — Midcrestal or paracrestal depending on keratinized tissue management goals
3. **Full-thickness flap reflection** — Expose bone crest; protect papillae
4. **Bone assessment** — Confirm bone volume; identify any defects; reassess plan
5. **Sequential drilling** — Begin with round bur to mark position, then sequential pilot → intermediate → final diameter drills per manufacturer protocol
   - ZimVie TSV: Standard, under-preparation, or over-preparation protocol based on bone density
   - Cool with saline irrigation throughout — heat generation above 47°C causes bone necrosis
6. **Implant placement** — Seat to planned depth; check parallelism and angulation
7. **ISQ measurement** (optional) — Resonance frequency analysis to confirm primary stability
8. **Cover screw or healing abutment** — Based on loading protocol
9. **Bone grafting if indicated** — Fill any marginal gaps around implant (GBR simultaneous if primary stability confirmed)
10. **Flap closure** — Tension-free primary closure; interrupted or mattress sutures

### Guided Surgery Sequence
Same as above, with guides directing:
- Pilot drill position (tooth/mucosa/bone-supported guide)
- Sequential drill angulation and depth via guide sleeves
- Flapless approach if tissue anatomy allows

**Critical guided surgery steps**:
- Confirm guide fully seated before each drill (rocking = unstable guide = error)
- Verify drill depth against guide sleeve + stopper combination
- Confirm implant depth and angulation before closing


## Osseointegration & Healing Periods

### Conventional Healing Protocol
| Situation | Healing Time Before Loading |
|-----------|---------------------------|
| Fresh implant, D1-D2 bone | 6–8 weeks |
| Fresh implant, D3 bone | 8–12 weeks |
| Fresh implant, D4 bone | 12–16 weeks |
| Simultaneous GBR graft | 4–6 months |
| Post-sinus augmentation | 6–9 months (lateral); 3–4 months (crestal) |
| Post-ridge augmentation | 4–6 months before implant |

### Early and Immediate Loading
| Protocol | Timing | Requirements |
|----------|--------|-------------|
| **Immediate loading** | Restoration same day as placement | ISQ ≥70; D1-D2 bone; experienced surgeon; favorable occlusion |
| **Immediate temporization** | Temp crown same day, not in full occlusion | ISQ 60–70; acceptable risk profile |
| **Early loading** | 2–6 weeks | ISQ ≥65; good bone quality; provisional confirmation |
| **Conventional** | 6–16 weeks | Standard protocol; lower ISQ or grafted sites |


## Prosthetic Workflow Sequence

### Single-Tooth Restoration
1. Healing abutment placement (shape soft tissue emergence)
2. Soft tissue maturation: 4–8 weeks
3. Final impression (conventional or digital scan of implant)
4. Abutment selection (stock or custom)
5. Crown fabrication (lab or chairside CAD/CAM)
6. Crown delivery: Cement-retained or screw-retained
7. Occlusal adjustment and contacts verification

### Multiple-Unit/Bridge
- Same sequence as single; add: verify parallelism of all implants for shared abutment pathway
- Implant-supported bridge: requires accurate master impression or full-arch scan
- Verify passivity of metal framework before final cementation/seating

### Full-Arch Rehabilitation (All-on-4 Style)
1. Extract remaining teeth (or have already edentulous)
2. Place 4–6 implants (2 anterior axial + 2 posterior tilted, or 4–6 axial)
3. Confirm ISQ on all implants (immediate loading requires ≥70)
4. Connect multi-unit abutments
5. Fabricate immediate provisional (same day — acrylic temporary full arch)
6. Osseointegration period: 3–6 months with provisional in function
7. Final prosthesis fabrication: Milled titanium/zirconia bar, acrylic/zirconia hybrid, or full zirconia
8. Delivery of final restoration; occlusal verification


## Complication Management

### Intraoperative Complications

**Nerve proximity / paresthesia**
- Prevention: CBCT planning with 2mm minimum safety margin from IAN
- If patient reports electrical sensation during drilling: stop, reassess position
- Post-op paresthesia: Monitor; most resolve; consider CBCT to assess implant position relative to nerve

**Sinus perforation (lateral wall approach)**
- Small perforations (<5mm): Often manageable with collagen membrane patch
- Large perforations: Abort procedure; allow healing; reschedule with modified approach

**Implant primary stability failure**
- Poor ISQ at placement: Consider leaving as buried implant; extend healing time
- Implant mobility at placement: Remove; graft; reattempt after healing

### Post-Operative Complications

**Infection / peri-implant disease early**
- Presentation: Pain, swelling, suppuration within first 2 weeks
- Management: Irrigation, antibiotics; consider implant removal if severe
- Prevention: Adequate soft tissue closure; patient home care; prophylactic antibiotics (protocol-dependent)

**Peri-implantitis (late)**
- Presentation: Bone loss + inflammation around integrated implant; similar to periodontitis
- Staging: Mild (<25% bone loss), Moderate (25–50%), Severe (>50%)
- Treatment: Non-surgical debridement, local antibiotics → surgical debridement + regenerative therapy for advanced cases
- Risk factors: Smoking, history of periodontitis, poor oral hygiene, implant surface design

**Implant failure (loss of osseointegration)**
- Early failure: Before loading, during healing
- Late failure: After loading, functional implant
- Management: Remove; assess etiology; grafting + replacement after healing

**Prosthetic complications**
- Screw loosening: Verify torque; check occlusion
- Chipping (ceramic fracture): Assess occlusal forces; consider night guard
- Abutment fracture: Often requires implant removal if internal fracture


## Key Clinical Pearls

- **Patient selection > technique**: A well-selected patient with average surgical skill will usually outperform a poorly selected patient with expert surgical skill
- **Occlusion is often the afterthought that causes the most failures**: Verify immediately after crown delivery and at every recall
- **Peri-implantitis is the long-term threat**: The most important thing you can give a patient post-implant is a rigorous maintenance protocol
- **Staged vs. simultaneous is almost always a stability question**: If primary stability is good (ISQ ≥60), simultaneous grafting and implant placement is predictable
- **Documentation protects everyone**: Consent forms, ISQ records, CBCT pre-op reports, complication notes — essential for clinical and medicolegal reasons

*Source types: Nobel Biocare CE content [Manufacturer], ZimVie clinical education [Manufacturer], Glidewell clinical education [Independent CE], Implant Education Company CE [Independent CE], ADA clinical guidelines [ADA/Standards]*
