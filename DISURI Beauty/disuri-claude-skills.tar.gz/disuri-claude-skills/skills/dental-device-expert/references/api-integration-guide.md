---
description: API Integration Guide Reference
---

# Dental Device API Integration — Claude Skills Architecture Guide

## Overview

This document covers how to integrate dental manufacturer and practice-management APIs into Claude Skills via MCP/REST connectors. It is a **technical implementation guide**, separate from the clinical/marketing knowledge in other skill references.


## Step 0: Reality Check on What APIs Exist

Most major dental manufacturers (Straumann, Nobel Biocare, Dentsply Sirona, ZimVie) **do not expose public, generic REST APIs**. Before architecting anything, identify what you actually have.

The three realistic integration categories:

| API Type | Examples | Notes |
|----------|---------|-------|
| **Practice Management APIs** | Dentrix/Dentrix Ascend (Henry Schein One), OpenDental, cloud PMS platforms | Require authorized vendor exchange agreements |
| **Vendor/Distributor APIs** | Inventory, product catalogs, order status from distributors | More common than direct manufacturer APIs |
| **Internal APIs you control** | Normalized manufacturer catalog, education content, ZimVie product data | Build these as your own layer wrapping scraped/licensed data |

**Do not architect the integration until you have**: URL, auth method, HTTP methods, and payload schemas for each concrete endpoint.


## Step 1: Expose APIs via MCP / REST Connector

MCP (Model Context Protocol) is the bridge layer that exposes external APIs, databases, or services as tools Claude can call.

### Core Tool Definitions

Define tools that map 1:1 to HTTP requests:

```
get_implant_catalog(manufacturer, region)
  → Returns: product list, SKUs, specs

get_ifu(device_id)
  → Returns: instructions for use, reprocessing info

get_inventory(location_id, sku)
  → Returns: stock levels, availability

create_order(practice_id, items[])
  → Action: submits order to distributor/manufacturer
```

### REST Connector Pattern

The REST API Connector skill pattern lets Claude hit arbitrary web services while handling:
- Auth headers (Bearer tokens, API keys)
- Rate limits
- Retries
- Response parsing


## Step 2: Define Skills That Use Those Tools

### Skill 1: Product Lookup

```
Input:  { manufacturer_name, product_name_or_code }
Tools:  get_implant_catalog, get_ifu
Output: Normalized JSON with:
        - indications
        - connections
        - torque ranges
        - packaging options
        + short natural-language explanation
```

### Skill 2: Ordering / Reordering

```
Input:  { practice_id, location_id, device_or_sku, quantity }
Tools:  get_inventory, create_order
Logic:  1. Check stock
        2. Confirm substitutes if out of stock
        3. Place order OR suggest alternates
Output: Order confirmation or substitute recommendations
```

### Skill 3: Clinical Reference (Read-Only)

```
Input:  { device_id, question_type }
        question_type options: "reprocessing" | "components_compatibility" | "indications"
Tools:  get_ifu
Output: Summarized manufacturer labeling
        Always tagged: "not a substitute for IFU/regulations"
```

### Each Skill's Prompt Must:
- Describe when to call which tool
- Enforce safety constraints (no off-label advice; defer to clinician)
- Surface manufacturer name and labeling source in output (e.g., "According to Straumann IFU for BLX...")
- Use clinician-friendly language in explanations


## Step 3: Implementation Sequence

### 1. Create Tools via MCP / REST Connector
Configure in your MCP configuration:
- Endpoints (full URLs)
- HTTP methods (GET/POST)
- Auth headers: `Authorization: Bearer <token>`
- JSON schemas for request and response

### 2. Define Skills in Claude Console / Config
- Reference the tools by name
- Describe the use case
- Define input/output JSON schemas

### 3. Call Claude with Skills Enabled
From your backend, call the Claude API with:
- Skills enabled in request payload
- Skill name + user input

When Claude's reasoning triggers a tool call → MCP makes the HTTP request → response returns to Claude → Claude uses data to answer.

### 4. Auth, Tenancy & PHI Handling
- **Never expose API keys to the model** — keep manufacturer/PMS keys server-side
- **Scope practice-specific data** (orders, PHI) to tenant context
- **Design Skills to never log or echo** sensitive identifiers outside your system


## Step 4: Dental-Specific Design Tips

### Normalize Device Identifiers
Create a small internal mapping layer so variant naming resolves to canonical IDs:
- "BLX 3.75×10" → canonical_id: `STR-BLX-3.75-10`
- "TSX Ø4.1 10 mm" → canonical_id: `STR-TSX-4.1-10`
- "ZimVie 4.1 SP 10mm" → canonical_id: `ZMV-SP-4.1-10`

This prevents the skill from breaking on naming variations across sales reps, catalogs, and clinical notes.

### Separate Read vs. Transact
Gate these differently with different Skills and different auth scopes:

| Read-Only | Transactional |
|-----------|--------------|
| IFUs, specs, compatibility | Orders, returns, RMAs |
| Clinical reference | Inventory modification |
| Product lookup | Account changes |

### Always Surface Source in Output
Clinicians need to know the origin of guidance:
- ✅ `"According to ZimVie IFU for Tapered Screw-Vent implant..."`
- ✅ `"Per Straumann BLX Instructions for Use, revision 2023..."`
- ❌ `"The implant should be torqued to 35 Ncm."` (no source — unacceptable)


## ZimVie-Specific Implementation Notes

For a ZimVie-focused skill, the most practical internal APIs to build first:

1. **ZimVie Product Catalog API** — Wrap zimvie.com product data into a normalized internal endpoint; map implant lines (Tapered Screw-Vent, Full Arch), bone grafts (Puros, RegenerOss), and RealGUIDE software
2. **RealGUIDE Integration** — RealGUIDE has documented integration capabilities for surgical planning workflows; explore API access via ZimVie partnership channels
3. **Distributor Integration** — ZimVie distributes through major dental distributors (Henry Schein, Patterson); their APIs may be more accessible than a direct ZimVie API


## Quick Reference: MCP Tool Definition Template

```json
{
  "name": "get_ifu",
  "description": "Retrieve instructions for use and reprocessing information for a specific dental device",
  "input_schema": {
    "type": "object",
    "properties": {
      "device_id": {
        "type": "string",
        "description": "Canonical device identifier (e.g., ZMV-SP-4.1-10)"
      },
      "info_type": {
        "type": "string",
        "enum": ["reprocessing", "indications", "compatibility", "full"],
        "description": "Type of IFU information to retrieve"
      }
    },
    "required": ["device_id"]
  }
}
```


## Safety & Compliance Reminders

- Frame all clinical content as **educational**, never as a substitute for manufacturer IFUs, local regulations, or specialist consultation
- Implant and surgical guidance is especially sensitive — always defer to the treating clinician
- Any transactional tool (orders, returns) must have explicit user confirmation before execution
- PHI handling must comply with HIPAA if integrated with practice management systems
