---
description: Digital Dentistry Reference
---

# Digital Dentistry — RealGUIDE, Guided Surgery & Digital Workflows

## The Digital Implant Workflow

The modern digital implant workflow replaces manual planning and freehand surgery with data-driven precision at every stage:

```
CBCT scan → Digital impressions/scan → Treatment planning software 
→ Surgical guide design → Guided surgery → Digital restorative workflow
```

Each step reduces technique sensitivity, improves predictability, and creates a documented, repeatable process.


## ZimVie RealGUIDE Suite

RealGUIDE is ZimVie's cloud-based platform for digital implant planning and surgical guide design. It integrates diagnostic imaging, implant planning, and surgical guide fabrication into a single workflow.

### RealGUIDE Modules

**PLAN — Treatment Planning**
- Import and visualize CBCT (DICOM) data in 3D
- Plan implant positions in the context of actual bone anatomy
- Assess bone volume, density, vital structure proximity (nerves, sinuses, floor of mouth)
- Evaluate emergence angles and prosthetic-driven positioning
- Output: Approved implant plan with specified implant selection, position, angulation, depth

**APP — Digital Impressions Integration**
- Import intraoral scan data (STL files from any scanner — Trios, iTero, CEREC, etc.)
- Merge CBCT bone data with soft tissue/crown data
- Creates a comprehensive virtual patient — bone + gingiva + existing teeth + proposed restoration
- Essential for prosthetically-driven implant planning

**GUIDE — Surgical Guide Design**
- Design tooth-supported, mucosa-supported, or bone-supported surgical guides
- Define sleeve positions, guide thickness, pilot drill depths
- Export STL files for in-office printing or lab fabrication
- Supports stackable guide systems (pilot guide → sequential drilling guide)

**CAD — Restorative Design**
- Design abutments, crowns, and prosthetic components digitally
- Integration with milling centers and dental labs
- Closes the loop from diagnosis → surgery → final restoration in one platform

**FULL SUITE** — All modules bundled

### RealGUIDE Key Features
- **Cloud-based**: No local software installation; accessible from any device
- **Open architecture**: Works with CBCT from any manufacturer (Carestream, Planmeca, CBCT from Sirona, etc.); accepts STL from any intraoral scanner
- **Collaboration**: Case sharing between surgeon, restorative dentist, and dental lab within the platform
- **Version 6.0**: Current generation with enhanced planning tools and updated guide design capabilities


## CBCT (Cone Beam CT) Fundamentals

CBCT is the diagnostic foundation of digital implant planning. Without accurate 3D bone imaging, the rest of the digital workflow has no basis.

### What CBCT Shows
- 3D bone anatomy in three planes (axial, sagittal, coronal)
- Bone height, width, and density at the proposed implant site
- Proximity to vital structures: inferior alveolar nerve, mental foramen, maxillary sinus, nasopalatine canal
- Pathology: cysts, residual infections, root fragments

### CBCT Limitations
- Radiation dose (though significantly less than medical CT)
- Metal artifacts from existing restorations can obscure bone detail
- Does not show soft tissue anatomy (gingival thickness, keratinized tissue width) — requires clinical examination or intraoral scan

### CBCT + Intraoral Scan Fusion
Merging CBCT bone data with intraoral scan (digital impression) creates the complete virtual patient used in RealGUIDE planning. The merge aligns reference points between the two datasets.


## Surgical Guides

### Types by Support

**Tooth-supported guides**
- Most accurate — stable reference against existing teeth
- Best for partially edentulous cases with adjacent natural teeth
- Limitation: Cannot be used in fully edentulous arches without teeth for reference

**Mucosa-supported guides**
- Rests against soft tissue — less inherently stable
- Used in fully edentulous arches
- Requires precise tissue scan; can be affected by tissue compressibility
- Can be improved with anchor pins

**Bone-supported guides**
- Requires flap reflection to seat against bone
- Most stable in complex anatomies; sacrifices flap-less advantage

### Flapless vs. Open-Flap Guided Surgery
| | Flapless Guided | Open-Flap Guided |
|--|----------------|-----------------|
| **Patient experience** | Less morbidity, faster healing | More invasive |
| **Accuracy** | Depends entirely on guide stability | Can verify bone directly |
| **Visibility** | None — trust the plan | Can assess bone in real-time |
| **Requirements** | Thick gingiva, good bone volume, high-accuracy scan | Flexible — works in most cases |
| **Risk** | Errors are invisible until too late | Can adapt intraoperatively |

### Accuracy Expectations
- Guided surgery reduces positional error vs. freehand but does not eliminate it
- Published accuracy data: Mean deviation at implant apex ~1.0–1.5mm, angular deviation ~2–4°
- Always plan with safety margins around vital structures accounting for this tolerance


## Digital Workflow Integration Points

### Intraoral Scanners (IOS) — Compatible with RealGUIDE
- 3Shape TRIOS (most widely used globally)
- Align Technology iTero
- Dentsply Sirona CEREC Primescan
- GC Orthocloud, Carestream, others
- RealGUIDE accepts standard STL export from all major scanners

### CBCT Scanners — Compatible with RealGUIDE
- All major brands via DICOM export: Carestream CS 9600, Planmeca ProMax, Sirona Orthophos, Vatech, Instrumentarium
- Open DICOM format = broad compatibility

### Surgical Guide Fabrication Options
- **In-office 3D printing**: Requires a compatible printer and validated materials (FormLabs, Stratasys, etc.)
- **Lab fabrication**: Send STL to dental lab or milling center
- **Dedicated guide printing services**: Some companies offer mail-in STL → fabricated guide services

### Restorative Integration
- Final abutment and crown design from RealGUIDE CAD can flow directly to:
  - In-house CAD/CAM (CEREC, Roland mills)
  - Dental lab (export STL/DXF for milling)
  - Glidewell, full-service labs


## Competitive Digital Platforms

| Platform | Company | Key Features |
|---------|---------|-------------|
| **DTX Studio** | Nobel Biocare / Envista | Full integration with Nobel implant catalog; IOS + CBCT workflow; prosthetic planning |
| **coDiagnostiX** | Straumann Group (Dental Wings) | Industry-leading accuracy data; widely used in research; open to all implant systems |
| **Simplant** | Dentsply Sirona | Pioneer in guided surgery; cloud-based; multi-manufacturer support |
| **ImplantStudio** | 3Shape | IOS-first workflow; strong integration with 3Shape scanners |
| **RealGUIDE** | ZimVie | Cloud-based; open architecture; strong ZimVie implant integration; module-based pricing |

**RealGUIDE positioning**: Open architecture and cloud-based access are genuine differentiators. Most competing platforms have tighter integration with their own implant systems and may restrict cross-brand use.


## Key Clinical Pearls

- **"Prosthetically driven" is the non-negotiable principle**: Always plan the ideal crown position first, then work backward to determine implant position — not the other way around
- **The guide is only as good as the data**: A poorly taken CBCT or inaccurate intraoral scan produces an inaccurate guide regardless of software quality
- **Open vs. guided should be a clinical decision**: Experienced surgeons freehand with excellent results; guided surgery benefits less-experienced surgeons and complex cases more than high-volume experienced clinicians
- **Digital workflow ≠ no failures**: Guided surgery reduces certain errors but introduces new ones (scan errors, guide seating errors, drilling depth errors)
- **RealGUIDE's cloud architecture** means clinicians can collaborate across offices and with remote specialists without file transfer complexity

*Source types: ZimVie RealGUIDE documentation [Manufacturer], Nobel Biocare DTX Studio [Manufacturer], Straumann coDiagnostiX [Manufacturer], independent digital workflow clinical literature [Independent CE]*
