---
description: Device Categories Reference
---

# Device Categories — Equipment Selection, Maintenance & Clinical Decision-Making

## Overview

Beyond implants and regenerative products, dental practices rely on a broad ecosystem of equipment. This reference covers the major device categories, selection criteria, clinical considerations, and maintenance requirements — grounded in ADA evaluator reports and independent expert guidance.


## Handpieces

### Types of Handpieces

| Type | Speed Range | Primary Use | Key Consideration |
|------|------------|------------|------------------|
| **High-speed air turbine** | 300,000–450,000 RPM | Crown prep, cavity removal | High cutting efficiency; less tactile feedback |
| **Electric high-speed** | Up to 200,000 RPM | Crown prep, precision work | More torque and control vs. air turbine; quieter |
| **Low-speed / slow-speed** | 10,000–40,000 RPM | Polishing, endodontics, implant drilling | Multiple uses with different attachments |
| **Surgical handpiece** | 800–40,000 RPM | Implant osteotomy, bone surgery | Torque-controlled; requires saline irrigation |
| **Micro-motor** | Variable | Lab work, detailed intraoral work | Electric; precise control |

### Selection Criteria (ADA Clinical Evaluators Framework)
- **Cutting efficiency** — How quickly and cleanly does it cut without heat generation?
- **Noise and vibration** — Patient comfort and operator fatigue
- **Ergonomics** — Weight, grip diameter, balance
- **Durability** — Bearing quality; expected service life
- **Sterilization compatibility** — Must tolerate autoclave cycles per manufacturer IFU
- **Cost of ownership** — Initial purchase + maintenance + repair + head replacement frequency

### Handpiece Maintenance
- **Lubrication**: Per manufacturer protocol — some require lubrication before every sterilization cycle; some are maintenance-free (sealed bearings)
- **Sterilization**: Heat sterilization (autoclave) required between every patient
- **Inspection**: Check for head wobble, reduced cutting speed, air leaks, chuck failure
- **Service interval**: Many manufacturers recommend factory service every 6–12 months for high-use handpieces

### Reprocessing Rule for Handpieces
CDC and ADA classify handpieces as **semi-critical** devices. External wiping is insufficient — internal channels harbor blood and saliva from aspiration. **Autoclave sterilization between every patient is required.** Always follow manufacturer IFU for temperature limits, lubrication requirements, and cycle type compatibility.


## Dental Delivery Units (DDUs)

### What a Delivery Unit Is
The delivery unit is the hub of the operatory — it holds and delivers the handpieces, air/water syringe, suction, and other instruments to the operatory workflow. Configuration and ergonomics have significant impact on operator efficiency and patient experience.

### Configuration Types
| Configuration | Description | Best For |
|--------------|-------------|---------|
| **Over-patient (transthoracic)** | Unit positioned over patient's chest | Right-handed operators who work from patient's right |
| **Over-patient (rear delivery)** | Unit positioned above patient's head | 12 o'clock working position; minimizes cross-contamination reach |
| **Side delivery (cart-mounted)** | Unit on cart beside patient chair | Flexible positioning; suitable for multiple operator types |
| **Self-contained mobile cart** | Freestanding unit | Portability; satellite rooms |

### Key Selection Criteria (DENTALEZ Delivery Systems Framework)
- **Handpiece ports**: Number and type (standard vs. Midwest quick-connect vs. Kavo) — must match existing or planned handpieces
- **Fiber optic support**: Does the unit supply fiber optic illumination to handpieces?
- **Air/water syringe**: Quality of spray control; cleanability
- **Suction integration**: High-volume evacuator and saliva ejector capacity
- **Infection control design**: Smooth surfaces, minimal crevices, removable/cleanable components
- **Ergonomics**: Reach distance, swivel range, height adjustment
- **Reliability / uptime**: Downtime in a busy practice is expensive — brand reputation for service matters

### Maintenance Considerations
- **Waterline management**: Dental unit waterlines harbor biofilm; requires regular treatment (tablet or continuous treatments like ICX, Citrisil)
- **Suction line maintenance**: Daily cleaning to prevent buildup and odor
- **Filter checks**: Air and water filters have scheduled replacement intervals
- **Lubrication of moving parts**: Swivel arms and joints per manufacturer schedule

### Infection Control for DDUs
- All patient-contact surfaces (control buttons, syringe, handpiece hoses) require surface disinfection between patients or barrier protection
- Retraction valves (which pull fluid back into waterlines) should be anti-retraction models to prevent cross-contamination
- Flush waterlines 20–30 seconds at start of day and 20–30 seconds between patients per CDC guidelines


## Dental Imaging Systems

### Intraoral X-Ray Systems

| Technology | Sensor Type | Key Advantage | Key Limitation |
|-----------|------------|--------------|----------------|
| **Digital sensor (CCD/CMOS)** | Wired or wireless electronic sensor | Instant image; lower radiation vs. film | Sensor thickness/rigidity; initial cost |
| **Phosphor plate (PSP)** | Reusable flexible plate | Film-like flexibility; lower cost per sensor | Requires scanning step; plates degrade |
| **Conventional film** | Silver halide film | No capital investment | Processing time, chemicals, higher dose |

**Trend**: Digital sensors and PSP have largely replaced film in modern practices. Wireless sensors (Dexis, Carestream) are growing.

### Panoramic and CBCT Systems

**Panoramic (OPG)**
- 2D overview of entire dentition and jaw anatomy
- Lower dose than CBCT; good screening tool
- Limitations: Distortion, no 3D bone volume assessment, magnification variation

**CBCT (Cone Beam CT)**
- 3D volumetric imaging of jaw and craniofacial structures
- Essential for implant planning, complex extractions, endodontic evaluation, pathology assessment
- Variable field of view: Limited (small — single arch) to full (craniofacial)
- Dose varies widely by FOV and resolution settings

**CBCT Selection Criteria**
- **Field of view options**: Small FOV for implant sites vs. full FOV for orthodontics/pathology
- **Resolution settings**: High resolution = more detail + higher dose; clinical application determines acceptable trade-off
- **Artifact management**: Metal artifact reduction algorithms matter in restoration-heavy patients
- **Software compatibility**: DICOM export compatibility with planning software (RealGUIDE, coDiagnostiX, etc.)
- **Footprint and installation requirements**: Weight, power, room shielding requirements
- **Major brands**: Carestream (CS 9600), Planmeca (ProMax), Dentsply Sirona (Orthophos), Vatech, Instrumentarium

### Intraoral Scanners (IOS)

Intraoral scanners capture digital impressions — replacing traditional PVS/alginate impressions for most prosthetic and implant restorative workflows.

**Key Selection Criteria**
- **Scan accuracy**: Measured by trueness (vs. reference standard) and precision (reproducibility)
- **Full-arch scan accuracy**: Accuracy degrades with scan length — full-arch implant bars require highly accurate systems
- **Scan speed**: Clinical efficiency
- **Ergonomics**: Wand size, weight, tip design
- **Workflow integration**: Compatibility with lab software, CAD/CAM systems, planning software (RealGUIDE)
- **Open vs. closed ecosystem**: Open = exports STL to any system; closed = proprietary formats may limit workflow

**Major IOS Brands**
| Brand | System | Key Feature |
|-------|--------|------------|
| 3Shape | TRIOS 5 | Industry-leading accuracy data; open file format |
| Align | iTero Lumina/Element | Strong Invisalign integration; good prosthetic workflow |
| Dentsply Sirona | Primescan 2 | Fast scan speed; native CEREC integration |
| Carestream | CS 3800 | Good value positioning |
| Medit | i700 | Strong value/accuracy ratio; open ecosystem |


## Sterilization Equipment

### Autoclave (Steam Sterilizer)

The autoclave is the cornerstone of infection control in any dental practice. All critical and most semi-critical items require sterilization.

**Types**
| Type | Mechanism | Best For |
|------|----------|---------|
| **Gravity displacement** | Steam displaces air by gravity | Unwrapped instruments; simple loads |
| **Pre-vacuum / dynamic air removal (Class B)** | Vacuum removes air before steam | Hollow instruments, handpieces, wrapped packs |
| **Flash/rapid** | High temperature short cycle | Unwrapped instruments urgent use |

**Class B autoclave** is the European standard (EN 13060) and recommended for hollow lumen devices (handpieces). US standard (FDA cleared) autoclaves vary; check if the unit is validated for hollow loads.

**Key Selection Criteria**
- **Chamber size**: Match to practice volume and largest instrument sets
- **Cycle time**: Fast cycles improve instrument turnover in busy practices
- **Validation and documentation**: Automatic cycle logging, biological indicator integration, print/export capability
- **Class B capability**: Required for hollow instrument sterilization (handpieces)
- **Water quality requirements**: Many autoclaves require distilled water; check specifications

**Monitoring Requirements (CDC)**
- **Mechanical**: Check pressure, temperature, time gauges on every cycle
- **Chemical**: Chemical indicators inside and outside packs on every cycle
- **Biological (spore testing)**: At least weekly with mail-in or in-office readers; daily is best practice
- **Documentation**: Log every cycle; retain records

### Ultrasonic Cleaners
- Pre-sterilization cleaning step — removes gross bioburden before packaging and sterilization
- Transducer frequency creates cavitation bubbles that scrub instrument surfaces
- Must be followed by rinse and dry before sterilization
- Never substitute for sterilization — cleaning alone does not sterilize

### Instrument Washers / Washer-Disinfectors
- Automated cleaning + thermal disinfection cycle
- Reduces manual handling and sharps exposure
- Validated cleaning is increasingly expected in modern infection control programs


## Equipment Decision Framework

When helping a practice evaluate equipment purchases, surface these questions:

1. **What problem does it solve?** — Is this a genuine clinical need or a technology upgrade?
2. **What's the total cost of ownership?** — Purchase price + installation + training + maintenance + consumables + service contracts
3. **What's the integration impact?** — Does it require new software, new workflows, new staff training?
4. **What's the downtime risk?** — If the equipment fails, what's the practice impact? What's the service network?
5. **Does it meet regulatory requirements?** — FDA cleared, ADA/ISO standards compliance, sterilization compatibility?
6. **What do independent evaluators say?** — ADA ACE reports, Clinicians Report ratings, peer-reviewed comparison studies

### Vendor Selection Beyond the Product
- **Service network**: Local vs. national; response time commitments
- **Training support**: Initial training; ongoing education; staff turnover coverage
- **Parts availability**: Proprietary vs. standard parts; how long will parts be available?
- **Distributor relationship**: Henry Schein, Patterson, Benco — purchasing through a distributor vs. direct often affects service terms


## Key Clinical Pearls

- **The handpiece is only as good as its maintenance**: A $3,000 high-speed handpiece with poor lubrication and infrequent sterilization service will underperform a $800 handpiece properly maintained
- **Waterline contamination is often overlooked**: Many practices treat waterlines inadequately; biofilm in lines is a real infection control issue
- **CBCT dose optimization matters**: Use the smallest FOV and lowest dose settings that answer the clinical question — "resolution for every case" is not justified
- **IOS full-arch accuracy**: Not all scanners are equal for full-arch implant work; smaller FOV (single quadrant) scans are universally accurate; full arch diverges significantly between systems
- **Sterilization documentation isn't optional**: Cycle logs, biological indicator records, and chemical indicator results are required for regulatory compliance and protect the practice legally

*Source types: DENTALEZ delivery systems clinical guide [Manufacturer], ADA Clinical Evaluators reports [ADA/Standards], CDC infection control guidelines for dental settings [FDA/CDC], Curate Studios dental equipment guide [Independent CE], Clinicians Report equipment ratings [Independent CE]*
