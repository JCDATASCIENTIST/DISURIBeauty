---
description: Regenerative Products Reference
---

# Regenerative Products — Bone Grafting, Membranes & Biologics

## Graft Material Categories

### The Four Graft Types

| Type | Source | Examples | Key Advantage | Key Limitation |
|------|--------|----------|---------------|----------------|
| **Allograft** | Human donor bone | Puros, RegenerOss, RegenaVate | Osteoinductive potential; familiar handling | Processing variability; batch differences |
| **Xenograft** | Animal bone (bovine) | Endobon, Bio-Oss | Slow resorption = long-term volume; excellent scaffold | Not osteoinductive; requires host cells |
| **Alloplast** | Synthetic materials | IngeniOs (HA/TCP), Biotivity A/C Plus | Unlimited supply; no disease risk; customizable | Osteoconductive only |
| **Autograft** | Patient's own bone | Chin, ramus, calvarium | Gold standard — all three osteogenic properties | Second surgical site; limited volume |

### The Osteogenic Triad
Every graft needs all three for predictable bone regeneration:
- **Osteogenic cells** — Living cells that form bone (autograft only)
- **Osteoinductive signals** — Growth factors (BMPs) that recruit bone-forming cells (allografts retain some; xenografts/alloplasts have none)
- **Osteoconductive scaffold** — Physical matrix for bone to grow into (all graft types provide this)


## ZimVie Regenerative Portfolio

### Allografts (Human Donor)

**Puros** — Flagship allograft line, processed via Tutoplast technology
- Processing: Solvent/detergent removes lipids, viruses, and antigenicity while preserving collagen scaffold and residual growth factors
- Forms: Cancellous chips, cortical chips, cortical/cancellous blend, demineralized bone matrix (DBM)
- Key use: Socket preservation, sinus lifts, ridge augmentation, defect fill
- Differentiator: Tutoplast has decades of safety data; retained collagen aids handling and healing

**RegenerOss** — Particulate allograft
- More accessible price point in the allograft category
- Cortical and cancellous options
- Indicated for similar applications as Puros

**RegenaVate** — Demineralized allograft
- Demineralization exposes BMPs → greater osteoinductive potential vs. non-demineralized allografts
- Used when osteoinduction is the priority: challenging defects, compromised healing sites, staged augmentation

### Xenograft (Bovine)

**Endobon** — Sintered bovine hydroxyapatite
- Processing: High-temperature sintering burns off all organic components → pure mineral scaffold
- Resorption: Very slow (years) — maintains volume long-term
- Key advantage: Outstanding scaffold for sinus augmentation and large ridge defects where long-term volume maintenance is critical
- Differentiator: Sintering ensures complete deproteinization — minimal immune response

### Alloplasts (Synthetic)

**IngeniOs** — Biphasic calcium phosphate (HA/TCP blend)
- Hydroxyapatite (HA): Slow-resorbing; long-term scaffold
- Tricalcium phosphate (TCP): Faster-resorbing; replaced by new bone
- Customizable HA/TCP ratio for different clinical resorption timelines
- Unlimited supply; no donor or disease concerns

**Biotivity A/C Plus** — Bioactive glass
- Silicon-based ceramic that bonds to both bone and soft tissue
- Releases ions (Si, Ca, P) that stimulate bone cell activity
- Unique property: Also bonds to soft tissue (periosteum, gingiva) — useful at surgical margins


## ZimVie Membrane Portfolio

### Purpose
Membranes create a protected space for bone regeneration by excluding fast-growing soft tissue cells while slower-growing osteogenic cells populate the graft.
- **GBR** = Guided Bone Regeneration (implant site defects, ridge augmentation)
- **GTR** = Guided Tissue Regeneration (around teeth/roots — periodontal applications)

### Membrane Products

**OsseoGuard** — Resorbable bovine collagen membrane
- Resorption: ~16–24 weeks
- Key use: Most ridge augmentation, socket preservation, sinus procedures
- Advantage: No second surgery for removal; collagen scaffold supports tissue ingrowth

**BioMend / BioMend Extend** — Resorbable collagen membrane
- BioMend: ~8 weeks resorption
- BioMend Extend: ~18 weeks resorption (for longer healing procedures)
- Processed via Tutoplast — consistent safety profile with Puros allografts

**CopiOs** — Pericardium membrane (bovine)
- Dense, strong membrane with excellent space-maintenance for larger defects
- Longer handling time allows precise surgical positioning

**d-PTFE membranes** — Non-resorbable dense PTFE
- Requires second surgery for removal
- Used when extended space maintenance is critical
- Key advantage: Can be intentionally exposed without infection risk (unlike ePTFE)

### Resorbable vs. Non-Resorbable Decision

| | Resorbable | Non-Resorbable |
|--|-----------|----------------|
| **Second surgery** | Not required | Required for removal |
| **Space maintenance** | Moderate | Superior |
| **Exposure risk** | Compromises healing | d-PTFE tolerates exposure |
| **Best for** | Most routine GBR/GTR | Large defects, complex anatomy |


## Clinical Applications

### Socket Preservation (Alveolar Ridge Preservation)
**Goal**: Minimize ridge resorption after extraction before implant placement

**Protocol**:
1. Atraumatic extraction
2. Debride socket walls
3. Fill with particulate graft (Puros cancellous, RegenerOss, or Endobon)
4. Cover with membrane (OsseoGuard, BioMend) or collagen plug
5. Primary closure

**Timing to implant**: 3–6 months depending on graft material and patient factors

**Evidence**: Socket preservation reduces horizontal bone loss by ~1.5–2mm and vertical loss by ~1mm vs. unassisted healing [Independent CE]

### Sinus Augmentation (Sinus Lift)

**Lateral window approach** (standard; for gains >5mm):
1. Create lateral window in sinus wall
2. Carefully elevate Schneiderian membrane
3. Pack graft material (Endobon, Puros, or blend)
4. Cover window with OsseoGuard or CopiOs
5. Allow 6–9 months healing before implant placement

**Crestal/osteotome approach** (for smaller gains ≤3–4mm):
- Internal elevation via implant osteotomy
- Faster, less invasive; limited volume gain

**Graft selection for sinus**:
- Endobon preferred for long-term volume maintenance (slow resorption during long healing)
- Puros cortical/cancellous blend adds osteoinductive boost
- Many clinicians use a 50/50 blend: xenograft + allograft

### Ridge Augmentation

**Horizontal deficiency (narrow ridge)**:
- GBR with particulate graft + membrane is gold standard for moderate defects
- Block grafts (autograft or processed allograft) for larger defects
- Tent-screw technique ensures stable membrane position without collapse

**Vertical deficiency (short ridge)**:
- Most challenging; highest complication rate
- Options: distraction osteogenesis, block graft, or GBR with rigid membrane support
- Often requires staged approach; experienced surgeon essential


## Biological Adjuncts (Non-ZimVie but Clinically Relevant)

**Platelet-Rich Fibrin (PRF / L-PRF)**
- Patient's own blood centrifuged to concentrate platelets and growth factors
- Used as membrane, mixed with graft, or applied to extraction sockets
- Provides autologous growth factors (PDGF, VEGF, TGF-β) — commonly used alongside ZimVie graft materials

**rhBMP-2 (INFUSE — Medtronic)**
- Recombinant human BMP-2; powerful osteoinduction
- FDA-approved for sinus augmentation and alveolar ridge augmentation
- Used in complex cases; significant cost


## Key Clinical Pearls

- **Match graft to goal**: Volume maintenance (large sinus, ridge) → slow-resorbing Endobon. Osteoinduction priority (challenging cases) → demineralized RegenaVate. Routine socket preservation → Puros cancellous.
- **Match membrane to space-maintenance requirement**: Small defects → BioMend. Large/complex defects → CopiOs or d-PTFE.
- **Contamination kills regeneration**: Blood clot must form inside graft space; no tension on flap; membrane must remain covered.
- **Patient risk factors**: Smoking, diabetes, bisphosphonates (MRONJ risk), and immunosuppression all significantly affect regenerative outcomes — screen before surgery.
- **Staged vs. simultaneous**: Simultaneous graft + implant possible with good primary stability (ISQ ≥60); otherwise stage the procedure.

*Source types: ZimVie biomaterials clinical documentation [Manufacturer], Tutoplast processing documentation [Manufacturer], independent clinical literature [Independent CE], ADA clinical evaluator reports [ADA/Standards]*
