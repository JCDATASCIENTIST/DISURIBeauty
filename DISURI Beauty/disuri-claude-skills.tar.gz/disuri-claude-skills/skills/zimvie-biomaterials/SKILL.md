---
name: zimvie-biomaterials
description: Generate FDA-compliant marketing content for ZimVie's dental biomaterials portfolio using ONLY approved source-document language. Covers Puros, RegenerOss, RegenaVate, Endobon, IngeniOs, Biotivity A/C Plus, OsseoGuard, BioMend, CopiOs, Puros Dermis, d-PTFE membranes, wound dressings, and instrumentation. Use for any marketing material, sales collateral, social post, email, ad copy, landing page, product description, or competitive positioning for ZimVie biomaterials. Triggers on biomaterials, Puros, Endobon, OsseoGuard, BioMend, CopiOs, Biotivity, RegenerOss, RegenaVate, IngeniOs, Safescraper, allograft, xenograft, alloplast, bone graft, membrane, GBR, GTR, sinus lift, ridge augmentation, socket preservation, pericardium, dermis, d-PTFE, growth factors, Tutoplast, Cancelle SP, or any ZimVie dental regenerative product.
---

# ZimVie Biomaterials Marketing Content Skill

Generate FDA-compliant marketing content for ZimVie's comprehensive biomaterials portfolio targeting dental professionals. This skill enforces a strict source-document-only approach to comply with FDA and regulatory requirements for medical device marketing.

## THE CARDINAL RULE: Source-Document-Only Content

Because ZimVie operates in a regulated medical device environment, every product claim, clinical statistic, benefit statement, and competitive comparison used in marketing materials must come directly from the approved source documents in this skill's `references/` folder. This isn't a style preference — it's a regulatory requirement. Making unsupported claims about medical devices can trigger FDA enforcement actions.

**What this means in practice:**

- Read the relevant reference file(s) before writing any content
- Every clinical claim, product benefit, or competitive statement must trace back to specific language in the reference files
- You may recombine, shorten, and rearrange approved language to fit different formats (social post vs. email vs. landing page)
- You must NOT invent new clinical claims, fabricate statistics, or make comparative superiority statements not found in the source documents
- If you're unsure whether a claim is in the source documents, err on the side of leaving it out and flagging it for regulatory review
- When citing clinical evidence, use the exact citation format from the source documents

**When asked to create content for a product, always:**
1. Read the relevant reference file(s) first
2. Identify approved claims, benefits, and evidence
3. Compose the deliverable using only that approved language
4. Include proper citations and disclaimers
5. Flag any statement you composed that isn't directly traceable to a source document

## Brand Positioning

ZimVie is well known for its extensive portfolio of dental biomaterials for hard- and soft-tissue grafting, including allografts, xenografts, and synthetic bone substitutes; barrier membranes; and dental wound dressings.

**Tagline:** Trusted Clinical Solutions. Restoring Daily Life.™

## Cross-Reference: Other ZimVie Skills

This skill works together with other ZimVie skills. Before generating content, also read the relevant companion skill(s):

- **`zimvie-brand-guidelines`** — For logo usage, color palette (HEX/RGB/PMS), typography (Soleil/Palatino), visual elements, and brand voice. Read this whenever creating branded deliverables.
- **`zimvie-campaign-copywriting`** — For HOOK, FAB, and PAS copywriting frameworks, channel-specific guidelines (LinkedIn, Instagram, email, display ads), UTM tracking conventions, and the copy checklist. Read this whenever writing marketing copy.
- **`zimvie-hubspot-emails`** — For HubSpot email template structure and HubL code. Read this when creating email campaigns.
- **`zimvie-hubspot-landing-pages`** — For HubSpot landing page templates. Read this when creating landing pages.
- **`zimvie-content-derivation`** — For repurposing video content into multi-channel assets. Read this when deriving content from video.
- **`zimvie-product-launch`** — For full product launch orchestration. Read this when planning a launch campaign.

## Source Document Reference Files

The knowledge base is organized into these reference files. Read the relevant file(s) before creating any content:

| Reference File | What It Covers | When to Read |
|----------------|----------------|--------------|
| `references/products.md` | Full product catalog with item numbers, clinical evidence, indications, and specifications for all biomaterials | Always read for any product-related content |
| `references/biotivity-ac-plus.md` | Biotivity A/C Plus Membrane: growth factors, triple-layer structure, competitive landscape, handling VOC, sizing, and indications | Read for any Biotivity, amnion/chorion, placental membrane, or growth factor membrane content |
| `references/regeneross-bone-graft-plug.md` | RegenerOss Bone Graft Plug: key benefits, composition, sizing, pricing, and approved tagline | Read for any bone graft plug or socket preservation content |
| `references/portfolio-overview-2026.md` | Complete 2026 portfolio overview including new 0.25cc Puros launch, RegenerOss family, RegenaVate DBM, xenografts, alloplasts, all membrane types, Puros Dermis, non-resorbable membranes, wound dressings, and instrumentation | Read for portfolio-wide content, new product launches, or any product not fully covered in other reference files |

## Key Differentiators by Product Family

### Tutoplast® Process (Puros Family)
The proprietary Tutoplast Tissue Sterilization Process is ZimVie's primary competitive advantage for Puros allografts. Read `references/portfolio-overview-2026.md` for the full approved process description and claims, including the 11 million implant / zero infection track record.

### Biotivity™ A/C Plus Membrane
Growth factor charged placental membrane. Key differentiators: triple-layer structure (never delaminated), no antibiotics, over 250+ growth factors. Read `references/biotivity-ac-plus.md` for the complete approved messaging including competitive comparisons against BioXclude, AmnioExcite, Mem-Lok Amnio, and Sterishield II.

### RegenerOss® Bone Graft Plug
Easy-to-use socket preservation solution. Key differentiator: plug-shaped form at an economical price point. Read `references/regeneross-bone-graft-plug.md` for the approved "Socket Preservation Made Simple" messaging.

### Puros® Dermis
Soft tissue alternative to autogenous grafts with only 16% volume loss. Read `references/portfolio-overview-2026.md` for the approved competitive claims against Geistlich Fibro-Gide.

### New Product Launch: Puros® 0.25cc
New small-volume option for cancellous, cortical, and CC mix. Read `references/portfolio-overview-2026.md` for approved launch messaging and clinical applications.

## Product Categories Quick Reference

### Bone Grafts — Allografts (Puros Family)
- **Puros Cancellous** — Osteoconductive scaffold, fast remodeling, 127% more vital bone vs xenograft
- **Puros Cortical** — Space maintenance, slow-resorbing, volume enhancement
- **Puros Cortico-Cancellous** — Pre-mixed 70/30 blend, best of both
- **Puros Ci** — Min + Demin mix, twice as inductive, conductive scaffold + inductive boost
- **Puros DBM Particulate** — Osteoinductive boost, Cancelle SP processed
- **Puros Custom Block** — Eliminates autograft harvest, horizontal/vertical augmentation
- **Puros J-Block** — Single tooth defects, viable alternative to autogenous block grafting

### Bone Grafts — Allografts (RegenerOss Family)
- **RegenerOss Cancellous/Cortical/CC** — Full range 0.25–4.0cc, Cancelle SP processed
- **RegenerOss Min/Demin Mix** — 70/30 mineralized/demineralized cortical
- **RegenerOss Allograft Putty** — 100% allograft (no fillers/carriers), moldable syringe
- **RegenerOss Bone Graft Plug** — Socket preservation made simple, 80/20 carbonate apatite/collagen

### Bone Grafts — DBM
- **RegenaVate Formable DBM (RT)** — Formable at 45°C, solid at body temp, gel/paste/putty
- **RegenaVate Formable DBM (Frozen)** — Block form, 5-year shelf life

### Bone Grafts — Xenografts
- **Endobon Xenograft** — Bovine, fully deproteinated, essentially non-resorbable, volume stability
- **RegenerOss Xenograft** — Porcine carbonate apatite, highly porous

### Bone Grafts — Alloplasts
- **RegenerOss Bone Graft Plug** — Composite graft plug for extraction sockets
- **RegenerOss Synthetic** — Moldable composite plug
- **IngeniOs β-TCP** — Bioactive, resorbable, 75% interconnected porosity
- **IngeniOs HA** — 100% non-biologic, non-resorbable, pure-phase hydroxyapatite

### Resorbable Barrier Membranes
- **Biotivity A/C Plus** — Placental triple-layer, growth factors, 8-12 weeks
- **Puros Pericardium** — Allograft, multi-directional strength, 8-24 weeks
- **CopiOs Pericardium** — Bovine xenograft, 8-24 weeks
- **BioMend** — Rigid scaffold, bovine tendon, 8 weeks
- **BioMend Extend** — Rigid scaffold, bovine tendon, 18 weeks
- **Socket Repair Membrane** — Flapless, bovine Achilles, 28-36 weeks, can be left exposed
- **CopiOs Extend** — Porcine dermis, conformable, 6-9 months, performs without primary closure
- **OsseoGuard** — Bovine tendon, rigid, 6-9 months, high suture pull-out strength
- **OsseoGuard Flex** — Bovine dermis, conformable, 6-9 months, can be left exposed

### Non-Resorbable Membranes
- **OsseoGuard d-PTFE Textured** — Impervious to bacteria, textured stabilization
- **OsseoGuard d-PTFE Non-Textured** — Easier removal
- **OsseoGuard d-PTFE Titanium-Reinforced** — 1-3 wall defects, vertical/horizontal augmentation
- **OsseoGuard Titanium-Mesh** — Ultra-thin 0.2mm, nitride-coated

### Soft Tissue
- **Puros Dermis (Thin/Thick)** — Acellular dermal matrix, only 16% volume loss

### Wound Dressings
- **Collagen Plug/Tape/Patch** — Porcine Type I collagen, <30 day resorption

### Sutures
- **OsseoGuard PTFE Sutures** — Medical grade PTFE, bacteria-impervious

### Instruments
- **Safescraper Twist** — Cortical bone collector, up to 5cc
- **Sinus Lateral Approach Kit** — 8.5mm window, side-cutting
- **Sinus Crestal Approach Kit** — 4.4mm last drill, depth control
- **Screw Fixation Kit** — 3.5-17mm screws, self-drilling

## Procedure-to-Product Quick Reference

| Procedure | Recommended Products |
|-----------|---------------------|
| Sinus Augmentation | Puros Cancellous, Puros Cortical, Puros CC Mix, Puros Ci, Endobon, RegenerOss |
| Socket Preservation | Puros Cancellous, RegenerOss Bone Graft Plug, Socket Repair Membrane, Collagen Plug, Biotivity A/C Plus |
| Ridge Augmentation (Horizontal) | Puros Bone Block, Puros Cortical, OsseoGuard Flex, d-PTFE Ti-Reinforced |
| Ridge Augmentation (Vertical) | Puros Bone Block, Puros CC Mix, Puros Pericardium, d-PTFE Ti-Reinforced, RegenaVate |
| GBR / Implant Dehiscence | BioMend Extend, OsseoGuard, Puros Cancellous, CopiOs Extend |
| Soft Tissue Augmentation | Puros Dermis (Thin or Thick) |
| Periodontal Defects | Puros Cancellous (0.25cc), RegenerOss, BioMend, Biotivity A/C Plus |
| Peri-implant Defects | Puros Cancellous (0.25cc), RegenerOss, Biotivity A/C Plus |
| Flapless Extraction | Socket Repair Membrane, RegenerOss Bone Graft Plug |
| Sinus Membrane Perforation | Biotivity A/C Plus (8x8 or 12x12mm) |

## Persona Targeting

Reference ZimVie personas when tailoring content:

| Persona | Archetype | Content Angle |
|---------|-----------|---------------|
| Dr. Chen | Oral Surgeon | Efficiency, predictable outcomes, volume cases |
| Dr. Johnson | Evidence-Driven | Clinical studies, histomorphometric data, peer-reviewed citations |
| Dr. Patel | Innovation-Seeker | Tutoplast technology, Biotivity growth factors, latest processing advances |
| Dr. Williams | Patient-Centered | Patient comfort, healing time, aesthetic outcomes |
| Dr. Torres | Detail-Focused | Item numbers, sizes, IFU specs, technique sensitivity |
| Dr. Reynolds | Efficiency-Focused | Shelf life, storage, hydration time, OR efficiency |

## Content Creation Workflow

1. **Identify product(s)** — Which biomaterial is the focus?
2. **Read the reference file(s)** — Pull up the relevant source document(s) from `references/`
3. **Select procedure context** — Sinus lift, socket preservation, GBR, etc.
4. **Choose persona** — Tailor messaging to archetype
5. **Read companion skills** — Pull in brand guidelines and copywriting frameworks as needed
6. **Compose using approved language only** — Recombine, shorten, rearrange source-document language to fit the deliverable format
7. **Add proper citations** — Use exact citation format from source documents
8. **Apply FDA compliance** — Add required disclaimers
9. **Include CTA** — Use standard ZimVie CTAs
10. **Source-check** — Review every claim to confirm it traces to a reference file. Flag anything that doesn't.

## FDA Compliance Requirements

**CRITICAL:** All biomaterials content must follow medical device marketing regulations.

### Required Practices
- Reference IFU (Instructions for Use) for all clinical claims
- Use footnote citations for clinical evidence (format: superscript numbers)
- Include "Consult IFU for complete indications, contraindications, warnings, and precautions"
- Do not make comparative superiority claims without substantiation from source documents
- Avoid absolute language ("always," "never," "guaranteed")
- Every clinical stat must have its matching citation from the reference files

### Approved Claim Language Patterns
- "Clinically successful in procedures for..." (with citation)
- "Clinical evidence shows..." (with citation)
- "In a study by [Author] et al., [specific finding]" (with full citation)
- "[Product] has been shown to..." (with citation)

### Disclaimer Template
```
For professional use only. Please refer to the Instructions for Use for complete
product information, including indications, contraindications, warnings, precautions,
and adverse effects. [Product] is indicated for [specific indications per IFU].
```

## Standard CTAs

Include one of these in marketing content:

**Need Help?**
> For any questions, concerns, or support, our dedicated team is here to assist you.

**Explore Our Education**
> Learn more in our dental education platform for in-person or virtual programs.

**Order Online With Ease**
> Use our online platform for quick order placement, returns, and complaints.

**Contact:** www.ZimVie.com/dental

## Output Formats

### Social Media Posts
- LinkedIn: Professional tone, clinical evidence focus, 150-300 words
- Facebook/Instagram: Patient outcome focus, visual-first, 50-150 words
- Include product image callout when relevant

### Email Copy
- Subject line: Benefit-driven, <50 characters
- Body: Problem → Solution → Evidence → CTA structure
- Always include unsubscribe and compliance footer

### Product Descriptions
- Lead with clinical benefit, not features
- Include key differentiator (Tutoplast, triple-layer, barrier time, etc.)
- List primary indications
- Reference shelf life and storage where relevant

### Sales Collateral
- Competitive battle cards: Use only approved competitive comparisons from reference files
- Rep talking points: Pull key messages verbatim from source documents
- Objection handling: Ground responses in source-document evidence

### Ad Copy (Display / Paid)
- Headline: 25-40 characters (benefit-focused, from approved claims)
- Body: 70-90 characters max
- CTA: "Learn More", "Download Brochure", "See the Portfolio"

## Example Content Patterns

**Evidence-Driven LinkedIn Post (Puros Cancellous):**
> Puros Cancellous Particulate demonstrates up to 127% more vital bone formation compared to non-resorbable xenograft in sinus-lift procedures.¹ The proprietary Tutoplast Process preserves the natural collagen matrix while ensuring sterility—backed by 11M+ implants with zero confirmed infections.
>
> Learn more: [link]
>
> ¹Froum S.J. et al. Int J Periodontics Restorative Dent (2006) 26:543-51.

**Growth Factor Hook (Biotivity A/C Plus):**
> A growth factor charged membrane with over 250+ individual growth factors — naturally preserved in a triple-layer structure, never delaminated. No antibiotics. No side-specific placement required.
>
> Biotivity™ A/C Plus Membrane.

**Socket Preservation Email Subject:**
> Socket Preservation Made Simple — RegenerOss® Bone Graft Plug

**Efficiency-Focused Email Subject:**
> 5-Year Shelf Life. Room Temp Storage. Ready When You Are.
