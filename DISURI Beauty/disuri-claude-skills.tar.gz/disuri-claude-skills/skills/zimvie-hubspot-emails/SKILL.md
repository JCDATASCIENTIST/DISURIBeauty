---
name: zimvie-hubspot-emails
description: Generate ready-to-paste HubSpot HTML + HubL email templates for ZimVie dental marketing campaigns. Use when asked to build a ZimVie email, HubSpot email for ZimVie, or any email targeting dental professionals. Supports product launch, nurture sequence, event invite, and newsletter emails. Applies ZimVie brand guidelines, asks for persona/archetype, includes FDA compliance reminders, and outputs complete HubL code. Trigger phrases include "ZimVie email", "HubSpot email", "build email for [campaign]", "email template", "nurture email", "product launch email", or requests for dental marketing emails.
---

# ZimVie HubSpot Emails

Generate HubSpot HTML + HubL email templates that follow ZimVie brand guidelines and email marketing best practices.

## Workflow

1. **Gather requirements** — Ask clarifying questions before generating
2. **Apply brand guidelines** — Reference zimvie-brand-guidelines skill for colors, typography, voice
3. **Generate HubL template** — Output complete, ready-to-paste code
4. **Include compliance notes** — Add FDA/medical device reminders

## Required Clarifying Questions

Before generating any email, ask:

**Email Type**: What type of email?
- Product Launch (announcing new product/feature)
- Nurture Sequence (educational, relationship-building)
- Event Invite (webinar, conference, symposium)
- Newsletter (multi-topic update)
- Re-engagement (win-back inactive contacts)
- Transactional (confirmation, follow-up)

**Product/Topic**: What product, event, or topic is being promoted?

**Persona**: Which ZimVie persona?
- Oral Surgeon
- Periodontist
- GP Implant
- GP Restorative
- Lab Tech
- DSO Ops
- DSO Clinician

**Archetype**: Which decision-making archetype?
- Evidence-Driven (needs clinical data, peer-reviewed studies)
- Innovation-Seeker (wants cutting-edge, first-to-market)
- Patient-Centered (focuses on patient outcomes, comfort)
- Detail-Focused (needs specs, technical documentation)
- Efficiency-Focused (ROI, time savings, workflow optimization)

**Buyer's Journey Stage**:
- Awareness (experiencing problem, researching)
- Consideration (evaluating solutions)
- Decision (comparing vendors, ready to purchase)

**Primary CTA**: What action should recipients take? (register, download, request demo, learn more, contact rep)

## Email Structure by Type

### Product Launch Email
1. Subject line with product name + key benefit
2. Preview text reinforcing value
3. Hero image of product
4. Headline announcing launch
5. 3-4 key benefits (bullets)
6. Primary CTA button
7. Supporting details or specs (for Detail-Focused)
8. Secondary CTA (contact rep)
9. Footer with legal/compliance

### Nurture Sequence Email
1. Subject line with educational hook
2. Preview text with value proposition
3. Personalized greeting
4. Educational content (problem → insight → solution path)
5. Key takeaway or tip
6. Soft CTA (learn more, read article)
7. P.S. line with secondary offer
8. Footer

### Event Invite Email
1. Subject line with event name + date
2. Preview text with key speaker or topic
3. Event banner/hero image
4. Event details (date, time, location/platform)
5. What attendees will learn (3-4 bullets)
6. Speaker credentials
7. Primary CTA (Register Now)
8. Calendar add link
9. Footer

### Newsletter Email
1. Subject line highlighting top story
2. Preview text with content tease
3. Header with logo
4. Featured article with image
5. 2-3 secondary stories (headline + 1-line summary + link)
6. Product spotlight (optional)
7. Upcoming events section
8. Footer

## Email Design Principles

**Mobile-First**: 
- Single-column layout (600px max width)
- 16px minimum body text
- 44px minimum touch targets for buttons
- Stack images on mobile

**Scannable Content**:
- One main idea per email
- Short paragraphs (2-3 sentences)
- Bullet points for benefits
- Generous white space

**One Primary CTA**:
- Above the fold
- Clear, action-oriented text
- High contrast button color (ZimVie Lemon on Navy)
- Repeat at bottom for long emails

**Accessibility**:
- Alt text for all images
- Sufficient color contrast (4.5:1 minimum)
- Meaningful link text (not "click here")
- Dark mode compatible colors

## HubSpot Email Modules

Use these standard HubSpot email modules:

| Section | Module | Path |
|---------|--------|------|
| Header Logo | Logo | `@hubspot/logo` |
| Hero Image | Image | `@hubspot/image` |
| Body Text | Rich Text | `@hubspot/rich_text` |
| CTA Button | Button | `@hubspot/button` |
| Divider | Divider | `@hubspot/divider` |
| Social Links | Social Follow | `@hubspot/social_follow` |
| Footer | Rich Text | `@hubspot/rich_text` |

## ZimVie Brand Application

Apply these brand elements (see zimvie-brand-guidelines skill for full specs):

**Colors**:
- Background: White (#ffffff) or Chrome (#dbe0e2)
- Primary text: Rich Gray (#414649)
- Headlines: Navy (#0a2043)
- Links: True Blue (#005da6)
- CTA Button: Lemon (#e6dc19) with Navy text
- Accent: Sky Blue (#61b6e2)

**Typography**:
- Headlines: Arial Bold (web-safe fallback for Soleil)
- Body: Arial Regular, 16px minimum
- Use proper trademark symbols (®/™) on first mention

**Voice**:
- Professional but approachable
- Confident without being pushy
- Educational, not salesy
- Passionate, Proactive, Agile (brand persona)

## FDA Compliance Reminders

Include these comments in generated templates:

```html
<!-- FDA COMPLIANCE NOTES:
- All claims must be supported by cleared indications for use
- No unapproved efficacy claims
- Use "designed to" or "intended for" language
- Include required safety information links
- Testimonials require proper disclosure
- Review with regulatory before sending
-->
```

**Email-Specific Compliance**:
- Include unsubscribe link (required by CAN-SPAM)
- Physical mailing address required
- "For professional use only" disclaimer
- Link to full prescribing information where appropriate

## Subject Line Best Practices

**Formula**: [Benefit] + [Curiosity/Specificity]

**Examples by Type**:
- Product Launch: "Introducing [Product]™: [Key Benefit] for [Persona]"
- Nurture: "[Number] ways to [solve problem] in your practice"
- Event: "You're invited: [Event Name] | [Date]"
- Newsletter: "[Month] Update: [Top Story Headline]"

**Avoid**:
- ALL CAPS
- Excessive punctuation!!!
- Spam trigger words (free, act now, limited time)
- Misleading subject lines

## Template Output Format

Generate complete HTML + HubL code that can be pasted directly into HubSpot Email Editor:

```hubl
{% extends "hubspot/email/templates/base.html" %}

{% block body %}
<!-- Email content here -->
{% endblock body %}
```

Include:
- Inline CSS (email client compatibility)
- Table-based layout for Outlook support
- Mobile-responsive styles
- Preheader text
- Unsubscribe and view in browser links

## Personalization Tokens

Use HubSpot personalization where appropriate:

```hubl
{{ contact.firstname|default("Doctor") }}
{{ contact.company|default("your practice") }}
{{ contact.jobtitle|default("dental professional") }}
```

## Example Usage

**User**: Build a ZimVie email for TSX Modular Surgical Kit product launch to oral surgeons

**Claude**: Before I generate the email template, I need a few details:

1. **Archetype**: Is this oral surgeon primarily Evidence-Driven (needs clinical data), Innovation-Seeker (wants cutting-edge), or Efficiency-Focused (ROI/workflow)?

2. **Buyer's Journey Stage**: Are they in Awareness (learning about the problem), Consideration (evaluating solutions), or Decision (ready to purchase)?

3. **Primary CTA**: What action should they take? (request demo, download brochure, contact rep, watch video)

4. **Key Message**: What's the #1 benefit or differentiator to emphasize? (e.g., modularity, compatibility, efficiency)

[After receiving answers, generate complete HubL email template]
