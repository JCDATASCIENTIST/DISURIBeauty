# HubL Email Template Reference

## Product Launch Email Template

```hubl
{% extends "hubspot/email/templates/base.html" %}

{% block body %}

<!-- FDA COMPLIANCE NOTES:
- All claims must be supported by cleared indications for use
- No unapproved efficacy claims
- Review with regulatory before sending
-->

<!-- Preheader Text (hidden preview text) -->
<span style="display:none !important; visibility:hidden; mso-hide:all; font-size:1px; color:#ffffff; line-height:1px; max-height:0px; max-width:0px; opacity:0; overflow:hidden;">
  [Product Name]™ is here. Discover how it can transform your surgical workflow.
</span>

<!-- Email Container -->
<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f8f9fa;">
  <tr>
    <td style="padding: 20px 0;">
      
      <!-- Main Content Table -->
      <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" style="margin: 0 auto; background-color: #ffffff;">
        
        <!-- Header with Logo -->
        <tr>
          <td style="padding: 24px 40px; background-color: #0a2043;">
            {% module "email_logo" path="@hubspot/logo"
              label="Header Logo"
              img={
                "alt": "ZimVie - Restoring Daily Life"
              }
            %}
          </td>
        </tr>
        
        <!-- Hero Image -->
        <tr>
          <td style="padding: 0;">
            {% module "hero_image" path="@hubspot/image"
              label="Hero Product Image"
              img={
                "alt": "Product Name product image",
                "width": 600
              }
            %}
          </td>
        </tr>
        
        <!-- Main Content -->
        <tr>
          <td style="padding: 40px;">
            
            {% module "email_content" path="@hubspot/rich_text"
              label="Email Body"
              html="<h1 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 28px; margin: 0 0 16px 0;'>Introducing [Product Name]™</h1>
              
              <p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0;'>Dear {{ contact.firstname|default('Doctor') }},</p>
              
              <p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0;'>We're excited to introduce [Product Name]™, designed to [key benefit statement tailored to persona].</p>
              
              <p style='color: #0a2043; font-family: Arial, sans-serif; font-size: 18px; font-weight: bold; margin: 0 0 16px 0;'>Key Benefits:</p>
              
              <ul style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.8; margin: 0 0 24px 0; padding-left: 20px;'>
                <li>Benefit 1 focused on persona priorities</li>
                <li>Benefit 2 with specific outcome</li>
                <li>Benefit 3 addressing pain point</li>
                <li>Benefit 4 differentiator</li>
              </ul>"
            %}
            
            <!-- Primary CTA -->
            {% module "primary_cta" path="@hubspot/button"
              label="Primary CTA"
              button_text="Request a Demo"
              style={
                "override_default_style": true,
                "button_font": {
                  "color": "#0a2043",
                  "size": 16,
                  "font": "Arial, sans-serif"
                },
                "button_background_color": {
                  "color": "#e6dc19"
                },
                "button_border_radius": 4,
                "button_padding": "14px 32px"
              }
            %}
            
            {% module "closing_content" path="@hubspot/rich_text"
              label="Closing Content"
              html="<p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.6; margin: 24px 0 0 0;'>Have questions? <a href='#' style='color: #005da6;'>Contact your ZimVie representative</a> to learn more.</p>
              
              <p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.6; margin: 24px 0 0 0;'>Best regards,<br>The ZimVie Team</p>"
            %}
            
          </td>
        </tr>
        
        <!-- Footer -->
        <tr>
          <td style="padding: 32px 40px; background-color: #414649;">
            {% module "footer_content" path="@hubspot/rich_text"
              label="Footer"
              html="<p style='color: #aaa9ad; font-family: Arial, sans-serif; font-size: 12px; line-height: 1.6; margin: 0 0 16px 0; text-align: center;'>For professional use only. Please refer to the Instructions for Use for complete product information.</p>
              
              <p style='color: #aaa9ad; font-family: Arial, sans-serif; font-size: 12px; line-height: 1.6; margin: 0 0 16px 0; text-align: center;'>© 2026 ZimVie Inc. All rights reserved.<br>
              1900 Aston Avenue, Carlsbad, CA 92008</p>
              
              <p style='color: #aaa9ad; font-family: Arial, sans-serif; font-size: 12px; line-height: 1.6; margin: 0; text-align: center;'>
                <a href='{{ unsubscribe_link }}' style='color: #61b6e2;'>Unsubscribe</a> | 
                <a href='{{ view_as_page_url }}' style='color: #61b6e2;'>View in Browser</a> | 
                <a href='#' style='color: #61b6e2;'>Privacy Policy</a>
              </p>"
            %}
          </td>
        </tr>
        
      </table>
      
    </td>
  </tr>
</table>

{% endblock body %}
```

## Nurture Sequence Email Template

```hubl
{% extends "hubspot/email/templates/base.html" %}

{% block body %}

<!-- Preheader -->
<span style="display:none !important; visibility:hidden; mso-hide:all; font-size:1px; color:#ffffff; line-height:1px; max-height:0px; max-width:0px; opacity:0; overflow:hidden;">
  [Educational hook that builds on subject line]
</span>

<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f8f9fa;">
  <tr>
    <td style="padding: 20px 0;">
      
      <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" style="margin: 0 auto; background-color: #ffffff;">
        
        <!-- Header -->
        <tr>
          <td style="padding: 24px 40px; border-bottom: 1px solid #dbe0e2;">
            {% module "email_logo" path="@hubspot/logo"
              label="Header Logo"
            %}
          </td>
        </tr>
        
        <!-- Content -->
        <tr>
          <td style="padding: 40px;">
            
            {% module "email_content" path="@hubspot/rich_text"
              label="Email Body"
              html="<p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0;'>Hi {{ contact.firstname|default('Doctor') }},</p>
              
              <p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0;'>[Opening that acknowledges their challenge or interest]</p>
              
              <h2 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 22px; margin: 0 0 16px 0;'>[Educational Headline]</h2>
              
              <p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0;'>[2-3 paragraphs of valuable educational content. Focus on insights, not selling. Build credibility through expertise.]</p>
              
              <p style='color: #0a2043; font-family: Arial, sans-serif; font-size: 16px; font-weight: bold; line-height: 1.6; margin: 0 0 16px 0;'>Key Takeaway:</p>
              
              <p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0; padding: 16px; background-color: #f8f9fa; border-left: 4px solid #61b6e2;'>[Summarize the main insight in 1-2 sentences that they can apply immediately]</p>"
            %}
            
            <!-- Soft CTA -->
            {% module "soft_cta" path="@hubspot/button"
              label="Learn More CTA"
              button_text="Read the Full Article"
              style={
                "override_default_style": true,
                "button_font": {
                  "color": "#ffffff",
                  "size": 16,
                  "font": "Arial, sans-serif"
                },
                "button_background_color": {
                  "color": "#005da6"
                },
                "button_border_radius": 4
              }
            %}
            
            {% module "ps_content" path="@hubspot/rich_text"
              label="P.S. Line"
              html="<p style='color: #414649; font-family: Arial, sans-serif; font-size: 14px; line-height: 1.6; margin: 32px 0 0 0;'><strong>P.S.</strong> [Secondary offer or teaser for next email in sequence]</p>"
            %}
            
          </td>
        </tr>
        
        <!-- Footer -->
        <tr>
          <td style="padding: 32px 40px; background-color: #414649;">
            {% module "footer_content" path="@hubspot/rich_text"
              label="Footer"
              html="<p style='color: #aaa9ad; font-family: Arial, sans-serif; font-size: 12px; text-align: center;'>© 2026 ZimVie Inc. | <a href='{{ unsubscribe_link }}' style='color: #61b6e2;'>Unsubscribe</a></p>"
            %}
          </td>
        </tr>
        
      </table>
    </td>
  </tr>
</table>

{% endblock body %}
```

## Event Invite Email Template

```hubl
{% extends "hubspot/email/templates/base.html" %}

{% block body %}

<!-- Preheader -->
<span style="display:none !important; visibility:hidden; mso-hide:all; font-size:1px; color:#ffffff; line-height:1px; max-height:0px; max-width:0px; opacity:0; overflow:hidden;">
  Join us [Date] for [Event Name]. Register now – limited spots available.
</span>

<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f8f9fa;">
  <tr>
    <td style="padding: 20px 0;">
      
      <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" style="margin: 0 auto; background-color: #ffffff;">
        
        <!-- Header -->
        <tr>
          <td style="padding: 24px 40px; background-color: #0a2043;">
            {% module "email_logo" path="@hubspot/logo" label="Header Logo" %}
          </td>
        </tr>
        
        <!-- Event Banner -->
        <tr>
          <td style="padding: 0;">
            {% module "event_banner" path="@hubspot/image"
              label="Event Banner"
              img={
                "alt": "Event Name - Date",
                "width": 600
              }
            %}
          </td>
        </tr>
        
        <!-- Content -->
        <tr>
          <td style="padding: 40px;">
            
            {% module "event_content" path="@hubspot/rich_text"
              label="Event Details"
              html="<h1 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 28px; margin: 0 0 8px 0;'>You're Invited</h1>
              
              <h2 style='color: #61b6e2; font-family: Arial, sans-serif; font-size: 22px; margin: 0 0 24px 0;'>[Event Name]</h2>
              
              <table role='presentation' cellspacing='0' cellpadding='0' border='0' style='margin-bottom: 24px;'>
                <tr>
                  <td style='padding: 8px 0;'>
                    <strong style='color: #0a2043; font-family: Arial, sans-serif;'>📅 Date:</strong>
                    <span style='color: #414649; font-family: Arial, sans-serif;'>[Day, Month Date, Year]</span>
                  </td>
                </tr>
                <tr>
                  <td style='padding: 8px 0;'>
                    <strong style='color: #0a2043; font-family: Arial, sans-serif;'>🕐 Time:</strong>
                    <span style='color: #414649; font-family: Arial, sans-serif;'>[Time] [Timezone]</span>
                  </td>
                </tr>
                <tr>
                  <td style='padding: 8px 0;'>
                    <strong style='color: #0a2043; font-family: Arial, sans-serif;'>📍 Location:</strong>
                    <span style='color: #414649; font-family: Arial, sans-serif;'>[Venue/Virtual Platform]</span>
                  </td>
                </tr>
              </table>
              
              <p style='color: #0a2043; font-family: Arial, sans-serif; font-size: 18px; font-weight: bold; margin: 0 0 16px 0;'>What You'll Learn:</p>
              
              <ul style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.8; margin: 0 0 24px 0; padding-left: 20px;'>
                <li>Learning objective 1</li>
                <li>Learning objective 2</li>
                <li>Learning objective 3</li>
                <li>Learning objective 4</li>
              </ul>
              
              <p style='color: #0a2043; font-family: Arial, sans-serif; font-size: 18px; font-weight: bold; margin: 0 0 8px 0;'>Featured Speaker:</p>
              
              <p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0;'><strong>[Speaker Name], [Credentials]</strong><br>[Speaker title and brief bio]</p>"
            %}
            
            <!-- Register CTA -->
            {% module "register_cta" path="@hubspot/button"
              label="Register CTA"
              button_text="Register Now"
              style={
                "override_default_style": true,
                "button_font": {
                  "color": "#0a2043",
                  "size": 18,
                  "font": "Arial, sans-serif"
                },
                "button_background_color": {
                  "color": "#e6dc19"
                },
                "button_border_radius": 4,
                "button_padding": "16px 40px"
              }
            %}
            
            {% module "calendar_link" path="@hubspot/rich_text"
              label="Calendar Link"
              html="<p style='color: #414649; font-family: Arial, sans-serif; font-size: 14px; text-align: center; margin-top: 16px;'><a href='#' style='color: #005da6;'>Add to Calendar</a></p>"
            %}
            
          </td>
        </tr>
        
        <!-- Footer -->
        <tr>
          <td style="padding: 32px 40px; background-color: #414649;">
            {% module "footer_content" path="@hubspot/rich_text"
              label="Footer"
              html="<p style='color: #aaa9ad; font-family: Arial, sans-serif; font-size: 12px; text-align: center;'>© 2026 ZimVie Inc. | <a href='{{ unsubscribe_link }}' style='color: #61b6e2;'>Unsubscribe</a></p>"
            %}
          </td>
        </tr>
        
      </table>
    </td>
  </tr>
</table>

{% endblock body %}
```

## Newsletter Email Template

```hubl
{% extends "hubspot/email/templates/base.html" %}

{% block body %}

<!-- Preheader -->
<span style="display:none !important; visibility:hidden; mso-hide:all; font-size:1px; color:#ffffff; line-height:1px; max-height:0px; max-width:0px; opacity:0; overflow:hidden;">
  This month: [Top story teaser] + [Secondary story teaser]
</span>

<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f8f9fa;">
  <tr>
    <td style="padding: 20px 0;">
      
      <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" style="margin: 0 auto; background-color: #ffffff;">
        
        <!-- Header -->
        <tr>
          <td style="padding: 24px 40px; background-color: #0a2043; text-align: center;">
            {% module "email_logo" path="@hubspot/logo" label="Header Logo" %}
            <p style="color: #61b6e2; font-family: Arial, sans-serif; font-size: 14px; margin: 16px 0 0 0;">[Month Year] Newsletter</p>
          </td>
        </tr>
        
        <!-- Featured Article -->
        <tr>
          <td style="padding: 0;">
            {% module "featured_image" path="@hubspot/image"
              label="Featured Article Image"
              img={
                "alt": "Featured article image",
                "width": 600
              }
            %}
          </td>
        </tr>
        
        <tr>
          <td style="padding: 32px 40px;">
            {% module "featured_article" path="@hubspot/rich_text"
              label="Featured Article"
              html="<p style='color: #61b6e2; font-family: Arial, sans-serif; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; margin: 0 0 8px 0;'>Featured</p>
              
              <h2 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 24px; margin: 0 0 16px 0;'>[Featured Article Headline]</h2>
              
              <p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.6; margin: 0 0 16px 0;'>[2-3 sentence summary of the featured article that creates interest without giving everything away.]</p>
              
              <a href='#' style='color: #005da6; font-family: Arial, sans-serif; font-size: 16px; font-weight: bold;'>Read More →</a>"
            %}
          </td>
        </tr>
        
        <!-- Divider -->
        <tr>
          <td style="padding: 0 40px;">
            {% module "divider1" path="@hubspot/divider"
              label="Section Divider"
            %}
          </td>
        </tr>
        
        <!-- Secondary Stories -->
        <tr>
          <td style="padding: 32px 40px;">
            {% module "secondary_stories" path="@hubspot/rich_text"
              label="More Stories"
              html="<h3 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 18px; margin: 0 0 24px 0;'>More From ZimVie</h3>
              
              <table role='presentation' cellspacing='0' cellpadding='0' border='0' width='100%'>
                <tr>
                  <td style='padding-bottom: 24px;'>
                    <h4 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 16px; margin: 0 0 8px 0;'>[Story 2 Headline]</h4>
                    <p style='color: #414649; font-family: Arial, sans-serif; font-size: 14px; line-height: 1.5; margin: 0;'>[One-line summary] <a href='#' style='color: #005da6;'>Read →</a></p>
                  </td>
                </tr>
                <tr>
                  <td style='padding-bottom: 24px;'>
                    <h4 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 16px; margin: 0 0 8px 0;'>[Story 3 Headline]</h4>
                    <p style='color: #414649; font-family: Arial, sans-serif; font-size: 14px; line-height: 1.5; margin: 0;'>[One-line summary] <a href='#' style='color: #005da6;'>Read →</a></p>
                  </td>
                </tr>
              </table>"
            %}
          </td>
        </tr>
        
        <!-- Upcoming Events -->
        <tr>
          <td style="padding: 32px 40px; background-color: #f8f9fa;">
            {% module "events_section" path="@hubspot/rich_text"
              label="Upcoming Events"
              html="<h3 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 18px; margin: 0 0 16px 0;'>📅 Upcoming Events</h3>
              
              <p style='color: #414649; font-family: Arial, sans-serif; font-size: 14px; line-height: 1.6; margin: 0 0 8px 0;'><strong>[Event Name]</strong> – [Date] | <a href='#' style='color: #005da6;'>Register</a></p>
              
              <p style='color: #414649; font-family: Arial, sans-serif; font-size: 14px; line-height: 1.6; margin: 0;'><strong>[Event Name]</strong> – [Date] | <a href='#' style='color: #005da6;'>Register</a></p>"
            %}
          </td>
        </tr>
        
        <!-- Footer -->
        <tr>
          <td style="padding: 32px 40px; background-color: #414649;">
            {% module "social_links" path="@hubspot/social_follow"
              label="Social Links"
            %}
            
            {% module "footer_content" path="@hubspot/rich_text"
              label="Footer"
              html="<p style='color: #aaa9ad; font-family: Arial, sans-serif; font-size: 12px; text-align: center; margin-top: 24px;'>© 2026 ZimVie Inc. All rights reserved.<br>
              <a href='{{ unsubscribe_link }}' style='color: #61b6e2;'>Unsubscribe</a> | 
              <a href='{{ subscription_preferences_url }}' style='color: #61b6e2;'>Manage Preferences</a> | 
              <a href='{{ view_as_page_url }}' style='color: #61b6e2;'>View in Browser</a></p>"
            %}
          </td>
        </tr>
        
      </table>
    </td>
  </tr>
</table>

{% endblock body %}
```

## Subject Line Examples by Email Type

### Product Launch
- "Introducing [Product]™: [Key benefit] for [persona]"
- "New from ZimVie: [Product]™ is here"
- "[Product]™: The next generation of [category]"

### Nurture
- "[Number] ways to improve [outcome] in your practice"
- "The science behind [topic]: What the research shows"
- "Case study: How Dr. [Name] achieved [result]"

### Event Invite
- "You're invited: [Event Name] | [Date]"
- "Save your seat: [Topic] webinar with [Speaker]"
- "[Event Name]: Register by [Date] for early access"

### Newsletter
- "ZimVie [Month]: [Top story headline]"
- "This month: [Topic 1] + [Topic 2] + more"
- "[Month] update: New research on [topic]"

## Persona-Specific Adjustments

| Persona | Tone | Key Messaging Focus |
|---------|------|---------------------|
| Oral Surgeon | Direct, technical | Surgical precision, efficiency, case throughput |
| Periodontist | Clinical, evidence-based | Tissue outcomes, regenerative results, studies |
| GP Implant | Supportive, practical | Ease of use, learning curve, training support |
| GP Restorative | Patient-focused, esthetic | Esthetics, patient satisfaction, workflow |
| Lab Tech | Technical, detailed | Specs, compatibility, precision metrics |
| DSO Ops | Business-focused | ROI, standardization, scalability |
| DSO Clinician | Efficient, protocol-driven | Consistency, time savings, standardization |
