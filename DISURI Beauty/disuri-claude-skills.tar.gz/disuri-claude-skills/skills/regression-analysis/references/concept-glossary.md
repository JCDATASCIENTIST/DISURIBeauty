# Regression Concept Glossary

Quick-reference for all regression symbols and concepts. Organized from foundational to advanced.

## Core Variables

| Symbol | Name | Description |
|--------|------|-------------|
| y | Dependent Variable | The outcome being explained or predicted. Left-hand side of the equation. |
| x | Independent Variable | The explanatory/predictor variable. Changes in x are hypothesized to affect y. |
| ŷ (y-hat) | Predicted Value | The model's prediction for y given a specific x value. Falls on the regression line. |
| ȳ (y-bar) | Mean of y | The average value of the dependent variable across all observations. |

## Population Parameters (Theoretical — never directly observed)

| Symbol | Name | Description |
|--------|------|-------------|
| β₀ | Population Intercept | True value of y when x = 0. Unknown; estimated by b₀. |
| β₁ | Population Slope | True rate of change in y per unit change in x. Unknown; estimated by b₁. |
| ε (epsilon) | Population Error | All variation in y not explained by the model. Cannot be calculated — the true line is unknown. |

## Sample Estimates (Calculated from data)

| Symbol | Name | Description |
|--------|------|-------------|
| b₀ (or β̂₀) | Estimated Intercept | Sample estimate of β₀. Where the fitted line crosses the y-axis. |
| b₁ (or β̂₁) | Estimated Slope | Sample estimate of β₁. Predicted change in y for a 1-unit increase in x. |
| e | Residual | Vertical distance from a data point to the fitted line: e = y - ŷ. The sample analog of ε. |

## Variation Decomposition

| Symbol | Name | Formula | Description |
|--------|------|---------|-------------|
| SST | Sum of Squares Total | Σ(y - ȳ)² | Total variation in y. Everything the model aims to explain. |
| SSR | Sum of Squares Regression | Σ(ŷ - ȳ)² | Variation explained by the model. Higher = more explanatory power. |
| SSE | Sum of Squares Error | Σ(y - ŷ)² | Variation left unexplained. Lower = better fit. |
| — | Fundamental identity | SST = SSR + SSE | Total variation = explained + unexplained. |

## Model Fit Metrics

| Symbol | Name | Formula | Description |
|--------|------|---------|-------------|
| R² | Coefficient of Determination | SSR / SST | Proportion of variation explained. Ranges 0–1; closer to 1 = stronger model. |
| Adj R² | Adjusted R-Squared | 1 - [(1-R²)(n-1)/(n-k-1)] | R² penalized for number of predictors. Use when comparing models. If Adj R² drops when adding a variable, that variable isn't helping. |
| df | Degrees of Freedom | n - k - 1 | Independent pieces of information available for estimation. n = observations, k = predictors. |

## Hypothesis Testing

| Concept | Description |
|---------|-------------|
| t-statistic | Tests whether an individual coefficient is significantly different from zero: t = b / SE(b). |
| p-value | Probability of seeing this coefficient (or more extreme) if the true effect were zero. p < 0.05 is the common threshold. |
| F-statistic | Tests whether the model as a whole is significant (at least one predictor matters). |
| Confidence Interval | Range of plausible values for a coefficient. A 95% CI for b₁ means: "we're 95% confident the true β₁ falls in this range." |

## Diagnostic Concepts

| Concept | Description |
|---------|-------------|
| Homoscedasticity | Residuals have constant variance across all fitted values. Violation: residuals fan out or funnel. |
| Heteroscedasticity | Non-constant variance in residuals. Fix with log transforms, weighted regression, or robust standard errors. |
| Normality of residuals | Residuals should be approximately normally distributed. Check with Q-Q plots and histograms. |
| Multicollinearity | Two or more predictors are highly correlated, inflating standard errors. Detect with VIF. |
| VIF | Variance Inflation Factor. VIF > 5 is a warning; VIF > 10 means serious multicollinearity. |
| Outlier | An observation far from the pattern. Can disproportionately influence the regression line. |
| Leverage | How far an observation's x-value is from the mean of x. High leverage = high potential influence. |
| Cook's Distance | Combines leverage and residual size to measure an observation's overall influence on the model. |

## Logistic Regression Concepts

| Concept | Description |
|---------|-------------|
| Odds | p / (1-p). If p = 0.75, odds = 3:1. |
| Log-odds (logit) | log(p / (1-p)). The scale logistic regression operates on. |
| Odds Ratio | e^b. How much the odds multiply for a 1-unit increase in x. OR = 1.5 means 50% higher odds. |
| Pseudo R² | Approximate analog of R² for logistic models. McFadden's is common. Don't over-interpret. |
| AUC-ROC | Area under the ROC curve. Measures discrimination ability. 0.5 = random guessing, 1.0 = perfect. |
