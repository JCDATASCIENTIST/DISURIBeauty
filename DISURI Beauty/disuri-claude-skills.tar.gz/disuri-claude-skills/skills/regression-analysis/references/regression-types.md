# Regression Types Reference

## Table of Contents
1. [Simple Linear Regression](#simple-linear-regression)
2. [Multiple Linear Regression](#multiple-linear-regression)
3. [Polynomial Regression](#polynomial-regression)
4. [Logistic Regression](#logistic-regression)
5. [Poisson Regression](#poisson-regression)
6. [Ridge and Lasso (Regularized)](#ridge-and-lasso-regularized)

---

## Simple Linear Regression

**When to use:** One continuous dependent variable (y), one continuous independent variable (x), and the relationship appears linear.

**The model:** ŷ = b₀ + b₁x

**Assumptions:**
1. Linearity — the relationship between x and y is linear
2. Independence — observations are independent of each other
3. Homoscedasticity — residuals have constant variance across all x values
4. Normality — residuals are approximately normally distributed

**Implementation (statsmodels):**
```python
import statsmodels.api as sm

X = sm.add_constant(df['x_column'])  # adds intercept
model = sm.OLS(df['y_column'], X).fit()
print(model.summary())
```

**Key outputs to extract:**
- `model.params` — coefficients (b₀, b₁)
- `model.rsquared` — R²
- `model.rsquared_adj` — Adjusted R²
- `model.fvalue`, `model.f_pvalue` — F-test
- `model.ssr` — SSR (regression sum of squares)
- `model.ssr` — note: statsmodels uses `ess` for explained SS and `ssr` for residual SS (confusingly). Use `model.ess` for SSR and `model.ssr` for SSE.
- `model.centered_tss` — SST
- `model.resid` — residuals

**Interpretation example:**
"For every 1-unit increase in Temperature, Ice Cream Sales increase by $2.86 on average (b₁ = 2.86, p < 0.001). Temperature explains 82% of the variation in sales (R² = 0.82)."

---

## Multiple Linear Regression

**When to use:** One continuous y, two or more x variables. The goal is to understand which factors matter and how much each contributes while controlling for the others.

**The model:** ŷ = b₀ + b₁x₁ + b₂x₂ + ... + bₖxₖ

**Additional assumptions (beyond simple linear):**
- No multicollinearity — independent variables should not be highly correlated with each other. Check with VIF.

**Implementation:**
```python
import statsmodels.api as sm

X = sm.add_constant(df[['x1', 'x2', 'x3']])
model = sm.OLS(df['y'], X).fit()
print(model.summary())

# Check multicollinearity
from statsmodels.stats.outliers_influence import variance_inflation_factor
vif_data = pd.DataFrame()
vif_data['Variable'] = X.columns
vif_data['VIF'] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]
```

**Adjusted R² matters here.** Regular R² increases every time you add a variable, even a useless one. Adjusted R² penalizes for adding predictors that don't earn their keep. If adjusted R² drops when you add a variable, that variable isn't helping — remove it.

**Interpretation:** Each coefficient represents the effect of that variable *holding all other variables constant*. "Controlling for humidity and day-of-week, each 1° increase in temperature is associated with $2.50 more in sales."

---

## Polynomial Regression

**When to use:** The scatter plot shows a curved relationship (U-shape, inverted-U, S-curve). A straight line clearly doesn't fit.

**The model:** ŷ = b₀ + b₁x + b₂x² + b₃x³ + ...

**Implementation:**
```python
from sklearn.preprocessing import PolynomialFeatures
import statsmodels.api as sm

poly = PolynomialFeatures(degree=2, include_bias=False)
X_poly = poly.fit_transform(df[['x']])
X_poly = sm.add_constant(X_poly)
model = sm.OLS(df['y'], X_poly).fit()
```

**Caution:** Don't go higher than degree 3 unless you have a theoretical reason. Higher-degree polynomials overfit like crazy — they'll chase noise in the sample and perform terribly on new data. Always check adjusted R² and use cross-validation for prediction tasks.

---

## Logistic Regression

**When to use:** The dependent variable is binary (0/1, yes/no, survived/died, clicked/didn't click).

**The model:** log(p / (1-p)) = b₀ + b₁x₁ + b₂x₂ + ...
Where p is the probability of the outcome being 1.

**Implementation:**
```python
import statsmodels.api as sm

X = sm.add_constant(df[['x1', 'x2']])
model = sm.Logit(df['y_binary'], X).fit()
print(model.summary())

# Odds ratios (more interpretable than raw coefficients)
odds_ratios = np.exp(model.params)
```

**Key differences from linear regression:**
- No R² in the traditional sense. Use **pseudo R²** (McFadden's) as a rough equivalent, but don't over-interpret it.
- Coefficients are in **log-odds**. Convert to odds ratios (e^b) for interpretation.
- Use **classification metrics**: accuracy, precision, recall, AUC-ROC, confusion matrix.
- Diagnose with **Hosmer-Lemeshow test** for calibration.

**Interpretation:** "Each additional year of experience multiplies the odds of promotion by 1.35 (odds ratio = e^0.30 = 1.35, p = 0.002)."

---

## Poisson Regression

**When to use:** The dependent variable is a count (number of events: customer complaints per day, goals scored, accidents per month). Counts are non-negative integers and often right-skewed.

**The model:** log(μ) = b₀ + b₁x₁ + b₂x₂
Where μ is the expected count.

**Implementation:**
```python
import statsmodels.api as sm

X = sm.add_constant(df[['x1', 'x2']])
model = sm.GLM(df['count_y'], X, family=sm.families.Poisson()).fit()
print(model.summary())

# Incidence rate ratios
irr = np.exp(model.params)
```

**Watch for overdispersion:** If the variance of y is much larger than the mean, Poisson underestimates standard errors. Use Negative Binomial regression instead (swap `sm.families.Poisson()` for `sm.families.NegativeBinomial()`).

---

## Ridge and Lasso (Regularized)

**When to use:** Many predictors, risk of overfitting, or multicollinearity. Also useful for feature selection (Lasso).

**Ridge (L2):** Shrinks coefficients toward zero but keeps all variables.
**Lasso (L1):** Can shrink coefficients to exactly zero, effectively selecting features.

**Implementation:**
```python
from sklearn.linear_model import Ridge, Lasso, RidgeCV, LassoCV
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Use cross-validation to pick the regularization strength
ridge = RidgeCV(alphas=[0.01, 0.1, 1, 10, 100]).fit(X_scaled, y)
lasso = LassoCV(cv=5).fit(X_scaled, y)

print(f"Best alpha: {ridge.alpha_}")
print(f"Coefficients: {ridge.coef_}")
```

**Important:** Always standardize features before regularization — otherwise the penalty treats variables on different scales unfairly.
