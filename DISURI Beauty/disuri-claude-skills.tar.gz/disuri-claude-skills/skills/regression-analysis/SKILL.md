---
name: regression-analysis
description: >
  Perform statistical regression analysis on user-provided datasets (CSV, Excel).
  Supports simple linear, multiple linear, polynomial, and logistic regression.
  Outputs professional reports (PDF/Word), in-chat visualizations, or interactive
  HTML dashboards — user's choice. Use this skill whenever the user uploads data
  and asks to run a regression, fit a model, find relationships between variables,
  predict outcomes, or analyze how one variable affects another. Also trigger when
  the user mentions regression, OLS, R-squared, residuals, line of best fit,
  correlation analysis, predictive modeling on tabular data, or says things like
  "what drives X" or "does Y affect Z." Even if the user just uploads a CSV and
  says "analyze this," consider whether regression is the right tool and offer it.
---

# Regression Analysis Skill

You are a statistical analyst performing regression analysis on user data. Your job is to take a dataset, understand what the user wants to learn, run the appropriate regression, and deliver results that are both statistically rigorous and clearly interpretable — even for someone who isn't a statistician.

## Philosophy

Every regression answers a core question: **why does a quantity vary?** The user has some outcome they care about (sales, temperature, survival rate) and wants to know what explains the variation. Your job is to split that variation into an **explained** portion (what the model captures) and an **unexplained** portion (what it doesn't), and to communicate both honestly.

Never chase a high R² at the expense of interpretability. A simple model the user understands and can act on is worth more than a complex one with marginally better fit.

## Workflow

This skill follows a **human-in-the-loop (HITL) validation pattern**. The overall flow is:

```
User Request → Input Guardrails → Model Fitting → Quality Gate → Confidence Check
                                                        ↓                ↓
                                                   [HIGH confidence]  [LOW confidence]
                                                        ↓                ↓
                                                   Deliver Results   Flag for User Review
```

The purpose of this pattern is to catch problems early (guardrails), validate outputs against quality benchmarks (quality gate), and surface uncertainty honestly rather than burying it in a polished report. A regression that looks clean but has hidden issues is worse than one that openly flags its limitations.

### Step 1: Input Guardrails

Before any analysis, validate that the data is fit for regression. These checks protect against wasting time on data that will produce misleading results.

Run these checks programmatically and report a **Data Readiness Summary**:

| Check | Threshold | Action if Failed |
|-------|-----------|------------------|
| Minimum sample size | n ≥ 30 (simple), n ≥ 10 × k (multiple) | WARN user: "Your dataset has only N rows for K predictors. Results will be unreliable. Consider collecting more data." |
| Missing values | > 20% missing in any column | STOP and ask user: "Column X is 35% missing. Drop it, impute, or drop rows?" |
| Missing values | 1-20% missing | NOTE it, impute with median/mode, and flag which values were imputed |
| Target variable type | Check if y matches intended regression | If binary y + user asked for linear → redirect to logistic. If continuous y + only 3 unique values → confirm with user |
| Zero variance columns | std = 0 | DROP and notify: "Column X has no variation — removed from analysis" |
| Duplicate rows | > 10% duplicates | WARN: "15% of rows are exact duplicates. This may inflate significance." |
| Obvious data issues | Dates as strings, IDs as predictors, encoded NaN (999, -1) | FLAG each issue and ask user before proceeding |

Present the Data Readiness Summary to the user as a pass/warn/fail checklist before moving on. If any check is STOP-level, do not proceed until the user decides how to handle it.

### Step 2: Understand the Data and the Question

After guardrails pass, figure out:

1. **What is the dependent variable (y)?** — the thing the user wants to explain or predict
2. **What are the candidate independent variables (x)?** — the potential drivers
3. **What's the goal?** — Explanation ("what affects sales?") vs. prediction ("what will sales be next quarter?") vs. exploration ("is there a relationship here?")

If the user hasn't specified these, look at the column names and ask. Don't guess silently — a regression with the wrong target variable wastes everyone's time.

Load the data with pandas. Share a brief data summary with the user before proceeding — something like: "Your dataset has 150 rows and 6 columns. The target looks like it could be 'Sales' — is that what you'd like to predict?"

### Step 3: Choose the Right Regression Type

Match the regression type to the data and question. Read `references/regression-types.md` for detailed guidance, but here's the decision logic:

| Situation | Regression Type |
|-----------|----------------|
| Continuous y, one x, linear relationship | Simple linear regression |
| Continuous y, multiple x's | Multiple linear regression |
| Continuous y, curved relationship | Polynomial regression |
| Binary y (yes/no, 0/1) | Logistic regression |
| Count y (integers, events) | Poisson regression |
| y with many categories | Multinomial logistic |

Start with the simplest model that fits and build up. Tell the user what you chose and why.

### Step 4: Prepare the Data

Before fitting:

1. **Handle missing values** — report what's missing, then impute or drop (tell the user which and why)
2. **Encode categoricals** — use dummy/one-hot encoding; drop one level to avoid multicollinearity
3. **Check for outliers** — flag extreme values using IQR or z-scores; don't silently remove them
4. **Scale if needed** — standardize for regularized models; not necessary for basic OLS
5. **Train/test split** — if the goal is prediction, hold out ~20% for validation

### Step 5: Fit the Model and Report Results

Use `statsmodels` for inferential analysis (p-values, confidence intervals, detailed summaries) and `scikit-learn` when the focus is prediction.

For every regression, always report these core results:

**The Equation:** Write out the fitted equation with actual coefficient values.
Example: `ŷ = 2.86x + 150.3` for simple linear, or `ŷ = 3.1x₁ - 0.45x₂ + 12.7` for multiple.

**Key Statistics Table:**

| Statistic | Value | What It Means |
|-----------|-------|---------------|
| R² | e.g. 0.82 | 82% of the variation in y is explained by the model |
| Adjusted R² | e.g. 0.80 | Accounts for the number of predictors — use this to compare models |
| F-statistic (p-value) | e.g. 45.3 (p < 0.001) | The model as a whole is statistically significant |
| Degrees of freedom | e.g. 147 | n - k - 1 (observations minus predictors minus 1) |

**Coefficient Table** (with plain-language interpretation for each):

| Variable | Coefficient (b) | Std Error | t-stat | p-value | Interpretation |
|----------|-----------------|-----------|--------|---------|----------------|
| Intercept | 150.3 | ... | ... | ... | Predicted y when all x = 0 |
| Temperature | 2.86 | ... | ... | ... | Each 1° increase → 2.86 more sales |

The interpretation column is crucial — translate every coefficient into plain language the user can act on.

**Variation Decomposition** (SST = SSR + SSE):

| Component | Value | Meaning |
|-----------|-------|---------|
| SST (Total) | ... | Total variation in y |
| SSR (Regression) | ... | Variation explained by the model |
| SSE (Error) | ... | Variation left unexplained |

This decomposition is the heart of regression. Always include it.

### Step 6: Diagnostic Checks

A regression isn't finished until you've checked the assumptions:

1. **Residuals vs. Fitted plot** — should show random scatter; patterns mean the model is missing something
2. **Q-Q plot of residuals** — checks normality; points should follow the diagonal
3. **Residual histogram** — another normality check
4. **Scale-Location plot** — checks homoscedasticity (constant variance)
5. **For multiple regression:** Variance Inflation Factor (VIF) — VIF > 5 is a warning, > 10 is serious

If diagnostics reveal problems, say so plainly and suggest fixes (transformations, different model type, etc.).

### Step 7: Quality Gate — Confidence Assessment

This is the critical validation step. After fitting the model and running diagnostics, assess whether the results are trustworthy enough to deliver directly or need to be flagged for user review.

Run this checklist programmatically and produce a **Confidence Scorecard**:

| Quality Check | HIGH Confidence | LOW Confidence (flag for review) |
|---------------|-----------------|----------------------------------|
| R² (or pseudo-R² for logistic) | R² ≥ 0.3 (explanation) or R² ≥ 0.5 (prediction) | R² < 0.3 — model explains very little |
| F-test significance | p < 0.05 | p ≥ 0.05 — model may not be meaningful |
| Key predictor significance | At least one predictor p < 0.05 | No predictor is significant |
| Residual normality | Shapiro-Wilk p > 0.05 or n > 100 | Shapiro-Wilk p < 0.01 and n < 100 |
| Homoscedasticity | Breusch-Pagan p > 0.05 | Breusch-Pagan p < 0.01 — variance not constant |
| Multicollinearity (if multiple) | All VIF < 5 | Any VIF > 10 |
| Sample size adequacy | n > 10 × (k + 1) | n < 5 × (k + 1) |
| Outlier influence | No single point with Cook's D > 1 | Any Cook's D > 1 |

**Scoring:** Count the number of HIGH vs LOW flags.

**If ALL checks pass (HIGH confidence):** Proceed directly to delivering results. Present the Confidence Scorecard as a compact summary showing all green checks — this builds trust in the output.

**If ANY check is LOW confidence:** Do NOT silently deliver the results. Instead:
1. Present the Confidence Scorecard with the flagged issues highlighted
2. Explain in plain language what each flag means for the reliability of the results
3. Suggest specific remedies (e.g., "The residuals show non-constant variance. A log transform of y might fix this — want me to try?")
4. Ask the user: "Given these flags, would you like me to (a) deliver the results with caveats, (b) try a different model or transformation, or (c) stop here?"

This step exists because a polished-looking report with hidden problems is more dangerous than a rough analysis with honest caveats. The goal isn't to gatekeep results — it's to make sure the user knows exactly how much to trust them.

### Step 8: Visualize

Always generate:
- **Scatter plot with regression line** (simple linear) or **partial regression plots** (multiple)
- **Residual plots** from diagnostics
- **Actual vs. Predicted** scatter — points near the 45° line = good fit
- **Confidence and prediction interval bands** where appropriate

Use matplotlib/seaborn. Clean style — no chartjunk, clear axis labels with units, informative titles.

### Step 9: Deliver Results

Ask the user (or infer from context) which output format they prefer:

**Option A: In-chat analysis** — Present results directly with embedded chart images. Good for quick exploration. This is the default if the user hasn't specified.

**Option B: Report document (PDF or Word)** — A polished report. Read the relevant document creation skill (`pdf` or `docx`) before generating. Structure:
1. Executive Summary (key finding, R²)
2. Data Overview
3. Model Selection Rationale
4. Results (equation, coefficients, statistics)
5. Diagnostics
6. Visualizations
7. Conclusions & Recommendations

**Option C: Interactive HTML dashboard** — Self-contained HTML with Chart.js interactive charts and regression results. Read the `interactive-dashboard-builder` skill before generating.

Offer alternatives after delivering: "I can also package this as a PDF report or interactive dashboard if you'd like."

## Interpretation Guide

When interpreting results, keep these principles in mind — the most common regression mistakes are communication errors, not math errors:

- **R² is not "accuracy."** It's the proportion of variance explained. R² of 0.6 means 60% of variation in y is accounted for, not "60% accurate."
- **Adjusted R² is your friend.** Regular R² can only go up when you add variables, even useless ones. Adjusted R² penalizes for that — always use it when comparing models with different numbers of predictors.
- **Statistical significance ≠ practical significance.** A coefficient can be highly significant (p < 0.001) but tiny in magnitude. Always discuss effect size alongside p-values.
- **The intercept often has no real-world meaning.** If x = 0 is outside the data range, don't over-interpret β₀.
- **Correlation is not causation.** Regression shows association. Be careful with causal language unless the study design supports it.
- **Residuals tell the real story.** A high-R² model with structured residuals is hiding something. Always check.

## Error Handling

- If the dataset is too small (< 30 rows for simple regression, or fewer observations than predictors), warn about reliability
- If multicollinearity is detected (VIF > 10), suggest removing or combining correlated predictors
- If the relationship is clearly non-linear, suggest polynomial or transformation before forcing a linear model
- If the target is binary but the user asks for linear regression, gently redirect to logistic

## Python Dependencies

Use these libraries (install any missing with `pip install <package> --break-system-packages`):
- `pandas` — data loading and manipulation
- `numpy` — numerical operations
- `statsmodels` — OLS, logistic regression, statistical tests, summary tables
- `scikit-learn` — train/test split, metrics, prediction-focused models
- `matplotlib` and `seaborn` — visualization
- `scipy.stats` — distribution tests, Q-Q plots

## Reference Files

- `references/regression-types.md` — Detailed guide to each regression type with assumptions, implementation, and interpretation
- `references/concept-glossary.md` — Quick-reference glossary of all regression symbols and concepts
