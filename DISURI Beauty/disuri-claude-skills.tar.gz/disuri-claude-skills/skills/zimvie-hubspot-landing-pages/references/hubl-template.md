# HubL Landing Page Template Reference

## Complete Template Structure

```hubl
{% extends "hubspot/base.html" %}

{% block body %}

{# FDA COMPLIANCE NOTES:
   - All claims must be supported by cleared indications for use
   - No comparative claims without substantiation
   - Include required safety information
   - Testimonials must include proper disclosure
   - Case results require "individual results may vary" disclaimer
   - Review with regulatory before publishing
#}

<!-- ========== HERO SECTION ========== -->
<section class="zv-hero" style="background-color: #0a2043; padding: 60px 20px;">
  <div class="zv-container" style="max-width: 1200px; margin: 0 auto;">
    
    {% module "hero_headline" path="@hubspot/rich_text"
      label="Hero Headline"
      html="<h1 style='color: #ffffff; font-family: Arial, sans-serif; font-size: 42px; margin-bottom: 16px;'>Headline Goes Here</h1><p style='color: #61b6e2; font-family: Arial, sans-serif; font-size: 20px;'>Sub-headline with value proposition tailored to persona</p>"
    %}
    
    {% module "hero_cta" path="@hubspot/button"
      label="Hero CTA Button"
      button_text="Primary CTA"
      style={
        "override_default_style": true,
        "button_font": {
          "color": "#0a2043",
          "size": 16,
          "font": "Arial"
        },
        "button_background_color": {
          "color": "#e6dc19"
        },
        "button_border_radius": 4
      }
    %}
    
    {% module "hero_image" path="@hubspot/image"
      label="Hero Product Image"
      alt="Product image description"
      loading="eager"
    %}
    
  </div>
</section>

<!-- ========== PROBLEM/PAIN SECTION ========== -->
<section class="zv-problem" style="background-color: #ffffff; padding: 60px 20px;">
  <div class="zv-container" style="max-width: 1000px; margin: 0 auto;">
    
    {% module "problem_content" path="@hubspot/rich_text"
      label="Problem Statement"
      html="<h2 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 32px; margin-bottom: 24px;'>The Challenge You Face</h2><p style='color: #414649; font-family: Arial, sans-serif; font-size: 18px; line-height: 1.6;'>Empathize with persona's specific challenges. Name the core problem they're trying to solve.</p>"
    %}
    
  </div>
</section>

<!-- ========== SOLUTION/BENEFITS SECTION ========== -->
<section class="zv-benefits" style="background-color: #f8f9fa; padding: 60px 20px;">
  <div class="zv-container" style="max-width: 1000px; margin: 0 auto;">
    
    {% module "benefits_content" path="@hubspot/rich_text"
      label="Benefits List"
      html="<h2 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 32px; margin-bottom: 32px;'>How [Product] Helps</h2><ul style='color: #414649; font-family: Arial, sans-serif; font-size: 18px; line-height: 2;'><li>✓ Benefit 1 focused on outcomes</li><li>✓ Benefit 2 tailored to persona priorities</li><li>✓ Benefit 3 with specific value</li><li>✓ Benefit 4 addressing pain point</li><li>✓ Benefit 5 differentiator</li></ul>"
    %}
    
  </div>
</section>

<!-- ========== SOCIAL PROOF SECTION ========== -->
<section class="zv-proof" style="background-color: #ffffff; padding: 60px 20px;">
  <div class="zv-container" style="max-width: 1000px; margin: 0 auto;">
    
    {% module "testimonial" path="@hubspot/rich_text"
      label="Testimonial"
      html="<blockquote style='border-left: 4px solid #61b6e2; padding-left: 24px; margin: 0;'><p style='color: #414649; font-family: Arial, sans-serif; font-size: 20px; font-style: italic; margin-bottom: 16px;'>\"Customer testimonial goes here. Keep it focused on outcomes and results.\"</p><cite style='color: #0a2043; font-family: Arial, sans-serif; font-size: 16px; font-style: normal;'>— Dr. Name, Title, Institution</cite></blockquote><p style='color: #aaa9ad; font-family: Arial, sans-serif; font-size: 12px; margin-top: 8px;'>Individual results may vary. This testimonial reflects the experience of one practitioner.</p>"
    %}
    
    {# Logo bar for institutional credibility #}
    {% module "logo_bar" path="@hubspot/rich_text"
      label="Institution Logos"
      html="<div style='display: flex; justify-content: center; align-items: center; gap: 40px; margin-top: 40px; flex-wrap: wrap;'><span style='color: #aaa9ad; font-family: Arial, sans-serif;'>Trusted by leading institutions</span></div>"
    %}
    
  </div>
</section>

<!-- ========== HOW IT WORKS / FEATURES SECTION ========== -->
<section class="zv-features" style="background-color: #0a2043; padding: 60px 20px;">
  <div class="zv-container" style="max-width: 1200px; margin: 0 auto;">
    
    {% module "features_content" path="@hubspot/rich_text"
      label="Features/How It Works"
      html="<h2 style='color: #ffffff; font-family: Arial, sans-serif; font-size: 32px; margin-bottom: 40px; text-align: center;'>How It Works</h2><div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 32px;'><div style='background: rgba(255,255,255,0.05); padding: 32px; border-radius: 8px;'><h3 style='color: #61b6e2; font-family: Arial, sans-serif; font-size: 20px; margin-bottom: 12px;'>Step 1</h3><p style='color: #ffffff; font-family: Arial, sans-serif; font-size: 16px;'>Description of first step or feature</p></div><div style='background: rgba(255,255,255,0.05); padding: 32px; border-radius: 8px;'><h3 style='color: #61b6e2; font-family: Arial, sans-serif; font-size: 20px; margin-bottom: 12px;'>Step 2</h3><p style='color: #ffffff; font-family: Arial, sans-serif; font-size: 16px;'>Description of second step or feature</p></div><div style='background: rgba(255,255,255,0.05); padding: 32px; border-radius: 8px;'><h3 style='color: #61b6e2; font-family: Arial, sans-serif; font-size: 20px; margin-bottom: 12px;'>Step 3</h3><p style='color: #ffffff; font-family: Arial, sans-serif; font-size: 16px;'>Description of third step or feature</p></div></div>"
    %}
    
    {% module "product_video" path="@hubspot/video"
      label="Product Video"
    %}
    
  </div>
</section>

<!-- ========== FAQ SECTION ========== -->
<section class="zv-faq" style="background-color: #ffffff; padding: 60px 20px;">
  <div class="zv-container" style="max-width: 800px; margin: 0 auto;">
    
    {% module "faq_content" path="@hubspot/rich_text"
      label="FAQ"
      html="<h2 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 32px; margin-bottom: 40px; text-align: center;'>Frequently Asked Questions</h2><div style='margin-bottom: 24px;'><h3 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 18px; margin-bottom: 8px;'>Question 1?</h3><p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.6;'>Answer addressing common objection or question.</p></div><div style='margin-bottom: 24px;'><h3 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 18px; margin-bottom: 8px;'>Question 2?</h3><p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.6;'>Answer with compliance-appropriate information.</p></div><div style='margin-bottom: 24px;'><h3 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 18px; margin-bottom: 8px;'>Question 3?</h3><p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.6;'>Answer removing friction from decision.</p></div>"
    %}
    
  </div>
</section>

<!-- ========== FORM SECTION ========== -->
<section class="zv-form" style="background-color: #f8f9fa; padding: 60px 20px;">
  <div class="zv-container" style="max-width: 600px; margin: 0 auto;">
    
    {% module "form_heading" path="@hubspot/rich_text"
      label="Form Heading"
      html="<h2 style='color: #0a2043; font-family: Arial, sans-serif; font-size: 28px; margin-bottom: 8px; text-align: center;'>Get Started Today</h2><p style='color: #414649; font-family: Arial, sans-serif; font-size: 16px; text-align: center; margin-bottom: 32px;'>Fill out the form and a ZimVie representative will contact you.</p>"
    %}
    
    {% module "contact_form" path="@hubspot/form"
      label="Contact Form"
      form={
        "form_id": "REPLACE_WITH_FORM_ID",
        "response_type": "redirect",
        "message": "Thank you for your interest. A ZimVie representative will contact you shortly."
      }
    %}
    
    <p style="color: #aaa9ad; font-family: Arial, sans-serif; font-size: 12px; text-align: center; margin-top: 16px;">
      By submitting this form, you agree to receive communications from ZimVie. 
      <a href="#" style="color: #005da6;">Privacy Policy</a>
    </p>
    
  </div>
</section>

<!-- ========== FINAL CTA SECTION ========== -->
<section class="zv-final-cta" style="background-color: #0a2043; padding: 60px 20px;">
  <div class="zv-container" style="max-width: 800px; margin: 0 auto; text-align: center;">
    
    {% module "final_headline" path="@hubspot/rich_text"
      label="Final CTA Headline"
      html="<h2 style='color: #ffffff; font-family: Arial, sans-serif; font-size: 32px; margin-bottom: 16px;'>Ready to [Value Proposition]?</h2><p style='color: #61b6e2; font-family: Arial, sans-serif; font-size: 18px; margin-bottom: 32px;'>Restate the key benefit and urgency.</p>"
    %}
    
    {% module "final_cta" path="@hubspot/button"
      label="Final CTA Button"
      button_text="Primary CTA"
      style={
        "override_default_style": true,
        "button_font": {
          "color": "#0a2043",
          "size": 18,
          "font": "Arial"
        },
        "button_background_color": {
          "color": "#e6dc19"
        },
        "button_border_radius": 4
      }
    %}
    
    <p style="color: #aaa9ad; font-family: Arial, sans-serif; font-size: 14px; margin-top: 24px;">
      Or <a href="#" style="color: #61b6e2;">contact a sales representative</a> to learn more.
    </p>
    
  </div>
</section>

<!-- ========== FOOTER ========== -->
<footer class="zv-footer" style="background-color: #414649; padding: 40px 20px;">
  <div class="zv-container" style="max-width: 1200px; margin: 0 auto;">
    
    {% module "footer_logo" path="@hubspot/logo"
      label="Footer Logo"
    %}
    
    {% module "footer_content" path="@hubspot/rich_text"
      label="Footer Legal"
      html="<p style='color: #aaa9ad; font-family: Arial, sans-serif; font-size: 12px; text-align: center; margin-top: 24px;'>© 2026 ZimVie Inc. All rights reserved. Restoring Daily Life™ is a trademark of ZimVie Inc.<br><a href='#' style='color: #61b6e2;'>Terms of Use</a> | <a href='#' style='color: #61b6e2;'>Privacy Policy</a> | <a href='#' style='color: #61b6e2;'>Cookie Settings</a></p><p style='color: #aaa9ad; font-family: Arial, sans-serif; font-size: 11px; text-align: center; margin-top: 16px;'>For professional use only. Not for distribution to patients. Please refer to the Instructions for Use for complete product information, including indications, contraindications, warnings, precautions, and adverse effects.</p>"
    %}
    
  </div>
</footer>

{% endblock body %}
```

## Module Quick Reference

| Purpose | Module Path | Key Parameters |
|---------|-------------|----------------|
| Text/Headlines | `@hubspot/rich_text` | `html` (string with HTML) |
| CTA Buttons | `@hubspot/button` | `button_text`, `style`, `href` |
| Images | `@hubspot/image` | `src`, `alt`, `loading` |
| Forms | `@hubspot/form` | `form_id`, `response_type`, `message` |
| Video | `@hubspot/video` | `player_id`, `video_type` |
| Logo | `@hubspot/logo` | Uses default site logo |
| Menu | `@hubspot/menu` | `menu_tree`, `flow` |

## Persona-Specific Customizations

### Oral Surgeon
- Emphasize surgical precision, procedural efficiency
- Include case volume/throughput metrics
- Technical specifications prominent

### Periodontist
- Focus on tissue outcomes, regenerative results
- Peer-reviewed study citations
- Long-term success rate data

### GP Implant
- Simplify technical language
- Emphasize learning curve, ease of adoption
- Include training/support availability

### GP Restorative
- Focus on restorative workflow integration
- Emphasize esthetics, patient satisfaction
- Lab compatibility messaging

### Lab Tech
- Technical specs and compatibility front-center
- Material properties, precision metrics
- Workflow efficiency data

### DSO Ops
- ROI calculations, cost per procedure
- Scalability, standardization benefits
- Training and onboarding efficiency

### DSO Clinician
- Protocol standardization benefits
- Multi-location consistency
- Time savings per procedure

## Archetype-Specific Content Adjustments

### Evidence-Driven
- Lead with clinical data, p-values, study citations
- Include "View the research" CTAs
- Add peer-reviewed publication references

### Innovation-Seeker
- Highlight "first-to-market" or "latest generation"
- Emphasize competitive advantage
- Include early adopter testimonials

### Patient-Centered
- Focus on patient outcomes and comfort
- Include patient satisfaction metrics
- Emphasize post-op recovery benefits

### Detail-Focused
- Provide comprehensive technical specifications
- Include downloadable spec sheets
- Add comparison tables

### Efficiency-Focused
- Lead with time/cost savings metrics
- Include ROI calculator or estimates
- Emphasize workflow streamlining
