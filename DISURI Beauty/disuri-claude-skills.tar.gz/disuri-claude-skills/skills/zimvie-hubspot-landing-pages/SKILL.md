---
name: zimvie-hubspot-landing-pages
description: Generate ready-to-paste HubSpot HTML + HubL landing page templates for ZimVie dental marketing campaigns. Use when asked to create a ZimVie landing page, HubSpot landing page for ZimVie, or any landing page targeting dental professionals. Applies ZimVie brand guidelines, asks for persona/archetype, includes FDA compliance reminders, and outputs complete HubL code with recommended modules. Trigger phrases include "ZimVie landing page", "HubSpot landing page", "create landing page for [product]", "landing page template", or requests for dental marketing landing pages.
---

# ZimVie HubSpot Landing Pages

Generate HubSpot HTML + HubL landing page templates that follow ZimVie brand guidelines and conversion best practices.

## Workflow

1. **Gather requirements** — Ask clarifying questions before generating
2. **Apply brand guidelines** — Reference zimvie-brand-guidelines skill for colors, typography, voice
3. **Generate HubL template** — Output complete, ready-to-paste code
4. **Include compliance notes** — Add FDA/medical device reminders

## Required Clarifying Questions

Before generating any landing page, ask:

**Product/Offer**: What product or offer is being promoted? (e.g., TSX Modular Surgical Kit, Biotivity A/C Plus Membrane, webinar registration)

**Persona**: Which ZimVie persona?
- Oral Surgeon
- Periodontist
- GP Implant
- GP Restorative
- Lab Tech
- DSO Ops
- DSO Clinician

**Archetype**: Which decision-making archetype?
- Evidence-Driven (needs clinical data, peer-reviewed studies)
- Innovation-Seeker (wants cutting-edge, first-to-market)
- Patient-Centered (focuses on patient outcomes, comfort)
- Detail-Focused (needs specs, technical documentation)
- Efficiency-Focused (ROI, time savings, workflow optimization)

**Traffic Source**: Where will visitors come from? (email, paid ad, organic search, trade show)

**Primary CTA**: What action should visitors take? (form fill, demo request, download, contact sales)

**Buyer's Journey Stage**:
- Awareness (experiencing problem, researching)
- Consideration (evaluating solutions)
- Decision (comparing vendors, ready to purchase)

## Landing Page Structure

Generate these sections in order:

### 1. Hero Section
- Clear headline matching traffic source message
- Sub-headline with value proposition tailored to persona
- Primary CTA button
- Optional: product image or UI screenshot

### 2. Problem/Pain Section
- Empathize with persona's specific challenges
- Name the core problem they're trying to solve
- Use language appropriate to archetype

### 3. Solution/Benefits Section
- 3-5 scannable bullets
- Focus on outcomes, not just features
- Tailor benefits to persona's priorities

### 4. Social Proof Section
- Customer testimonials (with proper disclosure)
- Case results (must include proper disclaimers)
- Logo bar of recognized institutions
- Statistics with citations

### 5. How It Works / Features Section
- Step-by-step process or key capabilities
- Technical specs for Detail-Focused archetype
- Visual demonstrations where appropriate

### 6. FAQ Section
- Address common objections
- Include compliance-related questions
- Remove friction from decision

### 7. Final CTA Section
- Restate value proposition
- Repeat primary CTA
- Optional: secondary action (contact sales, learn more)

### 8. Form Module
- Minimize fields (name, email, company, specialty minimum)
- Use progressive profiling when possible
- Include proper consent language

## Recommended HubSpot Modules

Use these @hubspot default modules:

| Section | Module | Path |
|---------|--------|------|
| Logo | Logo | `@hubspot/logo` |
| Hero Text | Rich Text | `@hubspot/rich_text` |
| CTA Button | Button | `@hubspot/button` |
| Navigation | Menu | `@hubspot/menu` |
| Images | Image | `@hubspot/image` |
| Forms | Form | `@hubspot/form` |
| Video | Video | `@hubspot/video` |
| Testimonials | Rich Text | `@hubspot/rich_text` |
| FAQ | Rich Text | `@hubspot/rich_text` |

For drag-and-drop flexibility, wrap main content in `{% dnd_area %}` tags.

## ZimVie Brand Application

Apply these brand elements (see zimvie-brand-guidelines skill for full specs):

**Colors**:
- Primary: Navy (#0a2043), Sky Blue (#61b6e2), Lemon (#e6dc19)
- Neutral: Rich Gray (#414649), Silver (#aaa9ad)
- Accent (sparingly): True Blue (#005da6), Poppy (#f47e48), Lime (#a1ce5e)

**Typography**:
- Headlines: Soleil Bold (fallback: Arial Bold)
- Body: Soleil Regular (fallback: Arial)
- Use proper trademark symbols (®/™) on first mention

**Visual Elements**:
- Quarter-circle shapes for section dividers
- Clean product photography on white backgrounds
- Diverse, authentic healthcare professional imagery

## FDA Compliance Reminders

Include these comments in generated templates:

```html
<!-- FDA COMPLIANCE NOTES:
- All claims must be supported by cleared indications for use
- No comparative claims without substantiation
- Include required safety information
- Testimonials must include proper disclosure
- Case results require "individual results may vary" disclaimer
- Review with regulatory before publishing
-->
```

**Copy Guidelines**:
- No unapproved efficacy claims
- Use "designed to" or "intended for" language
- Include contraindications link where appropriate
- All statistics must have citations

## Template Output Format

Generate complete HTML + HubL code that can be pasted directly into HubSpot Design Tools:

```hubl
{% extends "hubspot/base.html" %}

{% block body %}
<!-- Template code here -->
{% endblock body %}
```

Include:
- Semantic HTML structure
- CSS classes using ZimVie naming conventions
- Comments labeling each section
- Editable module regions
- Mobile-responsive viewport meta tag

## Example Usage

**User**: Create a ZimVie landing page for TSX Modular Surgical Kit targeting oral surgeons

**Claude**: Before I generate the template, I need a few details:

1. **Archetype**: Is this oral surgeon primarily Evidence-Driven (needs clinical data), Innovation-Seeker (wants cutting-edge), or Efficiency-Focused (ROI/workflow)?

2. **Traffic Source**: Where will visitors come from? (email campaign, Google Ads, LinkedIn, trade show QR code)

3. **Primary CTA**: What action should they take? (request demo, download brochure, contact rep, register for webinar)

4. **Buyer's Journey Stage**: Are they in Awareness (learning about the problem), Consideration (evaluating solutions), or Decision (comparing vendors)?

[After receiving answers, generate complete HubL template]
