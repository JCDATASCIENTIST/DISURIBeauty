# McKinsey: The Next Big Arenas of Competition

## What Is an Arena?

An arena is a market or set of markets where competition plays out among companies vying for dominance. McKinsey identified 18 arenas projected to generate $29–48 trillion in revenue by 2040, growing at 2-5x the rate of global GDP. Each arena was evaluated on:

- **Total Addressable Market (TAM):** Revenue potential by 2030–2040
- **Growth Rate (CAGR):** Compound annual growth
- **Dynamism:** How frequently the top players change rank — high dynamism = opportunity for new entrants
- **Swing Factors:** External forces that could accelerate or derail the arena

## The 18 Arenas — Strategic Summary

### Tier 1: Massive TAM + High Growth + High Dynamism (Best for wealth creation)

**1. E-commerce**
- TAM: ~$7.9T by 2030
- CAGR: ~15%+
- Dynamism: High — regional leaders differ, new models constantly emerge
- Swing factors: Cross-border logistics, regulation, payment infrastructure, social commerce
- Ad-tech angle: E-commerce runs on advertising. Performance marketing is the lifeblood.
- Wealth path: Build tools that help sellers acquire customers (AI-powered ad optimization, dynamic creative, attribution)

**2. AI Software & Services**
- TAM: ~$600B–800B by 2030 (some estimates higher)
- CAGR: 25-40%+
- Dynamism: Very high — market leaders shifting rapidly as foundation models evolve
- Swing factors: Regulation, compute costs, open vs. closed source, enterprise adoption velocity
- Ad-tech angle: AI is already core to ad targeting, bidding, creative optimization
- Wealth path: Build vertical AI tools for specific industries; AI-native ad platforms; agent-based marketing tools

**3. Cloud & Edge Computing**
- TAM: ~$800B–1T by 2030
- CAGR: 15-20%
- Dynamism: Moderate-high — dominated by hyperscalers but edge computing creates new niches
- Swing factors: Data sovereignty regulations, AI compute demand, edge adoption
- Ad-tech angle: Ad-tech infrastructure runs on cloud; edge computing enables real-time bidding
- Wealth path: Infrastructure-as-a-service for ad-tech, real-time data processing tools

**4. Digital Advertising**
- TAM: $1T+ by 2040
- CAGR: 10-15%
- Dynamism: Moderate-high — privacy changes, AI, and new channels constantly reshaping
- Swing factors: Privacy regulation (cookie deprecation, ATT), AI creative generation, CTV growth, retail media
- Ad-tech angle: This IS the user's home arena
- Wealth path: Build AI-native advertising tools that leapfrog legacy platforms; focus on emerging channels (CTV, retail media, in-game)

### Tier 2: Large TAM + Strong Growth (Wealth opportunity with some risk)

**5. Digital Payments**
- TAM: ~$500B+ by 2030
- CAGR: 12-18%
- Dynamism: Moderate — incumbents strong but fintech disruption real
- Swing factors: Regulation, crypto adoption, embedded payments, BNPL evolution
- Ad-tech angle: Payments data is gold for ad targeting; commerce + payments integration

**6. Streaming Video**
- TAM: ~$300B+ by 2030
- CAGR: 10-15%
- Dynamism: High — subscriber wars, ad-supported tiers emerging, content licensing shifts
- Swing factors: Ad-tier adoption, content costs, sports rights, creator economy
- Ad-tech angle: CTV advertising is the next frontier of digital advertising

**7. Cybersecurity**
- TAM: ~$300B–400B by 2030
- CAGR: 12-15%
- Dynamism: High — threat landscape constantly evolving, new entrants win with innovation
- Swing factors: AI-powered threats, regulation, talent shortage, nation-state attacks
- Ad-tech angle: Low direct adjacency, but ad fraud detection and brand safety are cybersecurity-adjacent

**8. Semiconductors**
- TAM: ~$1T by 2030
- CAGR: 10-15%
- Dynamism: Moderate — very capital-intensive, but AI chip demand creating openings
- Swing factors: Geopolitics (US-China), AI compute demand, new architectures
- Ad-tech angle: Low — chips are hardware, user's skills don't transfer directly
- Note: Wealth opportunity exists but requires deep technical expertise or significant capital

### Tier 3: Emerging / Specialty Arenas (Higher risk, transformative potential)

**9. Electric Vehicles (EVs)**
- TAM: $1.5T+ by 2030
- CAGR: 20-30%
- Dynamism: Very high — new entrants challenging legacy automakers
- Swing factors: Battery costs, charging infrastructure, government subsidies, consumer adoption
- Ad-tech angle: EV marketing is a massive opportunity; brand building for new EV companies needs ad expertise

**10. Battery & Energy Storage**
- TAM: ~$200B+ by 2030
- CAGR: 20-25%
- Swing factors: Raw material costs, new chemistry breakthroughs, grid integration
- Ad-tech angle: Very low direct adjacency

**11. Autonomous Vehicles / Shared Mobility**
- TAM: Highly uncertain, potentially $500B+ by 2035
- CAGR: Early stage, explosive once regulatory approval hits
- Swing factors: Regulation, safety record, public trust, liability frameworks
- Ad-tech angle: In-vehicle advertising is a future opportunity but distant

**12. Robotics**
- TAM: ~$200B–300B by 2030
- CAGR: 15-25%
- Dynamism: Moderate — few dominant players but AI enabling new entrants
- Swing factors: AI/ML capabilities, labor costs, regulation, hardware costs
- Ad-tech angle: Low direct adjacency, but robotics companies need growth marketing

**13. Future Air Mobility (eVTOL)**
- TAM: Uncertain, potentially $100B+ by 2040
- CAGR: Very early stage
- Swing factors: Regulation, safety certification, battery technology, public acceptance
- Ad-tech angle: Very low

**14. Space Economy**
- TAM: ~$600B+ by 2030 (inclusive of satellite, launch, services)
- CAGR: 10-15%
- Swing factors: Launch costs, LEO satellite constellations, government contracts, space tourism
- Ad-tech angle: Satellite-based internet (Starlink) creates new ad reach; space tourism branding

**15. Biotechnology & Pharma Innovation**
- TAM: Very large ($1T+ pharma, growing biotech segment)
- CAGR: 8-15% (biotech innovation faster)
- Swing factors: Regulatory approval, gene therapy breakthroughs, AI drug discovery
- Ad-tech angle: Pharma/health advertising is a massive vertical ($30B+ in US alone)

**16. Green Energy**
- TAM: Multi-trillion by 2040
- CAGR: 15-25%
- Swing factors: Government policy, grid modernization, storage costs, permitting
- Ad-tech angle: Low direct adjacency, but clean energy brands need marketing

**17. Future of Food**
- TAM: Growing segment within $8T+ food industry
- CAGR: 10-20% for alt-proteins, precision agriculture
- Swing factors: Consumer acceptance, regulation, price parity, technology scaling
- Ad-tech angle: DTC food brands rely heavily on performance marketing

**18. Web3 / Blockchain**
- TAM: Highly volatile, $100B–500B estimates
- CAGR: Extremely variable
- Dynamism: Very high — constant disruption and reinvention
- Swing factors: Regulation, institutional adoption, scaling solutions, use-case maturity
- Ad-tech angle: Moderate — Web3 advertising models (token-gated, decentralized), crypto project marketing

## Key Cross-Arena Insights for Wealth Strategy

### Convergence Zones (Where multiple arenas intersect = maximum opportunity)
- **AI + Advertising + E-commerce**: AI-powered shopping experiences, dynamic creative, automated media buying
- **AI + Cloud + Cybersecurity**: Secure AI infrastructure, privacy-preserving ML
- **Streaming + Advertising + AI**: Programmatic CTV, AI-generated ad creative for streaming
- **Digital Payments + E-commerce + AI**: Frictionless commerce, AI-driven fraud detection, personalized checkout

### Dynamism = Your Friend
High-dynamism arenas are where new entrants can win. If you're trying to build wealth through ownership, target arenas where the leaderboard is still being written, not ones dominated by entrenched incumbents.

### Swing Factors = Your Risk Radar
Every arena has 2-3 swing factors that could 2x or kill growth. Build your strategy accounting for these. The best approach: position yourself to benefit regardless of which way the swing factor goes (e.g., build tools for BOTH privacy-restrictive AND privacy-permissive ad environments).
