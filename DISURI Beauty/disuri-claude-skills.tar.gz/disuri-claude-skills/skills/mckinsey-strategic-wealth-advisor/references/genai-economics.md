# McKinsey: The Economic Potential of Generative AI

## Headline Numbers

- **Total annual economic potential of generative AI:** $2.6–4.4 trillion
- This is INCREMENTAL value on top of existing AI/automation potential
- Equivalent to adding a country the size of the UK's GDP to the global economy
- **75% of value** concentrates in four business functions: Customer Operations, Marketing & Sales, Software Engineering, and R&D

## Value by Business Function

### 1. Customer Operations (~$400B annual value)
- **What AI does:** Automates customer interactions, generates agent responses, personalizes service, routes intelligently, summarizes conversations
- **Automation potential:** 60-70% of work activities
- **Key use cases:**
  - AI-powered chatbots handling L1/L2 support
  - Real-time agent assist (suggesting responses, pulling context)
  - Automated ticket classification and routing
  - Proactive customer outreach based on behavioral signals
  - Voice-to-text summarization and quality monitoring
- **Wealth angle:** Build AI customer service tools for specific verticals (e-commerce, SaaS, healthcare). High willingness to pay because customer ops is a cost center companies want to shrink.

### 2. Marketing & Sales (~$400B annual value)
- **What AI does:** Generates content at scale, personalizes messaging, scores leads, optimizes campaigns, creates dynamic creative, automates copywriting
- **Automation potential:** 50-60% of work activities
- **Key use cases:**
  - AI-generated ad copy and creative variations (10x testing velocity)
  - Personalized email/SMS sequences at scale
  - Dynamic landing page generation per audience segment
  - AI-powered lead scoring and prioritization
  - Automated competitive intelligence and market analysis
  - Content repurposing across channels (blog → social → email → ad)
  - AI sales assistants that prep reps with account intelligence
- **Wealth angle:** THIS IS YOUR SWEET SPOT. Build AI tools for marketers. You understand the workflow, the pain points, and the willingness to pay. Specific opportunities:
  - AI creative studio (generate, test, iterate ad creative with AI)
  - Automated campaign management (AI agent that manages campaigns end-to-end)
  - Content engine (turn one piece of content into 50 channel-specific assets)
  - Attribution and analytics AI (make sense of fragmented data)

### 3. Software Engineering (~$300B annual value)
- **What AI does:** Generates code, writes tests, debugs, documents, translates between languages, automates DevOps
- **Automation potential:** 40-55% of work activities
- **Key use cases:**
  - Code generation from natural language descriptions
  - Automated unit test writing
  - Code review and bug detection
  - Documentation generation
  - Legacy code modernization
  - Infrastructure-as-code generation
- **Wealth angle:** Even without a CS degree, AI coding tools enable you to build products. Use AI to code while applying your marketing expertise to build products people want. The "AI-augmented solo founder" is now viable.

### 4. R&D (~$300B annual value)
- **What AI does:** Accelerates drug discovery, materials science, product design, scientific literature analysis
- **Automation potential:** 35-45% of work activities
- **Key use cases:**
  - Molecule generation and screening
  - Materials property prediction
  - Patent analysis and prior art search
  - Experimental design optimization
  - Scientific paper summarization and synthesis
- **Wealth angle:** Requires deep domain expertise. Not your primary path unless you partner with domain experts and contribute growth/commercialization skills.

## Value by Industry

### Industries with Highest Gen AI Impact (Annual Value)

| Industry | Value Range | Key Functions Impacted | Ad-Tech Relevance |
|---|---|---|---|
| Banking | $200–340B | Customer ops, risk, fraud, marketing | High — financial services ad spend is massive |
| High Tech | $240–460B | Engineering, marketing, sales | Very high — you'd be building for peers |
| Retail (incl. e-commerce) | $240–390B | Marketing, supply chain, customer ops | Very high — e-commerce advertising |
| Life Sciences | $60–110B | R&D, regulatory, marketing | Moderate — pharma marketing is specialized |
| Telecom | $60–100B | Customer ops, network optimization | Moderate — telecom ad budgets significant |
| Insurance | $50–70B | Underwriting, claims, customer ops | Low-moderate |
| Education | $30–50B | Content creation, tutoring, admin | Moderate — edtech growth market |

### Strategic Implication
If you're building AI tools, target the industries where BOTH the AI value is large AND you have a distribution advantage. For a digital advertiser:
- **Best targets:** Retail/e-commerce, high tech, banking (marketing functions)
- **Good targets:** Education, media/entertainment
- **Avoid:** Life sciences R&D, insurance underwriting (domain expertise required)

## Labor Market Impact

### Jobs Most Affected
- Knowledge workers in routine cognitive tasks face highest automation risk
- Roles involving data collection, data processing, and repetitive documentation see 60-80% task automation
- Creative and strategic roles see AI augmentation (human + AI), not replacement
- Physical labor sees slower automation (robotics is advancing but less mature)

### New Roles Created
- AI prompt engineers / AI workflow designers
- Human-AI collaboration specialists
- AI ethics and governance professionals
- AI product managers
- Vertical AI solution architects

### The Re-skilling Imperative
- McKinsey estimates up to 12 million occupational transitions needed in the US alone by 2030
- Workers who learn to work WITH AI see productivity gains of 30-60%
- Workers who ignore AI risk displacement or wage stagnation

## Adoption Timeline and Requirements

### What Accelerates Adoption
- Quality of AI output reaching "good enough" for the use case
- Ease of integration with existing workflows and tools
- Demonstrated ROI (ideally measurable within 3-6 months)
- Trust and safety mechanisms in place
- Regulatory clarity

### What Slows Adoption
- Data quality and availability issues
- Integration complexity with legacy systems
- Regulatory uncertainty (especially in healthcare, finance, legal)
- Organizational resistance to change
- Concerns about accuracy, hallucination, and liability
- High compute costs for training/inference

### Adoption Curve Prediction
- **Now–2025:** Early adopters in tech, marketing, customer service
- **2025–2027:** Mainstream adoption in knowledge work functions
- **2027–2030:** Deep integration into all business functions; industry-specific models
- **2030+:** Ubiquitous; competitive disadvantage for non-adopters

## Key Takeaways for Wealth Strategy

1. **Build where the value is:** Marketing/Sales and Customer Ops are the two largest value pools AND the most accessible for someone with advertising expertise.

2. **Industry focus matters:** E-commerce/retail and high tech are the best target industries — large AI value AND you understand the customer.

3. **Speed wins:** Adoption is still early. First movers who build AI-native tools (not retrofitted legacy tools) will capture disproportionate market share.

4. **AI as equalizer:** Gen AI enables small teams to produce output that previously required 10-50x the headcount. This is the golden age for solo founders and small teams.

5. **The productivity gap creates opportunity:** Companies that adopt AI see 30-60% productivity gains. Build tools that deliver these gains and charge a fraction of the labor cost savings.

6. **Don't just use AI — own AI infrastructure:** Using AI tools is table stakes. Building AI tools is where the wealth is. Be a toolmaker, not just a tool user.
