---
name: display-ad-specs
description: Comprehensive display and native ad specification tool for StackAdapt and Google Performance Max campaigns. Generate creative briefs with platform specs, validate ad creatives against requirements, provide quick reference lookups, create mockup specifications, and produce campaign-ready asset checklists. Use when creating display ad briefs, validating specs, planning campaigns, generating asset lists, or creating mockups for StackAdapt or Google Performance Max.
---

# Display Ad Specs

Comprehensive specification tool for StackAdapt and Google Performance Max display and native advertising campaigns.

## Core Workflows

### 1. Generate Creative Brief

When user requests a creative brief for a campaign:

1. **Clarify campaign details** (if not provided):
   - Platform(s): StackAdapt, Google Performance Max, or both
   - Ad formats: Display, native, responsive, or all
   - Primary sizes needed (or recommend common sizes)
   - Campaign objective and messaging

2. **Generate comprehensive brief** including:
   - Campaign overview and objectives
   - Platform-specific specs for all required formats
   - File requirements (format, size, resolution)
   - Mockup specifications (see section below)
   - Asset checklist with all deliverables
   - Best practices and guidelines

3. **Format output** as clean markdown with:
   - Clear headers for each section
   - Tables for specs when appropriate
   - Checklist format for deliverables
   - No excessive bullet points or formatting

### 2. Create Mockup Specifications

When creating mockup specs or design guidance:

1. **Specify exact dimensions** in pixels for each size
2. **Include visual hierarchy guidance**:
   - Headline placement and character limits
   - Description/body copy placement and limits
   - CTA placement and character limits
   - Logo/branding placement
   - Safe zones (center 80% for content)

3. **Provide design requirements**:
   - Text overlay recommendations (at least 1 image without overlay per aspect ratio)
   - Image quality standards (72+ DPI minimum, 144+ DPI recommended)
   - File format and size constraints
   - Brand compliance notes if applicable

4. **Create mockup template** with:
   - Artboard dimensions for each size
   - Safe zone guides
   - Text placement guides
   - Export specifications

### 3. Validate Ad Creatives

When user asks to validate specs or check requirements:

1. **Identify platform and format** being validated
2. **Check against requirements**:
   - Dimensions (exact pixels)
   - File format (JPG, PNG, GIF, HTML5)
   - File size limits
   - Resolution requirements
   - Text overlay compliance
   - Character limits for text assets
   - Safe zone compliance

3. **Provide clear validation result**:
   - ✓ Passes all requirements
   - ✗ Fails with specific issues listed
   - ⚠ Warning for optional but recommended improvements

### 4. Generate Asset Checklist

When user needs a campaign-ready asset list:

1. **List all required assets** by platform and format
2. **Organize by priority**: Required vs. optional
3. **Include specifications** inline with each asset
4. **Add quantity guidance** (e.g., "4+ unique images recommended")
5. **Format as actionable checklist** with checkboxes

### 5. Quick Reference Lookup

When user asks for specific size or spec information:

1. **Provide exact specifications** for requested size/format
2. **Include all relevant constraints** (dimensions, file format, file size, resolution)
3. **Add context** (when/where this size is used)
4. **Keep response concise** - just the facts needed

## Platform Specifications

### StackAdapt Display Ads

#### Common Display Sizes
| Size Name | Dimensions | Category |
|-----------|-----------|----------|
| Medium Rectangle | 300x250 | Desktop |
| Large Rectangle | 300x280 | Desktop |
| Leaderboard | 728x90 | Desktop |
| Large Leaderboard | 970x90 | Desktop |
| Wide Skyscraper | 160x600 | Desktop |
| Half-Page | 300x600 | Desktop |
| Mobile Leaderboard | 320x50 | Mobile |
| Mobile Interstitial | 320x480 | Mobile |

#### File Requirements
- **Formats**: JPG, PNG, GIF
- **Static file size**: Under 750 KB (JPG/PNG optimal)
- **Animated file size**: 3.5 MB max (GIF)
- **Resolution**: 72 DPI minimum, 144+ DPI recommended
- **Quality**: High-resolution images required

#### Native Display Specs (In-Ad)
- **Image**: High-resolution, no text overlay
  - Common sizes: 1200x628, 600x600
- **Headline**: 15-55 characters
- **Description/Caption**: Up to 120 characters
- **Sponsored By**: Up to 25 characters
- **Call-to-Action (CTA)**: Up to 10 characters

### Google Performance Max

#### Responsive Display Image Ratios
| Aspect Ratio | Recommended | Minimum | Status |
|--------------|-------------|---------|--------|
| Horizontal (1.91:1) | 1200x628 | 600x314 | Required (4+ images, up to 20) |
| Square (1:1) | 1200x1200 | 300x300 | Required (4+ images, up to 20) |
| Vertical (4:5) | 960x1200 | 480x600 | Optional (2+ images, up to 20) |

#### Logo Specifications
| Type | Recommended | Minimum | Status |
|------|-------------|---------|--------|
| Square Logo (1:1) | 1200x1200 | 128x128 | Required (1 logo, up to 5) |
| Horizontal Logo (4:1) | 1200x300 | 512x128 | Optional (1 logo, up to 5) |

**Logo Note**: Logos with transparent backgrounds may render on white in most ads. Upload square logos and avoid predominantly white logos on transparent backgrounds.

#### File Requirements
- **Formats**: JPG or PNG only
- **Maximum file size**: 5 MB (5120 KB)
- **Resolution**: High-resolution required
- **Safe zone**: Content in center 80% of image (won't be cut off)

#### Text Overlay Guidelines
- Use images with text/graphic overlays sparingly
- **Recommended**: At least 1 image WITHOUT overlays per aspect ratio (square, horizontal, vertical)
- Text overlays are allowed but not preferred for all images

#### HTML5 Ads
- **Required meta tags**:
  - `<meta name="productType" content="dynamic">`
  - `<meta name="vertical" content="RETAIL">`
- **Parameters**: "Responsive" parameter set to true
- **Maximum file size**: 600 KB (614,400 bytes)

### Common Desktop Display Sizes (Google)
| Size Name | Dimensions |
|-----------|-----------|
| Medium Rectangle | 300x250 |
| Large Rectangle | 336x280 |
| Leaderboard | 728x90 |
| Large Leaderboard | 970x90 |
| Wide Skyscraper | 160x600 |
| Half-Page | 300x600 |

### Common Mobile Display Sizes (Google)
| Size Name | Dimensions |
|-----------|-----------|
| Mobile Leaderboard | 320x50 |
| Large Mobile Banner | 320x100 |

### Other Popular Sizes (Google)
| Size Name | Dimensions |
|-----------|-----------|
| Square | 250x250 |
| Small Square | 200x200 |
| Banner | 468x60 |

## Best Practices

### Image Quality
- Use high-resolution images (144+ DPI recommended)
- Ensure images are relevant to queries and ad context
- Convey unique selling features visually
- Use both static image assets and dynamic image assets when possible

### Asset Diversity
- Add 4+ unique images at asset group level (Performance Max)
- Use varying aspect ratios (square, horizontal, vertical)
- Include images with and without text overlays
- Test different creative approaches

### Performance Optimization
- Monitor Asset Report for performance data (Performance Max)
- Wait 2-3 weeks before evaluating ad strength
- Replace low-performing assets based on data
- Ensure excellent ad strength for best results

### Compliance
- Confirm legal rights to all images
- Grant permission to share with platform for advertising
- Meet all format requirements to avoid disapprovals
- Review ads go through quality and policy checks before serving

## Output Templates

### Creative Brief Template

```markdown
# [Campaign Name] Display Ad Creative Brief

## Campaign Overview
- **Objective**: [Primary campaign goal]
- **Target Audience**: [Key demographics/personas]
- **Key Message**: [Main value proposition]
- **Platform(s)**: [StackAdapt / Google Performance Max / Both]

## Required Assets

### [Platform Name] Display Ads
- [ ] Medium Rectangle (300x250) - JPG/PNG, <750KB, 144+ DPI
- [ ] Leaderboard (728x90) - JPG/PNG, <750KB, 144+ DPI
- [ ] [Additional sizes as needed]

### [Platform Name] Native Ads
- [ ] High-res image (1200x628) - No text overlay
- [ ] Headline (15-55 characters): [Example text]
- [ ] Description (120 characters): [Example text]
- [ ] CTA (10 characters): [Example text]

## Mockup Specifications
[See Mockup Specifications section for detailed layout guides]

## File Delivery Requirements
- Format: JPG or PNG
- Resolution: 144 DPI minimum
- Color Mode: RGB
- File Naming: [campaign-name]_[size]_[version].jpg

## Brand Guidelines
[Include relevant brand elements, colors, fonts, logo usage]

## Timeline
- Creative Brief Approval: [Date]
- First Draft Due: [Date]
- Final Assets Due: [Date]
- Campaign Launch: [Date]
```

### Validation Checklist Template

```markdown
## Display Ad Validation Checklist

### File Specifications
- [ ] Correct dimensions (exact pixels)
- [ ] Correct file format (JPG/PNG/GIF)
- [ ] File size within limit
- [ ] Resolution meets minimum (72+ DPI)

### Design Requirements
- [ ] Content within safe zone (center 80%)
- [ ] At least 1 image without text overlay (per aspect ratio)
- [ ] Text legible at actual size
- [ ] Brand guidelines followed

### Text Assets (Native Ads)
- [ ] Headline within character limit
- [ ] Description within character limit
- [ ] CTA within character limit
- [ ] All text proofread and approved

### Legal & Compliance
- [ ] Legal rights to all imagery confirmed
- [ ] Platform-specific policies reviewed
- [ ] Medical/financial disclaimers included if needed
- [ ] Copyright notices included if required

### Technical
- [ ] All files properly named
- [ ] RGB color mode (not CMYK)
- [ ] Logos with appropriate background handling
- [ ] HTML5 ads include required meta tags (if applicable)
```

## When to Reference This Skill

Use this skill when users need:
- Creative briefs for display ad campaigns
- Spec validation before campaign launch
- Quick size/format lookups during planning
- Mockup specifications for designers
- Asset checklists for campaign management
- Cross-platform spec comparisons
- Best practice guidance for display advertising

Always provide exact, platform-specific requirements rather than generalizations.
