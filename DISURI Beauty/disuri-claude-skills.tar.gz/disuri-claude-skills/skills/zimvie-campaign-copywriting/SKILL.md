---
name: zimvie-campaign-copywriting
description: FDA-compliant copywriting frameworks for ZimVie dental/medical device marketing. Use when writing product launch copy, social media posts, email campaigns, landing pages, ad copy, or any marketing content for dental professionals (oral surgeons, periodontists, general dentists, prosthodontists, dental labs). Provides HOOK, FAB, and PAS frameworks with examples. Trigger phrases include "product copy", "marketing copy", "social post", "email copy", "ad copy", "landing page copy", "FDA compliant", or any request for ZimVie marketing content.
---

# ZimVie Campaign Copywriting

## Target Audiences
- Oral Surgeons
- Periodontists
- General Dentists (implant-placing)
- Dental Labs
- Prosthodontists

## Core Copywriting Frameworks

### 1. HOOK Format
Attention-grabbing statement that creates curiosity. Opens with a bold claim or question, then expands with supporting context.

**Structure:**
1. Hook statement (curiosity/benefit-driven)
2. Supporting context (2-3 sentences)
3. CTA

**Examples:**
```
"Say yes to more patients."
One integrated system for every case complexity. The TSX Kit gives you clinical versatility, workflow flexibility, and the confidence to take on more.

"Start with what you need today. Expand tomorrow."
The modular architecture scales as your practice grows—no need to replace your entire surgical setup.
```

### 2. FAB Format (Feature → Advantage → Benefit)
Translates product specs into customer value. Start with what it is, explain why it matters, then connect to clinical/business outcomes.

**Structure:**
1. Feature: What the product has/does
2. Advantage: Why that feature matters technically
3. Benefit: The clinical/business outcome for the customer

**Examples:**
```
Feature: "Full arch module for organized chairside seating"
Advantage: "Includes angled screw channel drivers for TiBases"
Benefit: "Keeps full arch instrumentation at your fingertips—reducing chair time"

Feature: "Universal compatibility across TSX, TSV, and Aesthetic lines"
Advantage: "Place any implant from 3.1 to 6.0mm diameter without switching systems"
Benefit: "Match the right implant to each case with complete clinical freedom"

Feature: "Color-coded drilling protocol"
Advantage: "Visual guidance for soft and dense bone approaches"
Benefit: "Eliminate guesswork and reduce training time for new team members"
```

### 3. PAS Format (Problem → Agitation → Solution)
Empathy-driven copy that acknowledges pain points before introducing the solution.

**Structure:**
1. Problem: State the challenge they face
2. Agitation: Emphasize the frustration/cost of the problem
3. Solution: Present the product as the answer

**Examples:**
```
Problem: "Switching between systems for different implant types?"
Agitation: "No more searching for tools. No more wondering which driver fits."
Solution: "Complete freedom to match the right implant to each case without switching systems."

Problem: "Inherited patients with legacy implants you can't identify?"
Agitation: "Hours spent searching for compatible components. Delayed treatment. Frustrated patients."
Solution: "ZimVie's legacy implant support helps you identify Biomet 3i, TSV, and Zimmer systems in minutes."
```

## Channel-Specific Guidelines

### LinkedIn (B2B Primary)
- Post length: 150-300 words
- Hook in first line (visible before "see more")
- Professional tone, clinical language
- 3-5 hashtags: #DentalImplants #Periodontology #OralSurgery #ZimVie #[ProductHashtag]
- Best times: Tuesday-Thursday, 7-8 AM or 12 PM

**Template:**
```
[HOOK: Problem statement or compelling question]

[CONTEXT: 2-3 sentences about the challenge dental professionals face]

[SOLUTION: Introduce product and key benefit]

[PROOF POINT: Clinical advantage or feature highlight]

[CTA: Learn more at the link in comments]

#DentalImplants #Periodontology #OralSurgery #ZimVie #[ProductHashtag]
```

### Instagram/Facebook
- Caption: 100-250 characters above fold
- Visual-first approach
- Carousel format for education (5-10 slides)
- Reels: 15-30 seconds for highest reach
- "Link in bio" for IG, direct links for FB

### Email Subject Lines
- 40-50 characters (6-10 words)
- Lead with benefit or curiosity
- Avoid spam triggers: "free", "act now", "limited time"
- Personalize when possible: "Dr. [Name]"
- Use emoji sparingly (1 max, test performance)

### Display Ads (StackAdapt)
- Headline: 25-40 characters (benefit-focused)
- Body: 70-90 characters max
- CTA: "Learn More", "Download Brochure", "See the Kit"

## Quote Card Best Practices

Extract powerful soundbites from video transcripts for social graphics:

**Best TSX Kit Quotes:**
- "The TSX Kit is organized into intuitive modules that integrate seamlessly into your workflow."
- "Clinical versatility, workflow flexibility, and giving you the confidence to say yes to more patients."
- "Everything is organized and ready when you need it—reducing chair time and eliminating the guesswork."
- "You can place everything from 3.1 to 6.0 millimeter diameter implants."
- "This is yours to add your personal favorite instruments to."

## FDA Compliance Reminders

1. **Use approved claims only** — all copy must pass Legal/Regulatory review
2. **No comparative claims** without documented clinical evidence
3. **Include required disclaimers** on all materials
4. **Trademark symbols** — apply ®/™ on first mention in body copy
5. **"Clinician only" disclaimer** where required: "This material is intended for clinicians only and does not comprise medical advice or recommendations."

## UTM Tracking Convention

```
?utm_source=[platform]&utm_medium=[channel]&utm_campaign=[product-name]-launch&utm_content=[content-type]
```

Examples:
- LinkedIn organic: `utm_source=linkedin&utm_medium=organic&utm_campaign=tsx-kit-launch`
- Email blast: `utm_source=hubspot&utm_medium=email&utm_campaign=tsx-kit-launch`
- Display ad: `utm_source=stackadapt&utm_medium=display&utm_campaign=tsx-kit-launch`

## Quick Copy Checklist
- [ ] Leads with benefit or curiosity (not feature)
- [ ] Written for target audience (clinical language for HCPs)
- [ ] Uses one of three frameworks (HOOK, FAB, PAS)
- [ ] CTA is clear and actionable
- [ ] UTM parameters included on all links
- [ ] Trademark symbols on product names
- [ ] Legal/Regulatory review completed
- [ ] Brand voice: Passionate, Disruptive, Proactive, Agile
