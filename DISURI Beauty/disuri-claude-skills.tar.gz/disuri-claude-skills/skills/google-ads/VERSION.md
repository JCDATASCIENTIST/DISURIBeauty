---
description: Google Ads Skill Version History
---

# Google Ads Skill — Version History

## v1.0 — 2026-02-20 — FINALIZED ✅

### Status: Deploy ready. 8/8 evals passing (100%).

### Contents
- `SKILL.md` — Router, diagnostic framework, intake questions, universal best practices
- `references/` — 14 reference files covering all campaign types and dental/medical device specialization
- `evals/` — 8 evals with machine-readable evals.json and human-readable EVAL-GUIDE.md

### Reference Files
| File | Coverage |
|------|---------|
| `search-and-ai-max.md` | Search campaigns, AI Max, Smart Bidding, broad match |
| `performance-max.md` | PMax setup, asset groups, audience signals, search themes |
| `demand-gen.md` | Demand Gen campaigns, creative, audiences, bidding |
| `youtube-video.md` | YouTube awareness & consideration, Video Reach, frequency |
| `display-and-remarketing.md` | Display, responsive display ads, optimized targeting |
| `shopping-and-retail.md` | Shopping, product feeds, Merchant Center, retail PMax |
| `app-campaigns.md` | App installs, in-app actions, deep links, iOS measurement |
| `lead-gen.md` | Lead generation, enhanced conversions, offline imports |
| `data-and-measurement.md` | Data Strength, Data Manager, enhanced conversions, GA4 |
| `creative-assets.md` | RSAs, ad strength, image assets, video, Asset Studio |
| `local-and-calls.md` | Store visits, Business Profile, call ads, local inventory |
| `dental-medical-device.md` | Medical device regulatory compliance, HCP/patient personas |
| `dental-device-knowledge-sources.md` | Industry knowledge sources and enrichment guide |
| `account-architecture.md` | Consolidation, segmentation, prohibited legacy methods |

### Eval Results
| Eval | Topic | Result |
|------|-------|--------|
| GA-1 | Smart Bidding Threshold | ✅ 5/5 |
| GA-2 | Medical Device Headlines | ✅ 6/6 |
| GA-3 | Account Consolidation Audit | ✅ 6/6 |
| GA-4 | PMax Healthcare Compliance | ✅ 7/7 |
| GA-5 | Attribution Ground Truth | ✅ 5/5 |
| GA-6 | Full RSA Build | ✅ 8/8 (post-fix) |
| GA-7 | Invalid Segmentation Reason | ✅ 5/5 |
| GA-8 | Bid Strategy Progression | ✅ 5/5 |

### Changelog
- **v1.0**: Initial release. All 14 reference files, 8 evals, full eval suite passed.
- **v1.0.1** (same day): Fixed `creative-assets.md` — added mandatory inline character count requirement to RSA output template. GA-6 re-eval confirmed 8/8 clean pass after fix.

### Known Gaps for v1.1
- Demand Gen campaign structure for dental device awareness (eval candidate)
- YouTube video asset requirements for medical device product (eval candidate)
- Shopping / product feed setup for dental consumables (eval candidate)
- Competitor conquesting compliance boundaries (eval candidate)
- Multi-location DSO local campaign setup (eval candidate)
