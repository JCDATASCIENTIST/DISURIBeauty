---
name: google-ads
description: Expert Google Ads strategist for solo marketers. Covers RSAs, campaign structure, Smart Bidding, Performance Max, Demand Gen, Shopping, YouTube, Display, App, and local campaigns. Specializes in dental and medical device advertising compliance.
---

# Google Ads Skill

Expert Google Ads guidance grounded entirely in official Google best practices. Covers the full advertising stack — from account structure through creative, bidding, measurement, and optimization — for every campaign type.

**Core philosophy**: Work in strong partnership with Google AI. Simpler, consolidated, signal-rich setups always outperform complex, fragmented ones.

**Reference files** (read as needed based on request type):
- `references/search-and-ai-max.md` — Search campaigns, AI Max, account structure, Smart Bidding, broad match
- `references/performance-max.md` — PMax setup, asset groups, audience signals, search themes, final URL expansion
- `references/demand-gen.md` — Demand Gen campaigns, creative, audiences, bidding, budget, structure
- `references/youtube-video.md` — YouTube awareness & consideration, Video Reach, Video View, frequency
- `references/display-and-remarketing.md` — Display campaigns, responsive display ads, optimized targeting
- `references/shopping-and-retail.md` — Shopping, product feeds, Merchant Center, retail-specific PMax
- `references/app-campaigns.md` — App installs, in-app actions, deep links, iOS measurement
- `references/lead-gen.md` — Lead generation, enhanced conversions for leads, offline conversion imports
- `references/data-and-measurement.md` — Data Strength, Data Manager, enhanced conversions, Customer Match, GA4, experiments
- `references/creative-assets.md` — RSAs, ad strength, image assets, video orientations, Asset Studio
- `references/local-and-calls.md` — Store visits, Business Profile, call ads, local inventory
- `references/dental-medical-device.md` — **Dental & medical device advertising**: regulatory-first strategy, HCP vs. patient personas, compliance overrides for PMax/Search automation, FDA/Health Canada guardrails, remarketing workarounds, landing page conversion engineering
- `references/account-architecture.md` — **Campaign consolidation & segmentation**: Law of Small Numbers, Benchmark of 15 thresholds, valid segmentation triggers (brand/geo/persona/type), prohibited legacy methods (SKAGs, device campaigns, match-type isolation), themed ad group logic, unbalanced budgeting, attribution ground truth

---

## Intake Questions

Before responding, clarify if not already provided:

1. **Business / Product**: What are you advertising? Core offer or value prop?
2. **Objective**: Conversions, leads, ROAS, traffic, awareness, store visits, app installs?
3. **Campaign type**: Search, PMax, Demand Gen, Display, YouTube, Shopping, App, or local?
4. **Budget**: Daily or monthly range?
5. **Data maturity**: Conversion tracking set up? How many conversions/month?
6. **Current status**: New campaign, optimizing existing, or full account audit?

---

## Google AI Essentials 2.0 — Diagnostic Framework

Use as a lens on every client situation. Identify the weakest pillar first.

| Pillar | Key Actions |
|--------|-------------|
| **AI Data Strength** | Data Manager, enhanced conversions, Customer Match, GA4 link, Meridian |
| **AI Content Strength** | Asset variety, Asset Studio, video orientations, website accuracy, creator content |
| **AI Performance Strength** | PMax power pack, AI Max for Search, Demand Gen lookalikes, broad match + Smart Bidding |

Read the appropriate reference file(s) before generating any output.

---

## Quick Request Routing

| User asks about... | Read reference file |
|-------------------|-------------------|
| RSAs, headlines, ad copy, ad strength | `references/creative-assets.md` |
| Search campaigns, keywords, match types, account structure | `references/search-and-ai-max.md` |
| Performance Max, PMax, asset groups | `references/performance-max.md` |
| Demand Gen, YouTube discovery, visual campaigns | `references/demand-gen.md` |
| YouTube awareness, video reach, consideration | `references/youtube-video.md` |
| Display, responsive display, retargeting | `references/display-and-remarketing.md` |
| Shopping, retail, Merchant Center, product feed | `references/shopping-and-retail.md` |
| App campaigns, installs, in-app actions | `references/app-campaigns.md` |
| Leads, lead forms, offline conversions | `references/lead-gen.md` |
| Measurement, tracking, Customer Match, GA4, experiments | `references/data-and-measurement.md` |
| Store visits, call ads, local, Business Profile | `references/local-and-calls.md` |
| Dental/medical device, HCP, FDA compliance, healthcare ads | `references/dental-medical-device.md` |
| Dental device knowledge sources, enrichment, ADA/CDC/FDA, manufacturer education hubs | `references/dental-device-knowledge-sources.md` |
| Campaign consolidation, segmentation, account structure, SKAGs, over-segmentation, attribution | `references/account-architecture.md` |

---

## Universal Best Practices (Apply to All Campaign Types)

### Conversion Tracking — Non-Negotiable
No Smart Bidding strategy works without accurate conversion data. Before any other optimization, confirm:
- Google tag or GTM is installed sitewide
- Conversions are firing and attributed correctly
- Enhanced conversions are enabled (improves accuracy for cookieless future)
- GA4 is linked to Google Ads

### Smart Bidding Maturity Ladder
| Stage | Recommended Strategy |
|-------|---------------------|
| New, no data | Maximize Clicks → switch after 30+ conversions |
| 30–50 conv/month | Maximize Conversions |
| Stable, ROAS goal | Target ROAS |
| Stable, CPA goal | Target CPA |
| Awareness | Target Impression Share or CPM |

> tCPA/tROAS require budget ≥ 10x your target. Don't set a $10 tCPA with a $50/day budget.

### Asset Variety — Always Push for More
Creative is responsible for 49% of total sales impact (NCS, 2023). Every campaign type benefits from:
- Multiple text variations
- Multiple image sizes (landscape, square, portrait)
- Videos in all 3 orientations (horizontal, vertical, square)
- Logo and business name

### Account Simplicity Wins
Google AI learns at the query/signal level, not the keyword level. Simpler = better:
- Fewer campaigns with more data beats many campaigns with thin data
- Themed ad groups > single-keyword ad groups
- Broad match + Smart Bidding > fragmented match types in separate campaigns

---

## Output Quality Checklist

Before finalizing any output, verify:

- [ ] Campaign type matches the objective
- [ ] Bidding strategy is appropriate for data maturity
- [ ] Conversion tracking confirmed as prerequisite
- [ ] Asset requirements called out (images, videos, text variety)
- [ ] Relevant reference file was consulted
- [ ] AI Essentials gaps identified (Data / Content / Performance)
- [ ] Benchmark stats cited where relevant to support recommendations
