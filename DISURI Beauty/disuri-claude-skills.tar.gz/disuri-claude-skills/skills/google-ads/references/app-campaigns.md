---
description: App Campaigns Reference
---

# App Campaigns

## What App Campaigns Do
Promote your app across Google's largest channels: Search, Google Play, YouTube, Gmail, and the Google Display Network. Google AI analyzes hundreds of millions of signal combinations and tests different creative + channel combinations to serve best-performing ads.


## Step 1: Define Your Goals
Share your goals — App campaigns optimize bidding and targeting to match:
- **Build a user base**: App installs
- **Engage users**: Drive specific in-app actions
- **Pre-registration**: Sign-ups before app launches


## Step 2: Upload Diverse Creative

Provide a diverse mix of text, video, and image assets. App campaigns dynamically generate creative optimized for reach and performance across channels.

**Slots available:**
- Up to 10 text assets
- Up to 20 image assets
- Up to 20 video assets
- Up to 20 HTML5/playable assets (for mobile games)
- **Use all available asset slots**

### Text Assets
- Write standalone phrases that vary in length (different placements have different text limits)
- Focus on unique selling points
- Include conversational text with clear CTAs

### Image Assets
- Utilize the full ad frame with limited blank space
- High pixel density, minimal text overlay
- Avoid superimposing logos and CTAs directly on image

### Video Assets
- Length: **10–30 seconds**
- Include all aspect ratios: portrait, landscape, and square
- Different orientations = more channels and device positions covered

### Ad Strength
- Use the **Ad Strength indicator** to evaluate asset diversity
- Monitor **asset performance ratings** in asset report
- Replace low-performing assets with new ones regularly


## Step 3: Deep Links (Web-to-App)

For users who already have your app installed, deep links bring them from a mobile web ad directly to relevant in-app content.

**Business impact**: Advertisers implementing deep linking see **2X+ uplift in conversion rate** (Google Data, Feb 2022)

### Implementation
- Use **Web to App Connect**: one-stop destination with guided steps for marketing + developer teams
- Covers: deep link setup, conversion tracking, and bidding configuration


## Step 4: Measurement (Privacy-Centric)

### Conversion Tracking
- Set up to measure app installs and in-app actions driven by App campaigns

### Google Analytics 4 (Firebase)
- Unlock measurement across website and app
- Use alongside Google-approved App Attribution Partners (complementary, not replacement)

### Conversion Modeling
- Google's conversion modeling fills in measurement gaps from iOS restrictions

### iOS-Specific Measurement
- Set up **SKAdNetwork conversion value schema** (can be done via GA4)
- Consider implementing **ATT prompt** and **on-device conversion measurement** to increase observed conversions
- Use GA4 to register your app with SKAdNetwork for cross-network install measurement


## For Retailers Running App Campaigns
- Drive customer loyalty through your app
- Win new app users across Google Play, Search, and YouTube with App campaigns for installs
- Use Web to App Connect to build a seamless web-to-app customer journey
