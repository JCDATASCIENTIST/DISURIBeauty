---
description: Account Architecture Reference
---

# Account Architecture — Modern Standards for Campaign Consolidation & Segmentation

## The Core Mandate: Algorithmic Synergy Over Manual Control

Modern SEM has shifted from manual, granular control to **data density and algorithmic synergy**. Your job as an account architect is no longer to pull every lever — it's to build a framework that lets Google's machine learning thrive.

Two mistakes consistently block this:
1. **Over-complexity** — Accounts that start logically but devolve into a "cable drawer" of redundant campaigns, conflicting settings, and tangled targeting — an insane Rubik's Cube no one can manage.
2. **Outdated strategy adherence** — Clinging to 15-year-old tactics for the illusion of control, while manual delivery is now provably inferior to automated optimization.

The mandate: **Less is more.**


## The Scientific Case for Consolidation

### The Law of Small Numbers
Machine learning needs a concentrated volume of conversion signals to find patterns. Fragmenting budget across many campaigns starves the algorithm of the data it needs.

Analogy: Rolling a die 6 times rarely produces one of each number. Rolling it a million times guarantees near-equal distribution. In Google Ads, a campaign with 2 conversions is statistically meaningless — a few more clicks could change reported ROAS by 100% instantly. High volume through fewer campaigns eliminates this volatility.

### The Benchmark of 15 — Algorithmic Patterning Thresholds
Consolidation targets, not minimums:

| Conversion Volume | What It Unlocks |
|------------------|-----------------|
| **15 conv/30 days** | Minimum threshold — algorithm begins learning |
| **150 conv/30 days** | Stability improves; ML accuracy meaningfully better |
| **1,500 conv/30 days** | Elite optimization — algorithm identifies non-obvious high-value user traits |

The goal is always to push conversion density toward 150+ by consolidating campaigns. A campaign at 12 conversions/month that could be merged with another to reach 28 should be merged.


## When to Segment: The Only Valid Triggers

Consolidation is the **default**. Segmentation is only justified when performance profiles or business objectives diverge so sharply that a single campaign can't serve them.

### Valid Segmentation Triggers

**1. Brand vs. Non-Brand** — Always separate
- Branded searches have unique intent, lower CPCs, and skewed quality metrics
- Mixing them contaminates non-brand data and distorts what "real" acquisition performance looks like
- Includes creative brand identifiers (e.g., "British Facebook ads guy" belongs in brand, not generic search)

**2. Geographic Markets with Materially Different Performance**
- Separate ONLY when markets show significant variance in CVR or CPC (e.g., California vs. Mississippi with 3x different conversion rates)
- If markets perform similarly (e.g., UK vs. US for a digital SaaS product), keep them consolidated
- "I want separate reporting" is NOT a valid segmentation reason — use dimensions and filters instead

**3. Distinct Major Service/Product Ranges with Different Buyer Personas**
- Separate when the audience and buying process fundamentally differ
- ✅ Residential vs. Commercial landscaping (different personas: homeowners vs. procurement officers)
- ✅ Done-For-You high-ticket service vs. Done-With-You mentorship (different price points, intent, journey)
- ❌ Red Hats vs. Blue Hats — do NOT separate product variations
- The test: "Does this require different messaging AND a different buyer?" If not, consolidate.

**4. Campaign Type**
- Search vs. Performance Max must remain separate (functional requirement)
- Different campaign types cannot be merged

### The Default Test
If you cannot articulate a **specific strategic reason** why a split improves performance rather than just providing different reporting views — consolidate.


## Prohibited Legacy Methods: The Control Fallacy

The "Control Fallacy" is the dangerous belief that manual segmentation outperforms automated delivery. In reality, manual fragmentation restricts algorithm visibility and forces sub-optimal bidding.

### Practices to Eliminate Immediately

| Legacy Method | Why It's Harmful |
|--------------|-----------------|
| **Device-Specific Campaigns** (splitting mobile/desktop/tablet) | Outdated 15-year-old tactic; ignores cross-device behavior; starves algorithm of unified signals |
| **Keyword Match-Type Isolation** (separate campaigns for broad/phrase/exact of the same keyword) | Creates internal competition; fragments conversion data; counterproductive under Smart Bidding |
| **SKAGs (Single Keyword Ad Groups)** | Creates an insane complexity Rubik's Cube; extreme account bloat; makes theme-based optimization impossible |
| **Separating geographic markets with similar performance** | Fragments budget without benefit; reduces conversion density in each campaign |
| **Splitting campaigns by device bid adjustments** | Smart Bidding already handles device at bid-time — manual overrides add noise |

**The Directive**: Stop trying to out-segment the machine. Trusting platform intelligence is now a competitive requirement, not a luxury.


## Micro-Architecture: Themed Ad Group Logic

Consolidation at the campaign level does not mean abandoning internal organization. Within each campaign, structure ad groups by **theme or buyer persona** — not by match type or device.

### The Alignment Rule
Every ad group must achieve **absolute alignment** across three elements:
> **Search Term → Ad Copy → Landing Page**

If a user searches "dental implant guided surgery kit," they must land on a page about guided surgery kits — not a general products page. Misalignment kills Quality Score, conversion rate, and wastes spend.

### Themed Ad Group Example (Landscaping Business)
- **Ad Group 1 — Grass Cutting**: "lawn mowing," "grass maintenance," "lawn care service"
- **Ad Group 2 — Patios**: "patio laying," "patio installation," "patio removal"
- **Ad Group 3 — Flowerbeds**: "rockeries," "shrubbery," "flowerbed maintenance"

Each theme has its own ad copy and dedicated landing page. Performance by theme reveals where to push more budget — if Patios consistently outperforms Grass Cutting, shift budget accordingly.


## Strategic Resource Allocation: Unbalanced Budgeting

Modern architecture demands **unbalanced budgeting**. You do not need to advertise every product equally.

**Do not make this mistake**: Splitting $15,000/month evenly across 15 products at $1,000 each.

**Do this instead**:
- Identify your 2–3 highest-ROAS "best sellers"
- Concentrate the majority of budget there
- Move lower-performing products to secondary channels: email sequences, upsells, retargeting (where permitted), or organic/social

This is the advertising equivalent of Adjusted R² — more variables (campaigns) does not mean more explanatory power. It often means less.


## Attribution and the "Ground Truth" Problem

Consolidated architecture is only as good as the data feeding it. **Google Ads consistently under-reports conversions** — sometimes by 30–50%.

### The Discrepancy Problem
Google Ads UI might show 3 conversions while third-party attribution (Hyros, Northbeam, Triple Whale, etc.) shows 6 actual conversions — a 50% gap. Without correcting for this, you risk:
- Pausing profitable consolidated campaigns that look like they're underperforming
- Making budget allocation decisions on incomplete data
- Misattributing performance to the wrong campaigns

### Ground Truth Principle
**Always establish a "ground truth" baseline from third-party tracking** before making structural changes to a consolidated account. Compare:
- Google Ads reported conversions vs. actual CRM/backend conversions
- Attribution window differences (view-through, click-through, cross-device)
- Revenue reported in Google Ads vs. actual revenue in your payment system

Use this reconciled data — not Google's reported numbers alone — to evaluate whether campaigns should be paused, consolidated, or scaled.


## Account Architecture Decision Framework

```
Is the question "Should I separate these campaigns?"

Step 1: Are they different campaign types (Search vs PMax)? 
  → YES: Separate (required)
  → NO: Continue to Step 2

Step 2: Is one branded and one non-branded?
  → YES: Separate (always)
  → NO: Continue to Step 3

Step 3: Do the markets show materially different CVR or CPC?
  → YES (significant variance): Consider separation
  → NO (similar performance): Consolidate
  → Continue to Step 4 if uncertain

Step 4: Are these fundamentally different buyer personas with different messaging?
  → YES (different audience, different journey, different copy): Separate
  → NO (just different products/variations): Consolidate

Default answer if still unsure: CONSOLIDATE
```


## Quick Reference: New Rules of Account Architecture

1. **Consolidate for Data** — Group budgets and keywords to maximize conversion density toward the 150+ threshold
2. **Segment for Strategy Only** — Separate only when intent, geo performance, or buyer personas truly diverge
3. **Eliminate for Efficiency** — Purge all legacy "control" tactics; focus budget on proven winners
4. **Verify with Ground Truth** — Use third-party attribution before making structural changes based on Google-reported data
5. **Organize Internally with Themes** — Consolidate campaigns but maintain logical themed ad groups with full search term → ad copy → landing page alignment
