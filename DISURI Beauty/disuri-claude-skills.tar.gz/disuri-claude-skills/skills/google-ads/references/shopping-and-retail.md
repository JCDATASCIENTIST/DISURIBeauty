---
description: Shopping and Retail Reference
---

# Shopping & Retail Campaigns

## Prerequisites
- Products uploaded to **Google Merchant Center**
- Merchant Center linked to Google Ads
- Having at least 10 product offers improves overall performance


## Product Feed Best Practices

### Visual Quality
- Use **close-up product shots with white background** — makes product details clear, drives engagement
- In the US: 3D images available for shoes and home goods via Manufacturer Center
  - People engage **~50% more** with 3D images vs. static images (Google Internal Data)

### Data Accuracy
- Keep price and availability **current** — stale data = bad ad experience
- Upload rich product descriptions
- Update frequently if prices/availability change often

### Feed Attributes to Maximize
- Accurate titles with key product attributes
- Rich descriptions
- High-quality images
- Correct pricing and availability
- Fulfillment options (shipping, local pickup)
- Deals and promotions


## Campaign Setup for Retail

### Performance Max with Product Feed (Recommended)
- Connect Merchant Center feed → PMax uses it for Shopping inventory
- Enables **Local Inventory Ads** (in-store product availability in ads)
- Best for: online sales, omnichannel (online + in-store)
- Upgrade from Standard Shopping → PMax → avg. **27% more conversions** at similar CPA/ROAS

### Search + PMax Together
- PMax captures demand across all channels; Search captures high-intent searchers
- Combine broad match + Smart Bidding + RSAs in Search alongside PMax

### App Campaigns for Retail
- Drive customer loyalty and business performance through your app
- Use Web to App Connect for deep linking from web ads to app content


## Retail-Specific PMax Settings

### New Customer Value Mode
- Prioritize new customers while still converting existing ones
- +9% ROAS, +5% new customer ratio, -7% new customer acquisition cost
- "New Customer Only Mode": +11.5% new-to-returning ratio, -3% new customer acquisition cost

### Retention Goal
- Bid more for lapsed customers
- Specify high-LTV customers for priority bidding

### Final URL Expansion
- Enable to let PMax find the most relevant landing page per user intent
- Use URL exclusions for non-conversion pages (careers, blog, FAQ)


## Optimization Tools

### Performance Planner
- Create plans for advertising spend
- Assess how campaign changes affect key metrics before making them

### Insights Page
- Just-in-time trends and forward-looking insights
- Understand how customer interests and preferences are shifting
- Check often to stay ahead of demand changes

### Recommendations & Optimization Score
- Review regularly and apply recommendations aligned with business goals
- Each recommendation shows estimated Optimization Score impact
- Optimization Score: estimates how well the account is set to perform

### Product Insights
- **Product Issues column** in Products tab: understand individual product performance
- Spot underperforming offers
- Identify products with missing feed attributes
- See how competitive your products' bids are

### Merchant Center Reporting
- **Best sellers report**: Make inventory decisions, prioritize products for advertising
- **Price competitiveness report**: Improve pricing and bidding on top products
- Reporting API: Ingest and analyze data at scale


## Local Inventory Ads
- Connect Business Profile (for physical locations) to Google Ads
- Enables "in-store availability" to show in Shopping ads
- PMax with store goals: drives store visits + online sales together


## Case Study Reference
- **IKEA Belgium**: Smart Bidding for store visits on Search + Shopping → **361% revenue increase YoY**
