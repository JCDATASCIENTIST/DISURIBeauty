---
description: Lead Gen Reference
---

# Lead Generation Best Practices

## Core Philosophy
Map the full lead-to-sale journey before setting up any campaign. Your conversion goal selection directly determines how Google AI optimizes.


## Step 1: Map the Lead-to-Sale Journey

### Choose a Single Conversion Goal for Bidding
- Chart the path: first interaction → qualified lead → closed lead
- Track: final sale values, conversion rates, average time between stages
- **Do NOT select goals from multiple stages** of the journey — pick the one that most directly aligns with your business goal and bidding

### Good Lead Gen Conversion Goals
These automatically trigger **invalid traffic protections** built specifically for lead gen:
- "Qualified lead"
- "Converted lead"
- "Book appointment"
- "Request quote"

### Volume & Freshness Requirements
- Goal must have generated **≥15 conversions in last 30 days** at account level
- If using enhanced conversions for leads or offline imports: upload data **daily** (ideally)
- Choose conversion actions that happen within **7 days** of ad interaction for timely optimization


## Step 2: Build a Strong Measurement Foundation

### Enhanced Conversions for Leads
- Improves accuracy of online and offline conversion measurement
- Grounded in first-party data rather than Google Click ID
- Enables: easier data imports, engaged-view and cross-device conversion tracking
- **+10% more conversions** vs. standard offline conversion import (Google Data, May–June 2024)

### Offline Conversion Imports
- If currently using offline imports: upgrade to Enhanced Conversions for Leads for better durability and accuracy

### Data Manager
- Simplifies tag implementation
- Enables CRM connections (HubSpot, Salesforce, and others)
- Makes Customer Match and Enhanced Conversions for Leads easier to use


## Step 3: Activate AI-Powered Campaigns

### Value-Based Bidding (If Leads Have Different Values)
- Use **Maximize Conversion Value** or **Maximize Conversion Value with tROAS**
- Apply **Conversion Value Rules** to refine by geography, device, and audiences
- Prioritizes budget toward your most valuable leads

### If All Leads Are Equal Value
- Use **Target CPA bidding** for qualified or converted leads

### Broad Match + Smart Bidding (Search)
- Keeps pace with evolving consumer search behavior
- Reaches wider range of relevant, valuable queries

### Campaign Types for Lead Gen

| Campaign Type | Best For |
|-------------|---------|
| **Search** | Capture in-market demand from searchers |
| **Performance Max** | Multiply leads across all Google channels (Search, YouTube, Display, Discover, Gmail, Maps) |
| **Demand Gen** | Create demand when customers aren't actively searching (visual/immersive) |
| **App campaigns** | Win new app users who engage with your business via app |

**Add to Search, PMax, Video, and Display campaigns**:
- **Call assets**: Let leads call directly from the ad
- **Lead form assets**: Let leads submit info directly in the ad


## Step 4: Optimize and Expand

### Content Suitability
- Use content and placement exclusions to control where ads appear
- Brand exclusions: avoid serving for branded queries you want to exclude

### Lead Verification
- Implement ReCAPTCHA, double opt-in, or server-side validation to ensure lead authenticity

### Budget and Target Alignment
- Set bid targets based on past campaign performance patterns (seasonality, promotions)
- If campaigns are budget-constrained → you're leaving conversions on the table
- CPA/ROAS targets act as your spend levers — align them with actual ROI goals

### Performance Planner
- Create ad spend plans and model how campaign changes affect KPIs before making them


## Lead Gen Asset Checklist
- [ ] Single, focused conversion goal selected
- [ ] ≥15 conversions/month at account level
- [ ] Enhanced conversions for leads enabled
- [ ] CRM connected via Data Manager
- [ ] Call assets added (if calls are valuable)
- [ ] Lead form assets added to relevant campaigns
- [ ] Value-based bidding set up if leads have different values
- [ ] Content suitability settings applied
