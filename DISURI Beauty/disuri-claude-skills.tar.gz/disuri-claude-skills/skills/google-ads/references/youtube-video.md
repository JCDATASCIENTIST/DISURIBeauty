---
description: YouTube and Video Reference
---

# YouTube Awareness & Consideration Campaigns

## Note on Naming
"Awareness and consideration" has been renamed to **"YouTube reach, views, and engagements"** for new campaigns. Same features, same functionality.


## Awareness Strategies

### Strategy 1: Grow Brand Awareness
- **Essential**: Video Reach Campaign Non-Skips
- **Supporting**: Premium Suite (YouTube Select / Sponsorships / Masthead)
- **Enrich**: Video Reach Campaigns Efficient Reach
- Primary KPIs: Unique Reach (Non-Skippable)
- Secondary KPIs: Watch Time, % CTV Delivery, Brand Lift, Lower CPMs

### Strategy 2: Maximize Reach & Frequency
- **Essential**: Video Reach Campaign Target Frequency
- **Supporting**: Video View Campaigns
- **Enrich**: Premium Suite
- Primary KPIs: Increased Avg. Frequency per User, Higher Absolute Brand Lift
- Secondary KPIs: Maximize Unique Reach at Desired Frequency, Higher ROI, Lower CPMs

### Strategy 3: Broaden Exposure to New Audiences
- **Essential**: Video Reach Campaigns Efficient Reach
- **Supporting**: Video View Campaigns
- **Enrich**: Premium Suite
- Primary KPIs: Unique Reach, Lower CPM
- Secondary KPIs: Incremental Reach to TV, Higher ROI, Higher Number of Lifted Users


## Consideration Strategy

### Create Interest & Grow Brand Equity
- **Essential**: Video View Campaigns
- **Supporting**: Video Reach Campaigns Efficient Reach
- **Enrich**: Premium Suite
- KPIs: Views, Consideration Lift, Search Lift Increase, Earned Actions


## Campaign Implementation Best Practices

### Planning
- Use **Reach Planner** before launch to ensure setup will meet performance goals
- Use **Meridian** to identify optimal frequency and anticipated ROI uplift
- Adjust bids, budget, flight dates, and targeting to achieve desired outcomes

### Reach & Frequency
- Recommended frequency: **3x per week** as a general rule of thumb
- Use a **2X multiplier** when planning for a month (vs. week) or during peak seasonality
- A typical brand can improve ROI by **19%** by achieving 2.7/week avg. weekly frequency (Meridian MMM study, 392 US brands)

### Targeting
- Recommended: demo, detailed demo, affinity, or custom affinity audiences
- **Content targeting** does NOT work on home feed (will block serving)
- **Shorts**: Limited reach with contextual targeting; placement targeting may block serving
- Go as **broad as possible** — let Google AI optimize multi-format campaigns

### Creatives
**Video Reach Campaigns**:
- Include a mix: short (<10s / 6s for bumper), medium (10–20s), long (>30s)
- Provide varying orientations: horizontal and vertical
- VRC campaigns with portrait + square + landscape → more effective at lifting **brand awareness**
- More assets = higher effectiveness
- Feature brand **early and often** in creative

**Video View Campaigns**:
- Take **>30s** to craft a compelling narrative
- Use vertical and square videos to reach customers where they are
- Drive relatability: testimonials, creators, real-life moments
- VVC campaigns with portrait + square + landscape → more effective at lifting **brand consideration**

### Placements / Format Mix
- Mix formats via automation for better results and reduced redundancy
- Mixing In-Stream + In-Feed + Shorts (Video Reach) → **35% more Unique Reach** vs. In-Stream only
- VVC mix of In-Stream + In-Feed + Shorts → **94% higher ROAS** vs. In-Stream alone
- Format Segment Reports: segment by In-feed, Skippable In-stream, Shorts for granular reporting

### Bidding
- Start competitive based on historic CPM bids (for Efficient Reach) or CPV bids (for Video View)
- Use bid guidance in-platform — it accounts for all settings and targeting
- Low bids cause under-pacing and may prevent serving on some formats


## Measurement

### KPIs by Strategy
| Strategy | Primary KPIs |
|---------|-------------|
| Grow brand awareness | Brand awareness lift, Incremental reach to TV, Completion, % CTV |
| Maximize reach & frequency | ROI, Reach, CPM, Frequency |
| Broaden exposure | Reach, Search Lift increase |
| Create interest / grow equity | Consideration Lift, Views, Search Lift, Earned Actions |

### Brand Lift Study
- Provides insight into how people feel about your product/brand
- Ensure recommended budget minimums are met before initiating
- Contact Google account representative to set up

### Search Lift
- Measures how ads impact likelihood to search for your product/brand on YouTube and Google Search

### Cross-Media Reach Measurement
- Deduplicated, on-target reach and frequency across YouTube and TV
- Helps compare efficiency and optimize investment across devices and formats

### Attribution Reports
- Shows paths customers took to complete conversions
- Understand how brand advertising efforts work together to create conversions

### Format Segment Reports
- Go to Segment > Format (Video only) for VTR and viewability by individual format
- Available for Video Reach Campaigns Efficient Reach and Video View Campaigns


## Brand Safety & Content Suitability

### Inventory Types (Main Control)
- Standard inventory recommended for most brands
- Limited inventory = for most sensitive advertisers
- YouTube content meets 99% effectiveness for brand safety (GARM Brand Safety Floor)

### Content Exclusions
- Exclude content types: live streams, embedded videos (optional, for sensitive brands)
- Use excluded themes to avoid topics across videos (1–2 exclusions typical for most brands)
- >10 topic exclusions → CPMs over **40% higher** than those excluding ≤10 topics
- Don't over-exclude — it limits reach and raises CPMs

### Specific Exclusions (When Needed)
- **Account-level negative keywords**: Exclude specific terms incongruent with your brand
- **Placement exclusions**: Exclude specific channels or videos
- **Account-level content suitability settings**: Consistent application across all campaigns
