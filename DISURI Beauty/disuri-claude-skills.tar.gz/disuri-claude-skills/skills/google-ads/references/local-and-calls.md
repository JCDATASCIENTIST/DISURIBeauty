---
description: Local and Calls Reference
---

# Local Marketing, Store Visits & Call Ads

## Local Marketing Overview
Customer journeys often start online and finish in-store. Google Ads tools help bridge online ads to offline actions.


## Store Visits & Local Sales

### Step 1: Build Your Digital Storefront
- Set up a **Business Profile** to manage online presence across Google Search and Maps
- Link Business Profile to Google Ads to enable location-based ad features and store visit measurement

### Step 2: Compelling Local Ad Creative
- Use **location-based messaging**: mention city, neighborhood, or "near you"
- **Quantified promotions**: "15% off", "Buy one get one free" — specific offers entice store visits
- Short videos and clear images of your physical location or products
- Clear CTAs: "Visit us today", "In stock now at [location]"

### Step 3: Tools for Driving Store Sales

**Smart Bidding for store visits**: Optimizes bids toward driving in-store traffic
- **IKEA Belgium**: Smart Bidding for store visits on Search + Shopping → **361% revenue increase YoY**

**Performance Max with store goals**:
- Drives omnichannel outcomes: online sales + in-store visits from a single campaign
- Use omnichannel goals to capture demand offline

**Local Inventory Ads**:
- Surfaces in-store product availability in Shopping ads
- Connects with shoppers searching for products available nearby

### Step 4: Measure Offline Value
- **Store Visits Conversions**: Google measures offline store visits attributed to your ads
- **Local Actions**: Track calls, direction requests, and other local interactions
- **Store Sales Measurement**: Connect in-store sales data back to ad performance
- **Attribution Reports**: Understand how brand advertising contributes to conversions over time


## Call Ads & Call Assets

### When to Prioritize Calls
Decide whether clicks to website OR calls to business are more valuable. If calls deliver significantly higher value, consider **call ads** instead of standard search ads.

### Set Up Call Ads for Success

**Ad text**:
- Write text that showcases your company's value and drives customers to call
- Users need a compelling reason to dial

**Scheduling**:
- Schedule ads **only when staff can answer**
- Use call reporting insights to staff appropriately based on call volumes and times

**Call Reporting**:
- Enables detailed call tracking: frequency, lengths, time of day
- Use insights to improve call center staffing

### Measure Calls as Conversions

**Call reporting**: Track calls from ads — provides details and enables tracking calls as online conversions

**Conversion tracking for calls**:
- Identify which keywords, campaigns, and targeting drive valuable calls
- Enables optimization of targeting, bidding, and budget toward call-generating elements

**Website call conversions**:
- Some users browse before calling — track website-sourced calls too
- Captures the full attribution picture regardless of when the call happens

### Optimize Call Ad Performance

**Bidding**: Bid according to the value calls deliver — don't treat all conversions equally if calls are worth more

**Website optimization**:
- Display phone numbers prominently for desktop visitors
- Enable **click-to-call** for mobile visitors
- Mobile optimization has outsized impact on call volume

**Call experience**:
- Cultivate relevant call experiences (just like landing pages)
- Relevant call experiences → higher conversion rates and more customers won


## Google Ads Mobile App (For On-the-Go Management)

### Monitor Performance
- Account Overview page: latest performance + interactive cards (Auction Insights)
- View performance at account, campaign, ad group, ad, and keyword level

### Take Action
- Check **recommendations** at least weekly
- **Optimization Score** prioritizes recommendations by impact potential
- Quick actions available from mobile: pause/enable campaigns, set budgets, create/edit RSAs

### Stay on Track
- Set up **custom notifications** from Settings: weekly performance summary, ad disapprovals
- Security: enable screen lock and 2-step verification when managing on mobile
- Contact support via Help page: phone, chat, or email


## Google Analytics Best Practices (for Local & All Advertisers)

### Link GA4 to Google Ads
- Bid for GA4 conversions and audiences
- Mark key events as conversions in Google Ads

### Predictive Audiences
- Build in GA4: likely purchasers, likely churners, etc.
- Apply to Google Ads campaigns for higher-intent targeting
- BAUR (German retailer): +56% sales using likely purchaser audience; 70% reachable only via predictive audiences

### Ecommerce Reporting
- Add ecommerce reporting for detailed product/service sell-through data
- Use with retail campaigns for product-level performance insight

### Benchmarking
- Enable to see performance rankings vs. competitors in your category

### iOS App Measurement
- Set up SKAdNetwork schema in GA4
- Register your app with SKAdNetwork for cross-network install measurement
