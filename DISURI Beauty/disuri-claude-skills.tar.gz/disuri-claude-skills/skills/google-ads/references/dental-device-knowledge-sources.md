---
description: Dental Device Knowledge Sources Reference
---

# Dental Device Expert Skill — Knowledge Sources & Enrichment Guide

## Overview

This document maps the primary sources for enriching the dental device expertise in this skill. Sources are organized into three buckets: manufacturer content, neutral standards/safety content, and independent clinical education. Always surface the source type in responses so clinicians can weigh bias and regulatory status appropriately.

**Important framing rule**: Any clinical instruction content should be framed as educational, never as a substitute for manufacturer IFUs, local regulations, or specialist consultation — especially for implants and surgery.


## Bucket 1: Manufacturer & Device Landscape

Use these to build the skill's brand dictionary, category ontology, and terminology normalization (e.g., recognizing that "RealGUIDE" maps to ZimVie → Surgical Planning Software → Digital Implantology).

### Market/Landscape Lists
- **Mordor Intelligence US Dental Devices Companies** — Overview of major dental device companies (Dentsply Sirona, Straumann Group, Envista, 3M, ZimVie, etc.) with market context
  - https://www.mordorintelligence.com/industry-reports/usa-dental-devices-market/companies
- **Clinicians Report Dental Company List** — Massive alphabetical index of dental manufacturers across categories: implants, equipment, consumables, software
  - https://www.cliniciansreport.org/companies.php

### Distributor/Manufacturer Directories
- **SupplyDoc Manufacturers** — Curated list of dental product and device manufacturers (3M, Air Techniques, American Eagle, SciCan, SS White, etc.); mine for brand names and product lines
  - https://supplydoc.com/pages/manufacturers
- **TDSC Manufacturers List** — Updated list of dental manufacturers carried by TDSC; keeps brand dictionary current
  - https://www.tdsc.com/manufacturers

**Build from these**: An ontology that maps manufacturer names → product categories (implants, imaging, handpieces, delivery units, sterilization, software) → normalizes synonyms and trade names.


## Bucket 2: Manufacturer Clinical Education & Product Instructions

These are the "expert voice" sources — how devices are used, clinical indications, workflows, and best practices. Highest signal for clinical how-to content.

### Implant Systems (Primary)
- **Nobel Biocare Continuing Education** — Large library of implant CE courses, on-demand webinars, and education journeys covering diagnosis, treatment planning, surgical/prosthetic workflows, and complication management
  - https://www.nobelbiocare.com/en-us/education
- **ZimVie Dental** — Education resources, RealGUIDE surgical planning, biomaterials clinical guides
  - Search zimvie.com for "clinical resources" and "education"
- **Straumann Group** — Clinical protocols, digital workflows, bone regeneration guides
  - Search straumann.com for "education" section
- **Envista / Implant Direct** — Search brand education hubs
- **Glidewell Clinical Education** — Live and online courses on implant placement and restorative workflows; very practical, procedure-oriented content
  - https://glidewelldental.com/company/blog/a-road-map-to-live-and-online-training-in-dental-implants

### General Devices & Equipment
- **DENTALEZ Dental Delivery Systems Guide** — Selection, maintenance, and repair considerations for dental delivery units
  - https://dentalez.com/news-happenings/the-complete-guide-to-dental-delivery-systems-part-2/
- **3M, Dentsply Sirona, BIOLASE** — Each brand publishes clinical guides, tech specs, and IFU PDFs for restorative materials, curing lights, and imaging systems
  - Search each brand's website for "clinical guide," "instructions for use," or "technical documentation"

**Skills you can build from these**:
- *Implant workflow explainer* — Stepwise implant questions grounded in Nobel/Straumann/ZimVie/Glidewell education content
- *Device know-how advisor* — Maps a product name (curing light, delivery unit, surgical kit) to manufacturer best-practice use, maintenance, and troubleshooting


## Bucket 3: Neutral Standards, Safety & Best-Practice Content

Use these to counterbalance manufacturer bias and cover reprocessing, infection control, regulatory compliance, and safety. Critical for any skill giving guidance on clinical protocols.

### ADA Sources
- **ADA News** — Article on manufacturer instructions guiding purchase and use of dental products, with emphasis on validated reprocessing instructions and FDA expectations for reusable instruments
  - https://adanews.ada.org/ada-news/2021/july/manufacturer-instructions-play-vital-role-in-guiding-purchase-use-of-dental-products/
- **ADA Standards Committee Technical Reports** — Reprocessing of burs, handpieces, etc.
- **ADA Clinical Evaluators (ACE) Reports** — Usage patterns and selection factors (e.g., curing lights, materials)

### CDC & FDA
- **CDC Infection Control for Dental Settings** — Reprocessing, disinfection, sterilization protocols
  - Search CDC.gov for "infection control in dental settings"
- **FDA Guidance on Reprocessing Reusable Medical Devices** — Regulatory requirements and validation
  - Search FDA.gov for "reprocessing reusable devices guidance"

**Skills you can build from these**:
- *Reprocessing & infection-control advisor* — Summarizes validated reprocessing steps; flags when a device should be treated as single-use based on labeling
- *Device selection advisor* — Surfaces neutral criteria (portability, power, durability, cost, compatibility) when comparing equipment like curing lights or delivery units


## Bucket 4: Independent Education & Expert Commentary

Use these to answer "how do experts think about picking X?" rather than quoting manufacturer brochures. Provides balance and practitioner perspective.

- **Implant Education Company** — Didactic + cadaver/live-surgery implant CE with detailed procedure descriptions (All-on-4, sinus lifts, bone grafting, etc.)
  - https://www.implantedco.com
- **Curate Studios — Ultimate Guide to Dental Equipment** — Interviews multiple experts, breaks down decision criteria and product categories
  - https://www.curatestudios.com/blog/the-ultimate-guide-to-dental-equipment


## How to Wire Into Skill Types

| Skill Type | Primary Sources |
|-----------|----------------|
| **Device catalog & mapping** | Mordor, Clinicians Report, SupplyDoc, TDSC |
| **Implant clinical advisor** | Nobel Biocare, Straumann, ZimVie, Glidewell education hubs |
| **Equipment selection coach** | ADA CE reports, DENTALEZ guide, Curate Studios expert guide |
| **Reprocessing & safety checker** | ADA/CDC/FDA + manufacturer IFUs |
| **Regulatory/compliance advisor** | FDA device guidance, ADA Standards, ZimVie regulatory docs |


## Source Transparency Rules

When responding with skill-derived content, always label the source type:
- `[Manufacturer]` — e.g., "Per ZimVie clinical documentation..."
- `[ADA Guidance]` — e.g., "ADA Standards recommend..."
- `[FDA/CDC]` — e.g., "FDA guidance states..."
- `[Independent CE]` — e.g., "Per Glidewell's clinical education content..."

This lets clinicians weigh regulatory status and manufacturer bias appropriately.


## ZimVie-Specific Source Priority

Since this skill is built with ZimVie context, prioritize these source categories for ZimVie content:
1. ZimVie.com clinical resources, RealGUIDE documentation, and biomaterials product guides
2. ZimVie education and CE content (dental implants, bone grafting, digital workflow)
3. Neutral ADA/FDA standards that apply to ZimVie product categories (implants, bone grafts, membranes)
4. Competitor education hubs (Nobel, Straumann) for workflow context and comparison framing
