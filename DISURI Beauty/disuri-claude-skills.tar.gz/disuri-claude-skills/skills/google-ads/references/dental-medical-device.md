---
description: Dental and Medical Device Reference
---

# Dental & Medical Device Google Ads — Industry-Specific Reference

## Why This Is Different
Medical and dental device advertising on Google operates under a completely different set of rules than standard DTC or B2B advertising. Regulatory compliance (FDA, Health Canada, Google's own health privacy policies) overrides most standard automation best practices. **Always apply these constraints first, then layer in performance best practices.**


## Audience Context

### Dual Audience: HCP vs. Patient
Dental device campaigns typically serve two distinct personas:
- **HCP (Healthcare Professional)**: Dentists, oral surgeons, periodontists, prosthodontists, dental lab technicians — clinical decision-makers
- **Patient / Consumer**: End patient researching treatment options, often pre-consultation

These personas require **separate asset groups** (in PMax) and persona-specific copy. Never mix them into the same ad group.


## 1. Search Campaigns — High-Intent Keyword Targeting with Value-Based Bidding (VBB)

### Keyword Strategy
- Start with **exact and phrase match only** — use technical qualifiers like "device" or "equipment"
- Examples: `[dental implant device]`, `"bone graft equipment"`, `[guided surgery kit]`
- Broad match is particularly risky in medical device: it may surface unqualified, non-professional, or consumer queries that waste budget or create compliance risk
- Build intent around clinical/capital equipment language, not consumer symptom language

### Match Type Discipline
- **Do NOT use Dynamic Search Ads (DSA)**: DSA auto-generates ad copy from your website — this bypasses the regulatory review process and can produce unvetted, non-compliant headlines
- Tight match types = tighter control over what queries trigger your ads

### Value-Based Bidding (VBB) Threshold
- Implement VBB only **after ≥25 conversions/month** to have sufficient data for meaningful optimization
- Track revenue or sales estimates per conversion — dental capital equipment is high-ticket; optimizing for lead volume alone is a mistake
- VBB shifts focus from lead count to lead quality and downstream revenue

### Conversion Impact
- High-intent keyword targeting prevents ~90% budget waste on unqualified traffic
- Shifts optimization from volume to high-ticket capital equipment quality


## 2. Performance Max (PMax) — Brand Safety and Compliant Audience Signaling

### Critical: Turn Off Final URL Expansion
- **Disable Final URL Expansion** in PMax for medical/dental device campaigns
- Standard PMax best practice is to leave this ON, but for medical devices: automated URL expansion can generate unvetted copy tied to URLs and may surface pages not cleared for advertising
- Maintain manual control over exactly which landing pages serve as ad destinations

### Asset Groups: Persona-Specific
- Create separate asset groups for **HCP audiences** and **Patient audiences**
- Different messaging, different CTAs, different trust signals for each
- HCP: clinical outcomes, peer-reviewed evidence, device specifications, CE marks
- Patient: procedure overview, practitioner referral framing, safety profile, ISI visibility

### Audience Signals (Not Retargeting)
- Upload **client lists** (existing HCP database, past purchasers) and **website visitors** as audience signals — not direct retargeting targets
- This is a critical compliance distinction: Google's health privacy policy prohibits standard cookie-based remarketing for medical devices
- Using lists as **signals** (to help AI find lookalikes) is compliant; using them as **explicit retargeting targets** is not
- This speeds up machine learning while navigating health privacy restrictions

### Disable Automatically Created Assets
- Turn OFF "automatically created assets" in all PMax asset groups
- AI-generated assets for medical devices risk: omitting required risk disclosures, making unsupported clinical claims, generating copy not reviewed by regulatory/legal/medical affairs
- Every asset must be pre-approved before entering the campaign

### Benefits of This Approach
- Scales across Google inventory while maintaining compliance control
- Leverages the "Mere Exposure Effect" — multi-placement visibility builds brand recognition across channels
- Identity resonance: finds lookalike HCPs and patients similar to your highest-value existing customers


## 3. Ad Copy — Regulatory-First Creative Lockdown

### Pre-Approval Workflow
- All headlines and descriptions must be **pre-approved** through your regulatory/medical affairs review process before entering Google Ads
- If your organization uses a content management system (e.g., **Veeva**), store and lock approved copy there and import to campaigns
- Establish a formal approval pipeline: Marketing → Medical Affairs → Regulatory → Legal → Campaign

### What to Lock Down
- Disable: **"automatically created assets"** (prevents AI from generating unapproved copy)
- Disable: **text customization** in Search and PMax (which auto-generates headlines from landing pages)
- Disable: **Dynamic Search Ads** (auto-generates copy from site content)
- Pin critical regulatory language in RSA headline/description slots as needed

### Copy Requirements
- **FDA compliance**: All claims must be within approved indication; include fair balance where required
- **ISI (Important Safety Information)**: Must be visible; include risk disclosures
- **Clinical accuracy**: All efficacy/outcomes claims must be supported by evidence on file
- Avoid superlatives without substantiation: "best," "most effective," "proven" require data backup
- Use precise, vetted medical terminology — this builds trust with HCP audiences via authority transfer

### Psychological Effectiveness of Regulatory-First Copy
- **Trust transfer mechanism**: Precise medical terminology transfers clinical authority to the practitioner audience
- Maintains brand authority and professional trust in a skeptical, highly educated audience


## 4. Remarketing — Workaround for Healthcare Restrictions

### The Compliance Problem
- Google's health privacy policy **prohibits standard cookie-based remarketing** for medical devices
- You cannot create standard remarketing audiences based on users who visited device product pages, treatment pages, or condition-related content

### Compliant Workaround: Custom Segments for Intent-Based Targeting
Create **Custom Segments** targeting users who:
- Searched for **your brand name** on Google (brand intent signal)
- Browse websites **similar to your competitors** (competitive intent signal)
- Use keywords related to your device category in their search history

### Why This Works
- Reaches interested prospects who cannot be reached via standard retargeting
- Complies with Google's health privacy policy — targeting is based on **intent signals** (search behavior), not health condition inferences
- Ads appear based on recent professional intent, making messaging feel highly personalized
- **Relevance framing**: message appears at the right moment in the HCP's research journey


## 5. Landing Page Optimization — 4-Phase Conversion Engineering

### Conversion Benchmark
- Starting baseline: ~2.3% conversion rate (industry typical for medical device)
- With optimization: target **8–12% conversion rate**
- Potential acquisition cost reduction: up to **77%**

### Phase 1: Payment & Financing Options
- For capital equipment: display financing, leasing, and payment plan options prominently
- Reduces sticker shock on high-ticket devices
- Multiple payment pathways reduce friction for purchase decision

### Phase 2: Multi-Step Checkout with Progress Indicators
- Break long lead/demo request forms into multiple steps with a visible progress bar
- **Psychological mechanism**: Sunk cost fallacy — once a visitor completes step 1, they're more likely to complete the process
- Reduces abandonment on long forms required for medical/dental B2B qualification

### Phase 3: Persona-Specific Copy
- **HCP landing page**: Clinical outcomes data, peer-reviewed citations, device specs, training/support, reimbursement codes
- **Patient landing page**: Procedure overview, "find a provider" CTA, safety information, ISI, testimonials (vetted for clinical accuracy)
- Never serve patient-facing copy to HCP audiences or vice versa

### Phase 4: Immediate Upsells / Cross-Sells
- After primary conversion action: surface complementary products (consumables, accessories, training)
- **Psychological mechanism**: Value anchoring — adjacent upsells feel smaller relative to the primary device purchase
- Must ensure all upsell products also carry appropriate regulatory approvals

### Regulatory Requirements for Landing Pages
- All testimonials and case studies must be **vetted for clinical accuracy**
- Include **fair balance** — ISI must be visible and accessible
- Any outcome claims must be supported by clinical evidence on file
- Legal/regulatory review required for page copy, just as for ad copy


## 6. Regulatory & Compliance Summary

| Element | Standard Google Ads Practice | Medical Device Override |
|---------|------------------------------|------------------------|
| Dynamic Search Ads | Often recommended for reach | **Never use** — unvetted copy |
| Automatically created assets | Leave ON for variety | **Turn OFF** — compliance risk |
| Text customization (PMax/Search) | Enable for AI-tailored copy | **Turn OFF** — unvetted copy |
| Final URL expansion | Leave ON for performance | **Turn OFF** — manual URL control required |
| Standard remarketing | Use for retention | **Not permitted** — health privacy policy |
| Broad match | Recommended with Smart Bidding | **Use with extreme caution** — risk of non-clinical queries |
| Customer lists as retargeting | Standard practice | **Use as signals only**, not direct targeting |


## 7. Regulatory Sources Referenced

1. Google Ads for Medical Devices — Ten Thousand Foot View
2. Google Ads: A Healthcare Digital Marketing Agency's Guide to Changes
3. What Top Google Ads Experts Do That Beginners Don't

**Additional compliance frameworks to be aware of:**
- FDA 21 CFR Part 801 (device labeling)
- FDA guidance on digital health and device promotion
- Health Canada Medical Device Regulations (for Canadian market)
- Google's Personalized Advertising Policy (health & medical categories)
- Google's Healthcare and Medicines advertising policy


## Quick Pre-Launch Compliance Checklist

- [ ] All ad copy pre-approved through regulatory/medical affairs review
- [ ] Automatically created assets: **OFF**
- [ ] Dynamic Search Ads: **Not used**
- [ ] Text customization: **OFF**
- [ ] Final URL expansion: **OFF** (PMax)
- [ ] Remarketing audiences: Used as **signals only**, not retargeting targets
- [ ] ISI/fair balance visible on all landing pages
- [ ] Testimonials clinically vetted
- [ ] All outcome claims supported by evidence on file
- [ ] Separate HCP and patient asset groups/ad groups
- [ ] VBB only activated if ≥25 conversions/month
- [ ] Custom segments (not remarketing lists) used for re-engagement
