---
description: Search and AI Max Reference
---

# Search Campaigns, AI Max & Account Structure

## The Core Principle
Align bidding → then targeting. Your bid strategy determines which targeting approach works best.


## AI Max for Search

**One-click activation** that brings all of Google AI to Search:
- **Search term matching**: Expands keywords via broad match + keywordless technology to find more relevant queries
- **Text customization**: Generates contextually tailored headlines/descriptions from landing pages
- **Final URL expansion**: Sends users to the most relevant page on your site

**Performance impact**:
- Advertisers activating AI Max typically see **14% more conversions or conversion value** at similar CPA/ROAS
- Campaigns still mostly on exact/phrase: **27% higher uplift**
- MyConnect (AU): +16% leads, -13% CPA, +30% conversions from net-new queries

**Best for**: Smart Bidding strategies (Maximize Conversions with tCPA, or Maximize Conversion Value with tROAS)

**Website requirements for AI Max**:
- Well-written HTML page titles and clearly-written content
- Easy navigation — AI Max needs to identify themes and terms
- Does NOT work well with: mostly Flash/image content, login-gated content
- Sensitive industries must have right certifications and audience settings


## Smart Bidding

Trains on hundreds of billions of search queries and signals. Sets bids at auction-time to hit goals.

**Broad match + Smart Bidding** = the recommended pairing:
- Broad match uses ALL available signals to find the most relevant match
- Exact and phrase match are restricted from using additional signals
- 62% of advertisers using Smart Bidding use broad match as their primary match type

**Value-based bidding**: Advertisers switching from tCPA → tROAS see **14% more conversion value** at similar ROAS


## Account Structure (ABCs)

### A — Align with AI
- Move single-keyword ad groups into **themed ad groups**
- Smart Bidding optimizes for a single target — segmented traffic forces it to optimize multiple targets separately
- Themed ad groups help Google understand keywords, select the best one, and match the right ad to each query

### B — Bring Match Types Together
- Move all match types of themed keywords into **one ad group**
- Then **simplify to just broad match**
- Duplicating the same keyword in multiple match types segments Smart Bidding's data
- There's no additional benefit to multiple match types with Smart Bidding — broad reaches everything exact/phrase does, plus more

### C — Consolidate and Clean Up
- **Remove device segmentation**: Smart Bidding already accounts for device at bid time
- **Segment campaigns by business objective**, not by device or match type
- Clean up duplicate and non-serving keywords
- Unnecessary segmentation = harder to manage, more error-prone, less AI efficiency


## Location and Brand Controls (AI Max Exclusive)
- **Locations of interest**: Reach customers based on geographical intent at the ad group level — without extra keywords
- **Brand controls**: Specify brands to associate with (or exclude) at campaign and ad group level


## Keyword Research Framework

### Intent Mapping
| Funnel Stage | Query Patterns |
|-------------|---------------|
| Bottom (buy intent) | "buy X", "X price", "best X for Y", "[brand] X" |
| Mid (consideration) | "X vs Y", "best X", "X reviews" |
| Top (problem aware) | "how to fix Y", "Y solution", "Y help" |

### Negative Keywords — Build From Day 1
Especially critical for PMax (which has no keyword list to fall back on):
- Competitor brand names (unless running conquesting)
- Irrelevant modifiers: "free", "DIY", "jobs", "salary" (context-dependent)
- Review Search Terms report weekly for new negatives

### Search Terms Report (Weekly)
- Add converting terms as exact match
- Add irrelevant terms as negatives
- In AI Max: search term insights show new queries the keywordless tech found


## Experiments: Testing Bid Strategies
- Test one variable at a time (don't change bidding AND creative simultaneously)
- Pick 1–2 metrics before launching to define success
- Use the Experiments page to manage all tests in one place
- Avoid changing base campaigns mid-experiment (use Campaign Sync)
- Keep records of all experiments for future reference


## Case Studies
- **L'Oréal Chile**: AI Max + Maximize Conversion Value → 2X higher conversion rate, 31% lower CPC
- **1STOPlighting**: tROAS on Shopping → 214% increase in profit
