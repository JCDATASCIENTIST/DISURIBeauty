---
description: Display and Remarketing Reference
---

# Display Campaigns

## Setup for Success
- Set up **conversion tracking** before launching (check regularly)
- Select a **campaign goal** based on your objective
- Use **Smart Bidding** to automate and optimize bids

## Upgrade Path
- Display advertisers upgrading to **Performance Max** see avg. **20% more conversions** at similar or lower CPA
- Works even with existing PMax campaigns

## Reaching the Right Audience

### Optimized Targeting
- Privacy-safe tool that finds customers likely to convert beyond manually-selected segments
- To re-engage existing customers: add audience segments built with your data (site visitors, repeat buyers)

## Creative: Responsive Display Ads (RDAs)
- Upload and maximize assets (images, logos, videos) for auto-generated ad combinations
- Advertisers see **2x conversions** on average when adding a responsive display ad to an ad group with a static display ad
- Bloomberg Media case study: -8% CPA, -81% cost-per-site-visit after adopting RDAs
- Use advanced format options: asset enhancements, auto-generated videos, native formats
- Include full product catalog with relevant images, titles, and prices
- Test and optimize frequently with fresh creative assets

## Measuring Display Value
- Include **Engaged-View Conversions (EVCs)** and **View-Through Conversions (VTCs)** in evaluation
  - These capture users who see (but don't click) your ad and later convert
  - Particularly valuable for measuring the influence of upper-funnel Display campaigns
- Check **lookback windows** — adjust from defaults based on your product buying cycle
- Enable **GA4 auto-tagging** for the most detailed Google Ads data
