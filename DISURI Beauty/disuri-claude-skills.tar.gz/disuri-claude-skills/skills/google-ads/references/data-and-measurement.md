---
description: Data and Measurement Reference
---

# Data Strength, Measurement & Audiences

## Why Data Strength Matters
AI Data Strength is the foundational pillar of modern marketing. A trusted data foundation significantly boosts ROI across all campaign types by powering smarter bidding, better audiences, and more accurate measurement.


## Step 1: Connect Your Data Sources

### Sitewide Tagging (Table Stakes)
- Install **Google tag** or **Google Tag Manager** sitewide
- Upgrade to **Google Tag Gateway** to run on your own first-party infrastructure
- Test conversion tracking regularly: generate conversions, confirm they register in Google Ads and GA4

### Link Google Analytics 4 to Google Ads
- Enables bidding for GA4 conversions and GA4 audiences
- Enables predictive audiences (e.g., likely purchasers)
- Requires **auto-tagging** enabled in Google Ads
- Use Firebase SDK for app conversion optimization

### Connect CRM / Offline Sources
- Use **Data Manager** to connect CRM and other offline data sources
- Also available via **Data Manager API** (programmatic data submission)
- Partners supported: HubSpot, Salesforce, and others
- Enables tracking of full customer journey: online ad → offline sale


## Step 2: Maximize Your Signals

### Enhanced Conversions
- Sends hashed first-party customer data (emails, phone numbers) to improve match accuracy
- Bridges measurement gaps from cookie deprecation
- **Enhanced Conversions for Leads**: 10% more conversions vs. standard offline conversion import
- Enables cross-device and engaged-view conversion tracking

### Conversion Value Rules
- Apply multipliers for high-value audiences, devices, or geographic locations
- Use for value-based bidding to prioritize the most profitable conversions

### Customer Signals to Pass
- User-provided email addresses
- Transaction data (purchase values)
- Ad interaction signals: GCLID, Session Attributes, GBRAID/WBRAID URL parameters


## Step 3: Customer Match

### What It Is
Upload first-party customer data so Google AI can reach your customers (and similar new ones) across Search, Shopping, YouTube, Gmail, and Display.

**Impact**: Customer Match list signals → **5.3% conversion uplift**

### Data Types to Upload (More = Better Match Rate)
- Email address
- Mobile device ID
- Phone number
- Physical address
- Best practice: Include multiple data points per customer in the same row

### Match Rates
- Typical range: **29–62%** match rate — don't expect 100%, it's normal
- Low match rate = likely formatting or encryption issue
- Use a verified Customer Match upload partner to increase match rates

### Update Frequency
| Method | Recommended Cadence |
|-------|-------------------|
| Manual uploads in Google Ads | Weekly (calendar reminder) |
| API | Daily automated append |
| Upload partner | As frequent as partner supports |
| Third-party (e.g., Zapier) | Real-time automation |
| Conversion-based customer lists | Automatic (enable in Account Settings) |

### Enhanced Conversions + Conversion-Based Lists
Enable both to auto-generate and auto-update customer lists based on conversion goals — no manual effort required.

### Privacy
- All customer data is hashed (encrypted) before matching
- Google does not retain or use the data for other products after matching
- Apple ATT policies may impact Customer Match on iOS 14+ traffic

### Use Cases
- Cross-sell existing customers
- Reach customers with special offers
- Reactivate dormant customers
- Create Lookalike segments (Demand Gen) to find similar new customers


## Step 4: Google Analytics 4 (GA4)

### Key Integrations
- Share key events from GA4 as conversions in Google Ads
- Import GA4 conversions to inform Smart Bidding
- Build audience lists including **predictive audiences** (e.g., "likely purchasers")
- Enable benchmarking to compare performance vs. competitors

### Predictive Audiences
- Reach people most likely to be interested in your product
- BAUR (German retailer): +56% sales using likely purchasers audience; 70% of those customers unreachable without predictive audiences

### For iOS (App Campaigns)
- Set up **SKAdNetwork conversion value schema** in GA4
- Integrate with Google Ads for event and value-oriented bidding optimization
- Consider implementing ATT prompt and on-device conversion measurement


## Step 5: Experiments (Measuring Incrementality)

### How to Run Good Experiments
1. **Set a clear hypothesis** tied to a business goal (e.g., "switching to tROAS will drive higher conversion value vs. tCPA")
2. **Test one variable at a time** — don't change bidding AND creative simultaneously
3. **Pick 1–2 metrics before launching** to define success
4. **Avoid changes to base campaigns** during experiment (use Campaign Sync)
5. **Keep records** of all experiments for future reference

### Types of Experiments Available
- Search bid strategy experiments
- Display campaign experiments
- PMax uplift experiments (vs. existing campaign mix)
- PMax vs. Standard Shopping switch experiments

### After the Experiment
- "Update original campaign" → ports changes, preserves campaign history (recommended for most cases)
- "Convert to new campaign" → use for new structures or to preserve learning period findings


## Step 6: Prove ROI

### Google Ads Experiments
- Measure incrementality across Search, PMax, Display, and more
- Lower budget requirements and improved methodology (recent update)

### Meridian (Google's Open-Source MMM)
- Marketing mix modeling for cross-channel ROI understanding
- Optimize full budget allocation across channels
- Identify optimal frequency and anticipated ROI uplift per channel

### Budgeting Tool (Google Analytics)
- Coming soon globally
- Works alongside Meridian for integrated budget optimization


## Data Strength Diagnostic Checklist

- [ ] Google tag / GTM installed sitewide and firing correctly
- [ ] GA4 linked to Google Ads with auto-tagging enabled
- [ ] Enhanced conversions enabled
- [ ] CRM connected via Data Manager
- [ ] Customer Match lists uploaded and updated regularly
- [ ] Conversion values assigned to reflect business importance
- [ ] Conversion value rules set up for key segments
- [ ] Experiments running to validate campaign performance
