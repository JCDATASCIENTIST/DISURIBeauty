---
description: Performance Max Reference
---

# Performance Max (PMax)

## What It Is
Single campaign type that runs across ALL Google channels: Search, Shopping, Display, YouTube, Gmail, Maps, Discover. Google AI controls bidding, targeting, and creative combinations automatically.

**Key stat**: Advertisers adopting PMax see avg. **27% more conversions or value** at similar CPA/ROAS — even when already using broad match and Smart Bidding in Search.


## Conversion Goals

### Choose Goals That Match Your Business
- Use the same conversion goals as your existing Search campaigns for consistency
- **New Customer Acquisition (NCA)**: Value/prioritize new customers while still converting existing ones
  - "New Customer Value Mode" improved ROAS by 9%, new customer ratio by 5%, reduced new customer acquisition cost by 7%
  - "New Customer Only Mode": 11.5% improvement in new-to-returning customer ratio, 3% reduction in new customer acquisition cost
- **Retention goal**: Bid more for lapsed customers; specify high-LTV customers for priority

### Conversion Value Setup
- Assign values to different conversion types to reflect their real business importance
- Use **Conversion Value Rules** to apply multipliers for high-value audiences, devices, or geographies


## Bidding Strategy
- **Maximize Conversion Value** (+ optional tROAS): If tracking conversion values — recommended for most
- **Maximize Conversions** (+ optional tCPA): If not tracking values, care equally about all conversions
- Use your Search campaign CPA/ROAS targets as a starting point if unsure


## Asset Groups

### What They Are
Asset groups replace ad groups in PMax. Each asset group = a themed set of assets that target a unified audience or product/service category.

### Asset Checklist Per Group
| Asset Type | Requirement |
|-----------|-------------|
| Headlines | 15 (max) |
| Descriptions | 5 |
| Images - Landscape (1.91:1) | ≥3 |
| Images - Square (1:1) | ≥3 |
| Images - Portrait (4:5) | ≥1 |
| Logo - Square | Required |
| Logo - Landscape | Recommended |
| Video | ≥1 (10s min); all 3 orientations ideal |

- More assets = more ad formats = more inventory your ads can appear on
- Use **Ad Strength** to confirm you have the optimal asset mix

### Video in PMax
- Including ≥1 video → avg. **12% more conversions**
- All 3 orientations (horizontal, vertical, square) → **20% more YouTube conversions** vs. horizontal-only
- If no video uploaded: PMax auto-generates one from your other assets (lower quality — always upload your own)
- Use the video creation tool in Asset Library if you don't have video

### Text Customization (ON by default)
- Generates new/additional headlines and descriptions from your landing pages
- Keeps text assets fresh and relevant to customer intent over time
- **Must be ON** to use Final URL Expansion

### Final URL Expansion (ON by default)
- Sends users to the most relevant landing page based on intent
- Advertisers using Final URL Expansion see avg. **9% more conversions/value** at similar CPA/ROAS
- **URL Exclusions**: Exclude careers pages, FAQ pages, or any non-conversion pages
- **URL Contains rules** (Final URL ON): Guide AI toward important categories without restricting it
- **Page Feeds** (Final URL ON): Provide specific URLs as important signals to AI
- Turn OFF only if: single landing page required, or legal approval needed for every URL used

### Final URL Expansion Decision Table
| Goal | Setting |
|------|---------|
| Maximize reach + conversions | Final URL ON |
| Maximize reach but exclude certain pages | Final URL ON + URL Exclusions |
| Exclude branded terms | Final URL ON + brand exclusions |
| Specific category only | Final URL OFF + "URL contains" rules |
| Approved URL list only | Final URL OFF + page feeds |
| Single landing page only | Final URL OFF (not recommended) |


## Audience Signals & Search Themes

### Audience Signals
- Not hard targeting — they **guide AI to ramp up faster**
- Provide: Customer Match lists, website visitors, remarketing audiences, in-market segments
- Keep Customer Match lists **fresh** (update at minimum weekly)
- PMax will discover new converting segments beyond your signals — that's a feature, not a bug

### Search Themes
- Tell PMax what queries your customers use (that AI might not learn from URLs/assets alone)
- Same prioritization as phrase match and broad match keywords
- Additive to what PMax matches via URLs and assets
- Useful when: landing pages are incomplete/outdated, new products, niche vocabulary


## Retail-Specific PMax
- Connect **Merchant Center feed** for Shopping inventory
- Product-level bidding via feed attributes
- Use **New Customer Value Mode** to grow new customer base while maintaining existing sales
- **Local inventory ads**: Enable to surface in-store product availability


## Upgrading from Display to PMax
- Advertisers upgrading Display → PMax see avg. **20% more conversions** at similar or lower CPA
- Works even with existing PMax campaigns running simultaneously


## Evaluating PMax Performance

### Key Reports
- **Insights page**: Top audiences, search themes, trends — check daily
- **Channel performance report** (beta): See where conversions are happening by channel
- **Asset performance labels**: Learning / Low / Good / Best — replace Low assets
- **Search terms report** (rolling out): See queries matching via search themes and keywordless

### Account for Conversion Delay
- Don't evaluate recent periods if conversions have a long lag (e.g., 7-day typical window = exclude most recent week)

### Experiments Available for PMax
1. Measure uplift of adding PMax to existing campaign mix
2. Measure uplift of switching Standard Shopping → PMax


## Asset Generation with Generative AI
- In campaign creation: Enter URL → click "Generate assets" → get suggested headlines, descriptions, images
- Use text prompts to specify type of lifestyle imagery you want (style, colors, lighting, background)
- Best for: lifestyle imagery, generic product imagery for large catalogs
- Available in US only
