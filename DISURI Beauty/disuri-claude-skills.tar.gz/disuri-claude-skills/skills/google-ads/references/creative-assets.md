---
description: Creative Assets Reference
---

# Creative Assets — RSAs, Ad Strength, Images, Video

## Creative Impact
Creative is responsible for **49% of total sales impact** of advertising (NCS Solutions, 2023).


## Responsive Search Ads (RSAs)

### Character Limits
| Element | Limit | Target |
|---------|-------|--------|
| Headline | 30 characters | 15 (all slots) |
| Description | 90 characters | 4 (all slots) |

> ⚠️ **Hard rule**: Count characters for every headline and description before outputting. A headline at 31 chars is rejected by Google Ads — there are no exceptions. Always show the character count alongside each line during drafting so violations are caught before delivery.

### Ad Strength Targets
Every ad group: ≥1 RSA at **"Good" or "Excellent"** Ad Strength.

| Improvement | Impact |
|------------|--------|
| Poor → Excellent | +12% avg. clicks and conversions |
| Adding logo + business name | +8% avg. conversions |
| Adding image assets | +6% avg. CTR |

### Reaching "Excellent" Ad Strength
1. Write all 15 headlines — maximize variety, don't repeat themes
2. Write all 4 descriptions
3. Pin sparingly — pinning limits AI's ability to test combinations
4. ≥1 headline with primary keyword
5. ≥1 headline with a strong CTA
6. ≥1 headline with a unique differentiator or social proof

### RSA Writing Framework

**Headlines — 5 categories to cover across all 15 slots:**

| Category | Example |
|---------|---------|
| Keyword-anchored | "Custom Wedding Invitations" |
| Benefit | "Free Shipping on All Orders" |
| Differentiator | "Award-Winning Design Studio" |
| Social proof | "10,000+ Happy Customers" |
| CTA | "Shop Now & Save 20%" |
| Urgency / offer | "Limited Time: 30% Off" |
| Brand + category | "[Brand] Official Site" |
| Question / curiosity | "Looking for the Best X?" |
| Unique feature | "Ships in 24 Hours" |

**Descriptions — 4 types:**

| Type | Purpose |
|-----|---------|
| Value prop | Core benefit in one sentence |
| Feature + benefit | Specific capability + why it matters |
| Urgency / offer | Time-limited or quantity-limited hook |
| Reassurance / trust | Reduce friction ("Free returns. No risk.") |

### Text Customization (AI Max / PMax)
Enable to let Google AI continuously generate new headlines and descriptions tailored to user context and intent, while staying true to brand. Works with Final URL expansion.


## RSA Output Template

When generating RSA copy, always deliver in this structure. **Show character count for every line — count before writing, not after.**

```
## RSA: [Ad Group Name]

### Headlines (30 chars max — show count for each)
1.  [Keyword-anchored]                          (XX chars)
2.  [Keyword-anchored variant]                  (XX chars)
3.  [Benefit]                                   (XX chars)
4.  [Benefit variant]                           (XX chars)
5.  [Differentiator]                            (XX chars)
6.  [Differentiator variant]                    (XX chars)
7.  [Social proof]                              (XX chars)
8.  [Social proof variant]                      (XX chars)
9.  [CTA]                                       (XX chars)
10. [CTA variant]                               (XX chars)
11. [Urgency / offer]                           (XX chars)
12. [Urgency / offer variant]                   (XX chars)
13. [Brand + category]                          (XX chars)
14. [Question / curiosity]                      (XX chars)
15. [Unique feature]                            (XX chars)

### Descriptions (90 chars max — show count for each)
1. [Value prop]                                 (XX chars)
2. [Feature + benefit]                          (XX chars)
3. [Urgency / offer]                            (XX chars)
4. [Reassurance / trust]                        (XX chars)

### Character Count Verification
- [ ] All headlines ≤30 chars (flag any that exceed — revise before delivering)
- [ ] All descriptions ≤90 chars (flag any that exceed — revise before delivering)

### Ad Strength Checklist
- [ ] 15 unique headlines written
- [ ] 4 descriptions written
- [ ] Minimal or no pinning
- [ ] Primary keyword in ≥1 headline
- [ ] Strong CTA in ≥1 headline
- [ ] Differentiator covered
- [ ] Image assets added or dynamic enabled
```

> **If any line exceeds the limit**: Do not deliver it. Revise immediately and show the corrected version with updated count. Never ask the user to check character counts themselves — that is the skill's job.


## Image Assets

### For Search Campaigns
- Add image assets to visually showcase offerings
- Or enable **dynamic image assets** → Google AI auto-selects most relevant images from landing pages
- **+6% CTR** on average when image assets show with Search ads
- Logo + business name showing = **+8% conversions** on average

### For All Campaign Types
Required image sizes to cover all inventory:
| Orientation | Aspect Ratio |
|------------|-------------|
| Landscape | 1.91:1 |
| Square | 1:1 |
| Portrait | 4:5 |

Use high-quality, high-resolution images with clear subjects. Avoid heavy text overlays.


## Video Assets

### Three Orientations — Always
| Orientation | Aspect Ratio | Use For |
|------------|-------------|---------|
| Horizontal | 16:9 | YouTube main feed, desktop |
| Vertical | 9:16 | YouTube Shorts, mobile |
| Square | 1:1 | Cross-platform, universal |

**All 3 orientations in PMax → 20% more YouTube conversions** vs. horizontal-only

### Video Length Guidelines by Campaign Type
| Campaign Type | Recommended Length |
|-------------|------------------|
| Bumper (awareness) | 6 seconds |
| Video Reach - short | <10 seconds |
| Video Reach - medium | 10–20 seconds |
| Video Reach - long | >30 seconds |
| Video View (consideration) | >30 seconds |
| App campaigns | 10–30 seconds |
| Demand Gen | Varies; use ABCD framework |

### ABCD Creative Framework (YouTube)
- **A**ttention: Hook viewers immediately
- **B**randing: Feature brand early and often
- **C**onnection: Create emotional resonance, relatability
- **D**irection: Clear CTA, repeated in voiceover AND graphics

### Video Creation Tools
- **Asset Studio**: Generate/convert video assets directly in Google Ads UI (globally available)
- **Video creation tool**: Build videos from templates in Asset Library
- **Trim video**: Create 6-second bumpers from longer clips
- **Veo + Imagen**: Image-to-video capabilities (Merchant Center and Ads campaigns)


## Asset Studio
Available globally. Use to:
- Generate lifestyle images unique to your business
- Convert video formats between orientations
- Create image-to-video assets via Veo and Imagen
- No external design tools required for basic asset generation


## Product Studio (Merchant Center)
- Enhance existing product imagery for multiple formats and audiences
- Update images for different seasonal offers and customer types
- Easy alternative to professional product photography for variants


## Demand Gen Creative (Rule of Three)
In each ad group: ≥3 images or videos in each aspect ratio (vertical, square, landscape)


## Case Study
**Armani Beauty (L'Oréal)**
- RSAs to each unbranded ad group (all at Good/Excellent Ad Strength)
- Added sitelinks and image assets to every ad group
- **Result**: +61% CTR, +11% on-site conversions
