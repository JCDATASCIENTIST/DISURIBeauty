---
description: Demand Gen Reference
---

# Demand Gen Campaigns

## What It Is
Demand Gen creates and converts demand using visually immersive creatives across Google's visual surfaces: YouTube, YouTube Shorts, Discover, and Gmail. 86% of people who discover new products on YouTube/Google say they took action after using those platforms.

**Key differentiators**:
- Exclusive: Lookalike segments (not available in other campaign types)
- Social-like CPA/ROAS targeting
- Channel controls for media mix customization


## Creative

### Ad Strength — Aim for "Excellent"
- Include ≥3 unique assets for each aspect ratio: vertical, square, landscape
- "Excellent" Ad Strength = comprehensive, diverse, high-quality assets following best practices

### Rule of Three
In each ad group: **≥3 images or videos per aspect ratio** (vertical, square, landscape)
- Maximizes reach across all available inventory
- Prioritize assets that feel native to each platform (e.g., vertical video for Shorts = relatable, authentic)

### Video + Image Together
- Advertisers running both video AND image ads see **6% more conversions per dollar** vs. image-only
- Tell a cohesive brand story across formats
- Video: Follow ABCD creative guidance (Attention, Branding, Connection, Direction)
  - Repeat the CTA in voiceover AND overlaid graphics
  - For consideration: take >30s to craft a compelling narrative
- Image: High-resolution, clear subjects, compelling visuals
  - Reuse high-performing social imagery to save time

### Product Feeds (Retailers)
- Turn ads into a virtual storefront
- Connect Merchant Center to Demand Gen
- Advertisers adding product feeds see **33% more conversions at similar CPA**

### If You Don't Have Video
- Use the video creation tool with templates
- Trim video to create shorter clips from longer ones
- Enhance product imagery with Product Studio in Merchant Center


## Audiences

### Optimized Targeting (For Conversion Goals)
- Looks beyond manually-selected segments to find audiences likely to convert
- Advertisers using optimized targeting see **20% higher conversions at the same cost**
- Add signals: audience segments, keywords to guide it

### Lookalike Segments (Demand Gen Exclusive)
- Upload customer list → AI finds new users with similar qualities
- Separate high-value and low-value customers into distinct Lookalike segments
- Lookalike segments can be saved and reused across all Demand Gen campaigns

### New Customer Acquisition (NCA)
- Fully automated: focuses on acquiring users new to your business
- "New Customer Only Mode": 11.5% improvement in new-to-returning ratio, 3% lower new customer acquisition cost

### Remarketing/Retention
- Create a dedicated ad group for remarketing/retention with tailored creatives
- Enhances signals for campaigns to find potential new customers


## Data Strength
Connect all data sources before launching:
- **Robust sitewide tagging**: Google tag or GTM
- **Link GA4 to Google Ads**: Bid for GA4 conversions and audiences
- **CRM/offline sources → Data Manager**: Comprehensive customer view
- **Customer signals**: Hashed email addresses, transaction data, ad interaction signals (GCLID, GBRAID, WBRAID)
- **Consent mode**: Pass consent signals with all tags


## Bidding Strategy

### For Efficiency (ROI Target)
- **tCPA**: Most conversions at a set target CPA
- **tROAS**: Most conversion value at a set target ROAS

### For Volume (Maximize Budget)
- **Max Conversions**: Most conversions within budget
- **Max Conversion Value**: Most conversion value within budget

### For Traffic Only (No Conversion Tracking Required)
- **Target CPC**: Most clicks at your target CPC
- **Max Clicks**: Most clicks within budget

> Click-based bidding should NOT be used for conversion goals.

Use the **Bid Strategy Report** to assess bidding performance over time.


## Budget Requirements
The learning period requires sufficient data. **Budget targets must be met from Day 1.**

| Strategy | Minimum Daily Budget |
|---------|---------------------|
| Maximize Conversions | ≥$100/day per campaign |
| Target CPA | ≥10x your tCPA |
| Maximize Conversion Value | ≥$100/day per campaign |
| Target ROAS | ≥10x your CPA |
| Max Clicks / Target CPC | No minimum |

- Learning phase = "Learning" status until 50+ conversions
- Minimize campaign changes during learning to avoid resetting
- If an ad group has <10 conversions in 6–8 weeks → merge with another ad group


## Campaign Structure

### Consolidate for AI Performance
- AI learns at the campaign level — consolidation improves performance
- Single campaign for your business (unless different objectives, ROI targets, or bid strategies)
- Combine similar audience themes in one ad group (e.g., 'baseball' + 'football' = 'sports')
- Start with budget that allows ≥50 conversions in first 30 days

### Dedicated Ad Group for Remarketing/Retention
- Separate ad group with tailored creatives for remarketing/retention audiences
- Consolidate only unless you need specific creatives per audience, or strict Prospecting vs. Remarketing budget control


## Evaluate and Optimize
- Monitor **Ad Strength** and **engagement metrics** (CTR in asset reports)
- Swap out lower-performing assets with new variations
- Review **Segment by ad format** reporting: YouTube Shorts, in-stream, in-feed
- Run **A/B experiments** for Demand Gen to test creative effectiveness across surfaces
