# HubSpot Analytics Reference

Quick reference for analyzing HubSpot marketing and sales data.

## Core HubSpot Objects

| Object | Key Fields | Use For |
|--------|------------|---------|
| **Contacts** | email, lifecycle_stage, persona, lead_status, create_date | Lead analysis, segmentation |
| **Companies** | name, industry, employee_count, annual_revenue | Account-level analysis |
| **Deals** | amount, stage, close_date, pipeline | Revenue, pipeline analysis |
| **Marketing Emails** | subject, send_date, opens, clicks, unsubscribes | Email performance |
| **Forms** | name, submissions, conversion_rate | Lead gen analysis |
| **Landing Pages** | views, submissions, conversion_rate | Page performance |
| **Campaigns** | name, influenced_contacts, influenced_revenue | Attribution |

## Key Marketing Metrics

### Email Performance
```
Open Rate = Opens / Delivered
Click Rate = Clicks / Delivered  
Click-to-Open Rate = Clicks / Opens
Unsubscribe Rate = Unsubscribes / Delivered

Benchmarks (B2B):
- Open Rate: 15-25% (good), <15% (needs work)
- Click Rate: 2-5% (good), <2% (needs work)
- Unsubscribe Rate: <0.5% (healthy)
```

### Form & Landing Page Performance
```
Conversion Rate = Submissions / Views
Cost Per Lead = Ad Spend / Submissions

Benchmarks:
- Landing Page CR: 2-5% (average), >10% (excellent)
- Form CR varies by length: shorter = higher
```

### Contact Lifecycle Analysis
```
Lifecycle Stages (typical flow):
Subscriber → Lead → MQL → SQL → Opportunity → Customer

Stage Conversion Rates:
Lead → MQL: 10-30% typical
MQL → SQL: 15-30% typical
SQL → Opportunity: 30-50% typical
Opportunity → Customer: 20-40% typical
```

## Campaign Attribution

### Attribution Models in HubSpot
- **First Touch**: Credit to first interaction
- **Last Touch**: Credit to final interaction before conversion
- **Linear**: Equal credit across all touchpoints
- **Full Path**: 22.5% first, 22.5% lead create, 22.5% deal create, 22.5% last, 10% middle

### Influenced Revenue Calculation
```
Influenced Revenue = Sum of deal amounts where contact 
interacted with campaign before deal close date
```

## Common Analysis Queries

### Lead Source Performance
Analyze by: Original Source, Latest Source, First Page Seen
Segment by: Persona, Product Interest, Region
Metrics: Volume, Conversion Rate, Cost, Quality Score

### Email Campaign Effectiveness
Compare: Subject lines, Send times, CTAs, Content types
Segment by: Persona, Lifecycle Stage, Engagement History
Track: Engagement trend over time, Fatigue indicators

### Content Attribution
Map: Content → Leads Generated → Deals Influenced
Identify: Top-performing content by stage, gaps in funnel

## HubSpot + Power BI Integration

### Connection Options
1. **HubSpot Data Sync** (to data warehouse) → Power BI
2. **Third-party connectors** (Supermetrics, Fivetran)
3. **HubSpot API** → Custom ETL → Power BI
4. **Export CSV** → Manual refresh (not recommended for production)

### Recommended Data Model
```
Fact Tables:
- fact_email_sends (grain: email + contact + send_date)
- fact_form_submissions (grain: form + contact + submit_date)
- fact_page_views (grain: page + session + date)
- fact_deal_stages (grain: deal + stage + date)

Dimension Tables:
- dim_contacts (current state)
- dim_companies
- dim_campaigns
- dim_content
- dim_date
```

### Key Joins
```
Contacts ←→ Companies: company_id
Contacts ←→ Deals: associated_contact_id
Campaigns ←→ Contacts: campaign_membership
Emails ←→ Contacts: recipient_id
```

## ZimVie-Specific HubSpot Analysis

### Persona Performance
Segment all analyses by ZimVie persona property:
- Oral Surgeon
- Periodontist
- GP Implant
- GP Restorative
- Lab Tech
- DSO Ops
- DSO Clinician

### Product Line Attribution
Track engagement and conversion by product interest:
- TSX Implant System
- Encode Impressions
- Zirconia Solutions
- Regenerative Products

### Campaign Types
Categorize campaigns for trend analysis:
- Product Launch
- Lead Nurture
- Event/Webinar
- Content Syndication
- Paid Media
- Email Newsletter

## Quick Diagnostic Checks

### Email Health Check
- [ ] Deliverability >95%?
- [ ] Open rate stable or improving?
- [ ] Unsubscribe rate <0.5%?
- [ ] List growth positive?

### Lead Gen Health Check
- [ ] Form conversion rates stable?
- [ ] Lead quality (MQL rate) consistent?
- [ ] Source mix diversified?
- [ ] Cost per lead within target?

### Pipeline Health Check
- [ ] MQL volume meeting targets?
- [ ] Stage conversion rates stable?
- [ ] Velocity improving or stable?
- [ ] Pipeline coverage >3x quota?
