# ZimVie Data Sources Reference

Overview of data sources available for ZimVie marketing and sales analytics.

## Primary Data Sources

### HubSpot (Marketing Automation)
**Data Available:**
- Contacts and lifecycle stages
- Email campaign performance
- Form submissions
- Landing page analytics
- Campaign attribution
- Marketing qualified leads

**Key Properties:**
- `persona` - Dental professional type
- `product_interest` - Product line interest
- `lead_source` - Original acquisition channel
- `lifecycle_stage` - Funnel position
- `lead_status` - Sales qualification status

**Refresh:** Real-time via API, daily for reports

---

### Salesforce (CRM)
**Data Available:**
- Opportunities and pipeline
- Account information
- Sales activities
- Win/loss data
- Territory assignments

**Key Objects:**
- Accounts (dental practices, DSOs)
- Contacts (practitioners)
- Opportunities (deals)
- Activities (calls, meetings)

**Refresh:** Synced with HubSpot, daily warehouse load

---

### Google Analytics 4 (Web Analytics)
**Data Available:**
- Website traffic and engagement
- User journeys
- Content performance
- Conversion events
- Audience demographics

**Key Events:**
- `page_view` - Content engagement
- `form_submit` - Lead generation
- `video_play` - Video engagement
- `file_download` - Content downloads
- `scroll` - Engagement depth

**Refresh:** Daily to data warehouse

---

### Google Ads
**Data Available:**
- Campaign performance
- Keyword data
- Audience targeting results
- Conversion tracking
- Cost data

**Key Metrics:**
- Impressions, Clicks, CTR
- CPC, CPL, ROAS
- Quality Score
- Conversion Rate

**Refresh:** Daily

---

### Meta Ads (Facebook/Instagram)
**Data Available:**
- Campaign performance
- Audience insights
- Creative performance
- Lead form submissions

**Key Metrics:**
- Reach, Impressions, Frequency
- CPM, CPC, CPL
- Video view rates
- Lead quality metrics

**Refresh:** Daily

---

### LinkedIn Ads
**Data Available:**
- Campaign performance
- Company targeting results
- Job title/function targeting
- Lead gen form data

**Key Metrics:**
- Impressions, Clicks
- CPM, CPC, CPL
- Engagement rate
- Lead form CR

**Refresh:** Daily

---

### StackAdapt (Programmatic)
**Data Available:**
- Display/native performance
- Contextual targeting results
- Audience segments
- Attribution data

**Key Metrics:**
- Viewability
- CPM, CPC
- Conversion lift
- Brand lift studies

**Refresh:** Daily

---

## Key Dimensions for Analysis

### Persona Segmentation
| Persona | Description | Typical Interests |
|---------|-------------|-------------------|
| Oral Surgeon | High-volume implant procedures | Surgical kits, implants |
| Periodontist | Surgical and restorative | Implants, regenerative |
| GP Implant | Growing implant practice | Training, starter kits |
| GP Restorative | Restorative-focused | Prosthetics, digital |
| Lab Tech | Dental laboratories | Digital workflows, materials |
| DSO Ops | DSO decision-makers | Standardization, pricing |
| DSO Clinician | DSO practitioners | Clinical protocols |

### Product Lines
- **TSX Implant System** - Flagship implant platform
- **TSV Implant System** - Legacy implant line
- **Encode Impressions** - Digital impression system
- **Zirconia Solutions** - Prosthetic options
- **Regenerative Products** - Bone grafts, membranes
- **Surgical Kits** - Instrument sets

### Geographic Segments
- North America (primary)
- EMEA
- APAC
- Latin America

### Customer Segments
- Private Practice (single location)
- Group Practice (2-5 locations)
- DSO (6+ locations)
- Academic/Institutional

---

## Standard KPI Definitions

### Marketing KPIs

| KPI | Definition | Target |
|-----|------------|--------|
| MQLs | Leads meeting qualification criteria | Varies by period |
| SQLs | MQLs accepted by sales | 30% of MQLs |
| CPL | Total spend / Leads | <$200 |
| MQL Rate | MQLs / Total Leads | >25% |
| Pipeline Influenced | Revenue from marketing-touched opps | 70%+ |

### Campaign KPIs

| KPI | Definition | Target |
|-----|------------|--------|
| CTR | Clicks / Impressions | >1% display, >3% search |
| Conversion Rate | Conversions / Clicks | >2% |
| ROAS | Revenue / Ad Spend | >3x |
| Email Open Rate | Opens / Delivered | >20% |
| Email Click Rate | Clicks / Delivered | >3% |

### Sales KPIs

| KPI | Definition | Target |
|-----|------------|--------|
| Win Rate | Won / (Won + Lost) | >30% |
| Pipeline Velocity | Avg days in pipeline | <90 days |
| Pipeline Coverage | Pipeline / Quota | >3x |
| Average Deal Size | Revenue / Deals | Varies by segment |

---

## Data Quality Considerations

### Common Issues
- **Duplicate contacts** - Check for merge candidates
- **Missing persona** - Enrich from company/behavior
- **Incomplete attribution** - UTM gaps, cross-device
- **Timezone mismatches** - Standardize to ET

### Validation Checks
- Row counts match source systems
- Date ranges complete (no gaps)
- Key fields populated (>95%)
- Referential integrity maintained

---

## Recommended Data Architecture

```
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│  HubSpot    │  │ Salesforce  │  │    GA4      │
└──────┬──────┘  └──────┬──────┘  └──────┬──────┘
       │                │                │
       └────────────────┼────────────────┘
                        │
                        ▼
              ┌─────────────────┐
              │  Data Warehouse │
              │   (Snowflake/   │
              │    BigQuery)    │
              └────────┬────────┘
                       │
                       ▼
              ┌─────────────────┐
              │    Power BI     │
              │   Semantic      │
              │     Model       │
              └─────────────────┘
```

### Semantic Model Structure
- **Fact tables:** Activities, Conversions, Spend, Pipeline
- **Dimension tables:** Contacts, Companies, Products, Campaigns, Dates
- **Calculated measures:** Rates, Velocities, Attribution
