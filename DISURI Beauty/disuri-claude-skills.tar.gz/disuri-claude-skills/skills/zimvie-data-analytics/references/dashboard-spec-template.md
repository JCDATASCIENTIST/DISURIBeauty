# Dashboard Specification Template

Use this template when creating dashboard specs for stakeholders.

---

## Dashboard Specification: [Dashboard Name]

### 1. Overview

**Purpose:** [One sentence describing what this dashboard enables]

**Primary Audience:** [Who will use this daily/weekly]

**Decision Support:** [What decisions does this inform]

**Refresh Frequency:** ☐ Real-time ☐ Daily ☐ Weekly ☐ Monthly

---

### 2. Key Performance Indicators

| KPI | Definition | Target | Data Source |
|-----|------------|--------|-------------|
| [Metric 1] | [Calculation/definition] | [Target value] | [Source system] |
| [Metric 2] | [Calculation/definition] | [Target value] | [Source system] |
| [Metric 3] | [Calculation/definition] | [Target value] | [Source system] |

---

### 3. Page Structure

#### Page 1: Executive Summary
- **Purpose:** High-level health check, 30-second view
- **Visuals:**
  - KPI cards: [List 4-6 headline metrics]
  - Trend sparklines: [Key trends]
  - Alert indicators: [What triggers red/yellow/green]

#### Page 2: [Detailed View Name]
- **Purpose:** [What drill-down this provides]
- **Visuals:**
  - [Chart type]: [What it shows]
  - [Chart type]: [What it shows]

#### Page 3: [Additional Pages as needed]

---

### 4. Filters & Interactivity

| Filter | Type | Default Value | Applies To |
|--------|------|---------------|------------|
| Date Range | Date picker | Last 90 days | All pages |
| Persona | Multi-select | All | All pages |
| Product Line | Dropdown | All | All pages |
| Region | Multi-select | All | All pages |
| Campaign | Searchable dropdown | All | Marketing pages |

**Cross-filtering behavior:** [Describe how selections propagate]

**Drill-through paths:** [List any drill-through capabilities]

---

### 5. Data Sources & Joins

| Source | Tables/Objects | Join Keys | Refresh |
|--------|---------------|-----------|---------|
| HubSpot | Contacts, Deals, Companies | Contact ID, Company ID | Daily |
| Salesforce | Opportunities, Accounts | Account ID | Daily |
| Google Analytics | Sessions, Events | Client ID | Daily |
| Ad Platforms | Campaigns, Ad Groups | UTM parameters | Daily |

**Data model diagram:** [Describe star schema or attach diagram]

---

### 6. Calculated Measures

```
// Conversion Rate
Conversion Rate = DIVIDE([Conversions], [Total Visitors], 0)

// Cost Per Lead
CPL = DIVIDE([Total Spend], [Leads Generated], 0)

// Pipeline Velocity
Velocity = DIVIDE([Pipeline Value], [Average Days in Stage], 0)

// MQL to SQL Rate
MQL to SQL = DIVIDE([SQLs], [MQLs], 0)
```

---

### 7. Conditional Formatting & Alerts

| Metric | Green | Yellow | Red |
|--------|-------|--------|-----|
| Conversion Rate | ≥3% | 2-3% | <2% |
| CPL | ≤$150 | $150-200 | >$200 |
| Pipeline Coverage | ≥3x | 2-3x | <2x |

**Automated alerts:** [List any email/Teams notifications]

---

### 8. Access & Distribution

**View Access:** [List roles/individuals]

**Edit Access:** [List roles/individuals]

**Scheduled Reports:** 
- [Report name]: [Recipients], [Frequency], [Format]

**Embedding:** ☐ SharePoint ☐ Teams ☐ Email ☐ Standalone

---

### 9. Technical Requirements

**Data Volume:** [Estimated rows]

**Performance Target:** <3 second load time

**Mobile Optimization:** ☐ Required ☐ Nice-to-have ☐ Not needed

**Row-Level Security:** [Describe RLS requirements if any]

---

### 10. Success Criteria

- [ ] Stakeholder sign-off on KPI definitions
- [ ] Data validation complete (matches source systems)
- [ ] Load time <3 seconds
- [ ] Mobile layout tested (if required)
- [ ] Training delivered to primary users
- [ ] Documentation complete

---

## Common ZimVie Dashboard Patterns

### Marketing Performance Dashboard
- **KPIs:** MQLs, SQLs, CPL, Conversion Rate, Pipeline Influenced
- **Segments:** Persona, Product Line, Campaign Type, Region
- **Comparisons:** MoM, YoY, vs Target

### Campaign Analytics Dashboard
- **KPIs:** Impressions, Clicks, CTR, Conversions, ROAS
- **Segments:** Channel, Campaign, Ad Group, Audience
- **Attribution:** First-touch, Last-touch, Multi-touch

### Sales Pipeline Dashboard
- **KPIs:** Pipeline Value, Win Rate, Velocity, Forecast Accuracy
- **Segments:** Rep, Region, Product, Deal Size
- **Views:** Waterfall, Funnel, Forecast vs Actual

### Content Performance Dashboard
- **KPIs:** Page Views, Time on Page, Bounce Rate, Conversions
- **Segments:** Content Type, Topic, Persona, Journey Stage
- **Trends:** Engagement over time, Top/Bottom performers
