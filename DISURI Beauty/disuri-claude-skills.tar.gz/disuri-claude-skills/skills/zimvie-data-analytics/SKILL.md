---
name: zimvie-data-analytics
description: Data analytics skill for ZimVie marketing intelligence. Use when asked to analyze datasets, create dashboard specifications, build Power BI reports, interpret HubSpot analytics, evaluate campaign performance, or generate actionable business insights. Triggers on requests like "analyze this data", "create a dashboard spec", "what does this data tell us", "build a Power BI report", "HubSpot performance analysis", or any ZimVie marketing/sales data analysis needs.
---

# ZimVie Data Analytics

Analytics skill for dashboard specifications, dataset analysis, and actionable insights focused on Power BI and HubSpot.

## Workflow Selection

**Dashboard Spec Request** → See [references/dashboard-spec-template.md](references/dashboard-spec-template.md)
**Dataset Analysis** → Follow Analysis Framework below
**HubSpot Analytics** → See [references/hubspot-analytics.md](references/hubspot-analytics.md)
**ZimVie Data Sources** → See [references/zimvie-data-sources.md](references/zimvie-data-sources.md)

## Dashboard Spec Workflow

1. **Clarify stakeholder needs**: Who views it? What decisions does it inform? Daily/weekly/monthly?
2. **Define success metrics**: 3-5 primary KPIs with clear definitions and targets
3. **Map data sources**: HubSpot, Salesforce, Google Analytics, ad platforms
4. **Design visual hierarchy**: Executive summary → Key metrics → Drill-downs
5. **Specify interactivity**: Filters, date ranges, segments (persona, product line, region)
6. **Document refresh cadence**: Real-time vs. daily vs. weekly

Output: Complete spec using template in references/dashboard-spec-template.md

## Dataset Analysis Framework

### Phase 1: Orient (5 min)
- What business question are we answering?
- What decisions will this inform?
- Who is the audience?

### Phase 2: Profile (10 min)
- Row count, date range, completeness
- Key dimensions and their cardinality
- Obvious data quality issues

### Phase 3: Analyze (core work)

**For Marketing Performance:**
- Conversion rates by channel/campaign/persona
- Cost efficiency: CPL, CPA, ROAS
- Funnel progression: MQL → SQL → Opportunity → Closed Won
- Time-based trends and seasonality

**For Sales Pipeline:**
- Pipeline velocity by stage
- Win rates by segment
- Deal size distribution
- Rep performance benchmarking

**For Product/Content:**
- Engagement metrics by content type
- Page performance and user flow
- Feature adoption and usage patterns

### Phase 4: Synthesize
Structure findings as:
1. **Executive Summary**: 2-3 sentences, the "so what"
2. **Key Findings**: 3-5 bullets with specific numbers
3. **Recommended Actions**: Prioritized next steps with expected impact
4. **Caveats**: Data limitations, confidence levels

## Power BI Specifics

**Visual Selection:**
- KPI cards for headline metrics
- Line charts for trends over time
- Bar charts for comparisons
- Tables for detailed drill-down
- Funnel visuals for conversion paths

**Filter Best Practices:**
- Date range slicer (default: last 90 days)
- Persona/segment filter
- Product line filter
- Region/territory filter
- Campaign filter for marketing dashboards

**Performance Tips:**
- Use DirectQuery for real-time needs, Import for speed
- Create aggregation tables for large datasets
- Limit visuals per page to 8-10
- Use bookmarks for guided navigation

## Insight Delivery Standards

Every analysis deliverable must include:

| Element | Requirement |
|---------|-------------|
| Business context | Why this matters to ZimVie |
| Specific numbers | No vague claims, always quantify |
| Comparison baseline | vs. prior period, vs. target, vs. benchmark |
| Statistical confidence | For A/B tests: p-value and sample size |
| Actionable recommendation | What to do next |
| Owner/timeline | Who acts and by when |

## ZimVie Persona Segmentation

Always segment analysis by dental persona when relevant:
- **Oral Surgeon**: High-volume implant procedures
- **Periodontist**: Surgical and restorative focus
- **GP Implant**: Growing implant practice
- **GP Restorative**: Restorative-focused general dentist
- **Lab Tech**: Dental laboratory technicians
- **DSO Ops**: Decision-makers at dental service organizations
- **DSO Clinician**: Clinicians within DSO networks
