---
name: zimvie-content-derivation
description: Transform anchor video content into multi-channel derivative assets for ZimVie dental product marketing. Use when repurposing video content (Green Screen Announcements, Clinician Deep Dives, Thought Leadership, KOL Testimonials, Unboxing Videos, Sales Training) into social cutdowns, blog articles, email copy, quote cards, or landing page content. Provides platform-specific specifications and derivation matrices. Trigger phrases include "repurpose video", "create cutdowns", "social clips", "derive content", "video transcription", "blog from video", or any request to transform video into multi-channel content.
---

# ZimVie Content Derivation

## Anchor Video Types

| Video Type | Duration | Purpose | Funnel Stage |
|------------|----------|---------|--------------|
| Green Screen Announcement | 5 min | Launch awareness, product intro | TOFU |
| Clinician Deep Dives | 8-15 min | Step-by-step clinical instruction | MOFU |
| Thought Leadership Interviews | 3-5 min | Brand authority, product story | TOFU/MOFU |
| KOL Testimonials | 2-4 min | Social proof, clinical validation | MOFU/BOFU |
| Product Unboxing | 5 min | Complete product walkthrough | MOFU |
| Sales Training | 10-20 min | Internal enablement | Internal |

## Content Derivation Matrix

### From Green Screen Announcement
→ 15-30 sec teaser clips
→ Speaker highlight cuts
→ Launch countdown content
→ Email header GIFs
→ LinkedIn native video

### From Clinician Deep Dives
→ "Quick tip" Reels (15-30 sec)
→ Technique highlight clips
→ Gated education content
→ YouTube Shorts

### From Thought Leadership Interviews
→ Quote cards (static)
→ Soundbite clips (15-30 sec)
→ "Meet the Team" carousel
→ Blog pull quotes
→ LinkedIn articles

### From KOL Testimonials
→ Social proof clips
→ Landing page embeds
→ Email testimonial blocks
→ Sales deck clips
→ "What they're saying" posts

### From Product Unboxing
→ 30-sec teaser
→ 60-sec feature highlight
→ Blog article (via transcription)
→ Social carousel

### From Video Transcriptions
→ SEO blog articles
→ LinkedIn articles
→ Email copy
→ Landing page copy
→ Press release content

## Platform Specifications

### Instagram Reels
- Duration: 15-30 sec (highest completion)
- Aspect: 9:16 vertical
- Content: Hook-driven, single feature highlight
- Captions: Required (85% watch silent)

### Instagram Stories
- Duration: 15 sec max
- Aspect: 9:16 vertical
- Content: Quick teaser, swipe-up CTA
- Disappears: 24 hours

### LinkedIn Video
- Duration: 30-60 sec
- Aspect: 1:1 or 16:9
- Content: Professional, thought leadership clips
- Native upload preferred

### YouTube Shorts
- Duration: 30-60 sec
- Aspect: 9:16 vertical
- Content: Educational, how-to snippets
- Hashtag: #Shorts

### Facebook Feed
- Duration: 30-60 sec
- Aspect: 1:1 or 4:5
- Content: Broader awareness, testimonial clips
- Autoplay without sound

## Social Cutdown Workflow

1. **Source Selection**: Identify anchor video and key moments
2. **Timestamp Mapping**: Mark in/out points for each platform
3. **Reframing**: Adjust composition for vertical (9:16) formats
4. **Captioning**: Add burned-in captions for silent viewing
5. **Platform Optimization**: Add native elements (CTAs, overlays, lower thirds)
6. **Thumbnail Creation**: High-contrast image with text overlay

## Blog Article Derivation Process

**From Video Transcription to SEO Article (~1,800 words)**

1. **Extract Key Sections**:
   - Product overview statements
   - Feature/benefit explanations
   - Direct quotes from speakers
   - FAQ-worthy content

2. **Apply 12-Section Structure**:
   - H1 Headline (benefit-driven, <60 chars)
   - H2 Subheadline (value prop summary)
   - Introduction (problem/solution hook)
   - Product Overview (features, specs table)
   - Key Benefits (clinical advantages)
   - Behind the Innovation (direct quotes)
   - Clinical Scenario (use case)
   - Video Embed (YouTube + CTA)
   - FAQ Section (5-7 questions, schema-ready)
   - Product Specs (table format)
   - Related Resources (internal links)
   - CTA Footer (multiple conversion paths)

3. **SEO Elements**:
   - JSON-LD schema markup
   - Meta tags and Open Graph
   - Keyword variations throughout
   - Internal linking placeholders

See [references/blog-article-template.md](references/blog-article-template.md) for complete template.

## Quote Extraction Guidelines

**HOOK Format Quotes**: Attention-grabbing, curiosity-creating
- "Say yes to more patients."
- "Start with what you need today. Expand tomorrow."

**FAB Format Quotes**: Feature → Advantage → Benefit
- "Full arch module for organized chairside seating. Includes angled screw channel drivers for TiBases. Keeps full arch instrumentation at your fingertips."

**PAS Format Quotes**: Problem → Agitation → Solution
- "Switching between systems? No more searching for tools. Complete freedom to match the right implant."

## Video KPIs by Type

| Video Type | Primary KPI | Target |
|------------|-------------|--------|
| Green Screen Announcement | Video Completion Rate | >50% |
| Clinician Deep Dives | Average Watch Time | >60% duration |
| Thought Leadership | Engagement Rate | >3% |
| KOL Testimonials | Landing Page CVR Lift | +15% vs control |
| Social Cutdowns | Engagement Rate | >4% on Reels |
| Sales Training | Completion Rate | >90% |

## Content Ownership Matrix

| Derivative Type | Primary Owner |
|-----------------|---------------|
| Social cutdowns | Video Team + Social |
| Quote cards | Video Team + Social |
| Blog articles | Product Manager |
| Email copy | Digital Marketing (Joel) |
| Landing page copy | Web Manager (Caro) |
| Sales deck clips | Video Team + Sales Ops |

## Quick Derivation Checklist
- [ ] Source video transcribed
- [ ] Key timestamps identified
- [ ] Platform formats determined (16:9, 9:16, 1:1)
- [ ] Captions/subtitles created
- [ ] Brand elements applied (lower thirds, logo, colors)
- [ ] CTAs included for each platform
- [ ] UTM parameters set
- [ ] Thumbnail created
- [ ] Legal/Regulatory approved
