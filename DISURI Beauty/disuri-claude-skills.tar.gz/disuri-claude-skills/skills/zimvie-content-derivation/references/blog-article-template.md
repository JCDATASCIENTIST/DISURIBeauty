# SEO Blog Article Template

Use this 12-section structure for all ZimVie product launch blog articles derived from video transcriptions.

## Article Structure (~1,800 words)

### 1. H1 Headline
- Benefit-driven with target keywords
- Include product name, key innovation, primary benefit
- Keep under 60 characters for SEO

**Example**: "Introducing the ZimVie TSX Kit: The All-in-One Modular Implant System Built for Clinical Versatility"

### 2. H2 Subheadline
- Value proposition summary
- One sentence expanding on headline
- Supports with additional context

**Example**: "Streamline your implant workflow with universal compatibility, intuitive organization, and the flexibility to scale as your practice grows."

### 3. Introduction (150-200 words)
- Hook addressing the problem
- Integrate target audience naturally
- Introduce solution without overselling
- Include primary SEO keywords

**Structure**:
- Sentence 1-2: Problem statement
- Sentence 3-4: Introduce the solution
- Sentence 5-6: Key differentiator
- Sentence 7-8: Promise/outcome

### 4. Product Overview
- Core features and architecture
- Pull from transcript and documentation
- Include visual summary table for scanability

**Include**:
- Design philosophy (3 core principles)
- Architecture overview (e.g., two-level system)
- Specifications summary table

### 5. Key Benefits
- Clinical advantages
- Workflow differentiators
- Comparison table (vs. legacy/competitors)
- Bullet lists for scanability

**Categories**:
- Clinical Advantages (3-5 bullets)
- Workflow Differentiators (3-5 bullets)
- Comparison Table (Feature | Traditional | New Product)

### 6. Behind the Innovation
- Direct quotes from transcript
- Pull insights where PMs/engineers speak
- Storytelling that humanizes the product
- Use quote formatting with attribution

**Quote block format**:
```
"[Direct quote from video transcript]"
— [Name], [Title], ZimVie
```

### 7. Clinical Scenario
- Real-world use case showing application
- Create relatable clinician persona
- Emphasize improved outcomes and workflow

**Structure**:
- The Situation: Describe the clinician and practice
- Before: Pain points with current approach
- With [Product]: How the product changes workflow
- The Result: Outcomes achieved

### 8. Video Embed
- YouTube placeholder with CTA
- Include video description
- Call-to-action below video

```html
[Embed YouTube Video Here: Product Name Overview]

Video Description: Watch ZimVie's product team walk through the [product] features...

Ready to learn more? Download the full brochure or contact your ZimVie representative.
```

### 9. FAQ Section (5-7 questions)
- Schema-ready formatting (JSON-LD)
- Address common objections
- Pull from typical customer questions

**Format each FAQ**:
```
**Q: [Question]?**

[Answer in 2-4 sentences. Be specific and helpful.]
```

### 10. Product Specs
- Full specifications table
- Module/component breakdown
- Use schema.org Product markup
- Include download links

**Tables**:
- Main specifications (Feature | Value)
- Available modules/components
- Download links (PDF documentation)

### 11. Related Resources
- Internal linking section
- Related products, blog posts, education portal
- Supports SEO through site architecture

**Include links to**:
- Related product pages
- Compatibility guides
- Education portal/webinars
- Other blog posts in category

### 12. CTA Footer
- Multiple conversion paths
- Options for different buyer readiness levels

**CTAs to include**:
- Download Brochure (gated PDF)
- Contact Your Representative
- Watch Full Demo Video
- Register for Upcoming Webinar
- Social media follow links

---

## SEO Elements Checklist

### Meta Information
- [ ] Title tag: 50-60 characters with product name and key benefit
- [ ] Meta description: 150-160 characters with value prop and CTA
- [ ] Primary keyword in H1, intro, and throughout
- [ ] Secondary keywords distributed naturally

### Schema Markup (JSON-LD)
- [ ] Article schema
- [ ] FAQPage schema
- [ ] Product schema
- [ ] VideoObject schema (if video embedded)

### On-Page SEO
- [ ] H2/H3 headings every 200-300 words
- [ ] Internal links: 3-5 to related pages
- [ ] Featured image: 1200 x 628 px with alt text
- [ ] Image alt tags on all images

### Funnel Alignment
| Section | Funnel Stage |
|---------|--------------|
| Headline, Intro, Overview | Awareness |
| Benefits, Innovation, Scenario, FAQ, Specs | Consideration |
| Video CTA, Resources, CTA Footer | Conversion |

---

## Article Metadata Template

```yaml
Title Tag: [Product] - [Key Benefit] | ZimVie
Meta Description: Discover [Product] - [value prop in 150 chars]...
Primary Keywords: [product name], [category]
Secondary Keywords: [3-5 related terms]
Category: Products, [Subcategory]
Target Audience: Oral Surgeons, Periodontists, General Dentists
Funnel Stage: Awareness / Consideration
Word Count: ~1,800 words
Author: ZimVie Digital Marketing Team
```
