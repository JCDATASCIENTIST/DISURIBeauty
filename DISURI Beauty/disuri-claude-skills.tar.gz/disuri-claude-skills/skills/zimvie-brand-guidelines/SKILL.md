---
name: zimvie-brand-guidelines
description: ZimVie brand identity specifications for dental/spine medical device marketing. Use when creating any ZimVie-branded content including presentations, documents, social media graphics, emails, landing pages, or marketing collateral. Provides logo usage rules, color palette (PMS/CMYK/RGB/HEX), typography (Soleil/Palatino), visual elements, and brand voice guidance. Trigger phrases include "ZimVie brand", "brand guidelines", "logo usage", "brand colors", "ZimVie formatting", or any request for branded marketing materials.
---

# ZimVie Brand Guidelines

## Brand Foundation

**Vision**: Everyone deserves to feel better, healthier, and stronger. We create solutions for people to enjoy and experience life.

**Mission**: Advancing clinical technology foundational to restoring daily life.

**Values**: Growth Mindset, Accountability, Authenticity, Curiosity

**Brand Persona**: Passionate, Disruptive, Proactive, Agile

## Logo Usage

**Pronunciation**: [zihm vee] — "Zim" from Zimmer Biomet heritage, "vie" (French for "life")

**Primary Format**: Horizontal logo with tagline "Restoring Daily Life™"

**Limited Use Format**: Stacked (square) format — only when space is constrained

**Protected Space**: Minimum clearance = size of "Z" circle icon around all sides

**Company Name in Text**: Always "ZimVie" (upper camel-case), never "Zimvie", "ZIMVIE", or "ZV"

**Co-branding**: ZimVie logo must be 15-20% larger than partner logos

### Logo Don'ts
- Never add ®/™ to logo (tagline gets ™)
- Never alter colors, condense, stretch, skew, or tint
- Never use on distracting/low-contrast backgrounds
- Never recreate — use official artwork only

## Color Palette

### Primary Colors (Dominant Use)
| Color | PMS | CMYK | RGB | HEX |
|-------|-----|------|-----|-----|
| ZimVie Navy | 2768 | 100,87,40,50 | 10,32,66 | #0a2043 |
| ZimVie Sky Blue | 2915 | 55,9,0,3 | 97,182,226 | #61b6e2 |
| ZimVie Lemon | 3945 | 13,4,99,0 | 230,220,25 | #e6dc19 |
| ZimVie Rich Gray | 446 | 33,22,22,75 | 65,70,73 | #414649 |
| ZimVie Silver | Cool Gray 6 | 35,29,26,0 | 170,168,173 | #aaa9ad |

### Secondary Colors (Accent Only — Max 2-3 per piece)
| Color | PMS | CMYK | RGB | HEX |
|-------|-----|------|-----|-----|
| ZimVie True Blue | 2935 | 95,68,3,0 | 0,93,166 | #005da6 |
| ZimVie Poppy | 1575 | 0,63,79,0 | 244,126,72 | #f47e48 |
| ZimVie Lime | 367 | 41,0,82,0 | 161,206,94 | #a1ce5e |

### Neutral Colors
| Color | PMS | CMYK | RGB | HEX |
|-------|-----|------|-----|-----|
| ZimVie Chrome | 7541 | 14,7,8,0 | 216,223,225 | #dbe0e2 |
| ZimVie Pewter | 7544 | 56,41,34,4 | 149,162,174 | #798591 |

**Color Rules**: Limit palette to 5-6 colors per piece. Secondary colors < 50% of total color usage.

## Typography

### Primary Sans-Serif (Print, Digital, Web)
**Soleil** — Light, Light Italic, Regular, Regular Italic, Book, Book Italic, Semi-Bold, Semi-Bold Italic, Bold, Bold Italic

Desktop substitute: **Arial**

### Secondary Serif (Technical Documents, White Papers)
**Palatino LT Std** — Light, Roman, Medium, Bold (+ Italics)

Desktop substitute: **Times Roman**

### Product Naming
- Product names: Soleil Bold
- Descriptors: Soleil Regular
- No custom product logos — text only with appropriate trademark symbols

### Trademark Usage
- Superscript and reduce size of ®/™ symbols
- Apply to headlines, subheads, and first body copy mention
- Extra attention in headlines to align with top of preceding letter

## Visual Elements

### Quarter-Circle Shape
Derived from the "i" dot in logo. Use to:
- Create visual separation between sections
- Build patterns and decorative elements
- Frame quotes and callouts

### Pattern Grid
- Open patterns for subtle backgrounds
- Light backgrounds: 65-70% opacity
- Dark backgrounds: 20-25% opacity

### Quote Styling
- Use two quarter-circle shapes as quotation marks
- Colors from primary/secondary palette
- Soleil font for quoted text

## Business Units

**Dental**: Surgical, Digital Dentistry, Regenerative, Restorative

**Spine**: MIS Solutions, Motion Preservation, Cervical, Thoracolumbar, Biologics

**EBI Bone Healing**: Non-Invasive/Implantable Electrical Stimulation, Vascular Compression

No individual division branding — all use master ZimVie brand.

## Imagery Guidelines

**Healthcare Professionals**: Authentic, diverse, relevant to modern practice

**Patients/Caregivers**: Pleasant, trustworthy, confident (not overly enthusiastic)

**Product Photography**: Clean white surface, soft shadows, reflections, multiple angles

**Diversity**: Represent global audience and different cultures

## Email Signature Format
```
First Name Last Name  [Arial Bold, 12pt]
Title, Department  [Arial Regular, 10pt]

D. 123.456.7890  [Arial Regular, 12pt]
M. 123.456.7890
email@ZimVie.com
```
No images, banners, or slogans beyond logo.

## Quick Reference Checklist
- [ ] Logo is official artwork, not recreated
- [ ] Protected space maintained around logo
- [ ] Company name written as "ZimVie"
- [ ] Colors from approved palette only
- [ ] Typography uses Soleil/Palatino (or Arial/Times substitutes)
- [ ] Secondary colors limited to accent use
- [ ] Product names in text, not custom logos
- [ ] Trademark symbols properly superscripted
- [ ] Imagery represents diversity
