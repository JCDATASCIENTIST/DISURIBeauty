---
name: zimvie-product-launch
description: Master orchestration skill for ZimVie dental product launches. Use when planning or executing a full product launch campaign, coordinating cross-functional deliverables, creating launch timelines, or managing the omnichannel marketing playbook. Covers the complete launch lifecycle from T-16 weeks through T+4 weeks post-launch, including video production, content creation, email campaigns, paid media, and the 4-stage user journey funnel. Trigger phrases include "product launch", "launch plan", "launch timeline", "launch checklist", "campaign coordination", or any comprehensive product go-to-market request.
---

# ZimVie Product Launch SOP

## Overview

This skill provides a repeatable, scalable framework for launching dental products at ZimVie. It ensures alignment between Product Management, Marketing, Sales, Education, and Compliance teams while maximizing content efficiency through strategic repurposing.

## Target Audiences
- Oral Surgeons
- Periodontists  
- General Dentists (implant-placing)
- Dental Labs
- Prosthodontists

## Stakeholders & Roles

| Role | Owner | Responsibilities |
|------|-------|------------------|
| Product Manager | Hannah/Justin | Product docs, clinical claims, storyboards, regulatory, blog, core messaging |
| Product Marketing Leader | Jane | Final approval, storyboard sign-off, messaging alignment |
| Digital Marketing Strategist | Joel | Funnel strategy, UTM tracking, paid media, retargeting, core messaging |
| Video Team | Jesse + Team | Video production, transcription, cutdowns, green screen |
| Social Media Manager | Daniela | Social scheduling, platform optimization, community engagement |
| Web Team | Caro/Emilia | Landing page, homepage banner, e-commerce, video embedding |
| Education Team | Anne-Marie | Webinars (PATH C), KOL coordination, clinician deep dives |
| Legal/Regulatory | Lori/Jane/Legal | Claims review, compliance, video script approval |

## 4-Stage User Journey

### Stage 1: Awareness (TOFU)
**Goal**: Generate awareness among target HCP audiences

**8 Entry Touchpoints**:
1. LinkedIn Article/Post + Video clips
2. Facebook/IG Post + Reels/Stories
3. YouTube Video + Shorts
4. Display Ads (StackAdapt)
5. Press Release
6. Homepage Banner
7. Blog Article (SEO)
8. Email Blast

See [references/stage-guides.md](references/stage-guides.md) for detailed specs.

### Stage 2: Consideration (MOFU)
**Goal**: Educate engaged prospects through deeper content

**2 Key Assets**:
1. Product Landing Page (all traffic destination)
2. Full Unboxing Video (5 min)

Supporting content: Clinician Deep Dives, Thought Leadership, KOL Testimonials

### Stage 3: Conversion (BOFU)
**Goal**: Convert prospects into customers

**3 Paths**:
- **PATH A**: E-Commerce Purchase → Direct sale
- **PATH B**: Contact Rep / Download Brochure → Lead nurture → Rep handoff
- **PATH C**: Education Webinar (for 120-day non-converters)

**Retargeting Loop**: Non-converters cycle through retargeting ads (StackAdapt + Social) for up to 120 days before moving to PATH C.

### Stage 4: Post-Purchase
**6 Tracks**: Onboarding, Education, Support, Legacy Implant Support, Repeat Purchase, Advocacy

## Video Content Suite

Video serves as the primary anchor for all launch content.

| Video Type | Duration | Purpose | KPI Target |
|------------|----------|---------|------------|
| Green Screen Announcement | 5 min | Launch buzz, multi-speaker | >50% VCR |
| Clinician Deep Dives | 8-15 min | Clinical instruction | >60% watch time |
| Thought Leadership | 3-5 min | Brand authority | >3% engagement |
| KOL Testimonials | 2-4 min | Social proof | +15% CVR lift |
| Product Unboxing | 5 min | Product walkthrough | MOFU anchor |
| Sales Training | 10-20 min | Internal enablement | >90% completion |
| Social Cutdowns | 15-60 sec | Platform-native | >4% engagement |

## Master Launch Timeline

### Pre-Launch: T-16 to T-2 Weeks

| Week | Activities | Owner(s) |
|------|------------|----------|
| T-16 | Product documentation, kickoff, Product Brief | PM, DMS |
| T-15 | Core messaging, storyboards for ALL video types | DMS, PM, Video |
| T-14 | Complete storyboards, PM review, Legal review | DMS, Video, PM, Legal |
| T-12 | Jane approval, GREEN SCREEN SHOOT, internal interviews | Jane, Video, DMS |
| T-10 | Product unboxing, sales training video, landing page wireframe | Video, DMS, Caro |
| T-8 | KOL testimonial capture, clinician deep dive filming | Video, Education |
| T-6 | Social cutdowns (all platforms), transcription to PM for blog | Video, PM, Social |
| T-4 | Final approval, schedule posts, load emails, landing page live | All Teams |

### Launch Week & Post-Launch: T0 to T+4 Weeks

| Week | Activities | Owner(s) |
|------|------------|----------|
| T0 | LAUNCH: Publish all videos, banner, blog, campaigns, email, PR | All Teams |
| T+1 | Monitor daily, social engagement, activate retargeting with video ads | DMS, Daniela |
| T+2 | Mid-launch performance review, optimize campaigns, A/B test cutdowns | DMS |
| T+3 | Follow-up email to non-openers, continue organic social, PATH C list building | DMS, Daniela |
| T+4 | Post-launch report, team retrospective, document learnings, Education begins PATH C | All Teams |

## Content Derivation Quick Reference

**From Video → Derivative Assets**:
- Green Screen → Teaser clips, email GIFs, LinkedIn video
- Deep Dives → Quick tip Reels, technique highlights
- Thought Leadership → Quote cards, soundbite clips
- Testimonials → Social proof clips, landing page embeds
- Transcriptions → SEO blog, email copy, landing page copy

## UTM Tracking Convention

```
?utm_source=[platform]&utm_medium=[channel]&utm_campaign=[product-name]-launch&utm_content=[video-type]
```

## Launch Checklist

### T-16 (Kickoff)
- [ ] Product Brief completed
- [ ] Kickoff meeting scheduled
- [ ] Core team identified

### T-14 (Storyboards)
- [ ] All video storyboards drafted
- [ ] Legal/Regulatory review submitted
- [ ] Core messaging approved

### T-12 (Production)
- [ ] Green screen shoot completed
- [ ] Thought leadership interviews captured
- [ ] Landing page wireframe approved

### T-8 (Content Creation)
- [ ] KOL testimonials scheduled/captured
- [ ] Clinician deep dives filmed
- [ ] Post-production underway

### T-4 (Final Prep)
- [ ] All content approved by Legal
- [ ] Social posts scheduled
- [ ] Email campaigns loaded
- [ ] Landing page live
- [ ] Paid campaigns queued
- [ ] Sales team briefed

### T0 (Launch Day)
- [ ] All videos published
- [ ] Homepage banner deployed
- [ ] Blog article live
- [ ] Email blast sent
- [ ] Press release distributed
- [ ] Paid campaigns activated
- [ ] Social posts live

### T+4 (Post-Launch)
- [ ] Post-launch report delivered
- [ ] Video KPIs analyzed
- [ ] Retargeting optimized
- [ ] Learnings documented
- [ ] PATH C webinar planning initiated

## Related Skills

- **zimvie-brand-guidelines**: Logo, colors, typography, visual elements
- **zimvie-campaign-copywriting**: HOOK/FAB/PAS frameworks, channel guidelines
- **zimvie-content-derivation**: Video-to-multichannel asset transformation

## Resources

See [references/stage-guides.md](references/stage-guides.md) for detailed Stage 1-4 content specifications.
