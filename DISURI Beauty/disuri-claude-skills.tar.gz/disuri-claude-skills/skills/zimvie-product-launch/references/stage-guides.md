# Stage Content Guides

Detailed specifications for each funnel stage in the ZimVie product launch user journey.

---

## Stage 1: Awareness (TOFU)

### 1. LinkedIn Article/Post
| Element | Specification |
|---------|---------------|
| Post Length | 150-300 words |
| Article Length | 800-1,500 words |
| Image Size | 1200 x 627 px |
| Video Length | 30-90 seconds |
| Hashtags | 3-5 (#DentalImplants #Periodontology #OralSurgery #ZimVie) |
| Best Times | Tuesday-Thursday, 7-8 AM or 12 PM |

### 2. Facebook/Instagram Post
| Element | Specification |
|---------|---------------|
| Caption (FB) | 100-250 characters |
| Caption (IG) | 138-150 chars above fold |
| Feed Image | 1080 x 1080 px (1:1) or 1080 x 1350 px (4:5) |
| Reel/Story | 1080 x 1920 px (9:16) |
| Carousel | 5-10 slides |
| Reel Duration | 15-30 seconds |

### 3. Blog Article (SEO)
| Element | Specification |
|---------|---------------|
| Word Count | 1,500-2,500 words |
| Title Tag | 50-60 characters |
| Meta Description | 150-160 characters |
| H2/H3 Headings | Every 200-300 words |
| Internal Links | 3-5 per article |
| Schema | Article, FAQ, Product (JSON-LD) |

### 4. YouTube Video
| Element | Specification |
|---------|---------------|
| Teaser Clip | 30 seconds |
| Feature Highlight | 60 seconds |
| Full Unboxing | 5 minutes |
| Shorts | < 60 seconds (9:16) |
| Thumbnail | 1280 x 720 px |
| Title | 60-70 characters |

### 5. Display Ad (StackAdapt)
| Ad Size | Dimensions |
|---------|------------|
| Medium Rectangle | 300 x 250 |
| Leaderboard | 728 x 90 |
| Wide Skyscraper | 160 x 600 |
| Billboard | 970 x 250 |
| Mobile Banner | 320 x 50 |

**Creative Requirements**: JPG/PNG/GIF/HTML5, max 150KB static, 200KB animated, 15 sec max animation

### 6. Email Blast
| Element | Specification |
|---------|---------------|
| Subject Line | 40-50 characters |
| Preview Text | 85-100 characters |
| Email Width | 600px max |
| Hero Image | 600 x 300 px |
| Body Copy | 50-125 words |
| CTA Button | 44px height min |
| Best Times | Tuesday-Thursday, 10 AM or 2 PM |

### 7. Press Release
| Element | Specification |
|---------|---------------|
| Headline | 65-80 characters |
| Subheadline | 120-150 characters |
| Lead Paragraph | 25-30 words (Who, What, When, Where, Why) |
| Body | 300-500 words |
| Boilerplate | ~100 words |

### 8. Homepage Banner
| Element | Specification |
|---------|---------------|
| Desktop Size | 1920 x 600 px |
| Mobile Size | 768 x 400 px |
| CTA Button | High contrast, action-oriented |
| Rotation | 3-5 seconds auto-advance |

---

## Stage 2: Consideration (MOFU)

### Product Landing Page Structure

| Section | Content |
|---------|---------|
| 1. Hero | Product name, headline, hero image/video, primary CTA |
| 2. Value Proposition | 3-4 key benefits with icons |
| 3. Product Video | Embedded 5-minute unboxing |
| 4. Features Deep Dive | Tabbed/accordion format, specs |
| 5. Compatibility | Implant system compatibility table |
| 6. Clinical Evidence | Studies, FDA clearance |
| 7. Social Proof | KOL testimonials, case studies |
| 8. FAQ | 5-7 questions, accordion format |
| 9. Resources | Brochure, IFU, technique guides |
| 10. CTA Section | Buy Now, Contact Rep, Download |
| 11. Related Products | Cross-sell opportunities |

**Technical Requirements**:
- Page load: < 3 seconds
- Mobile responsive: Required
- Schema markup: Product, FAQPage, VideoObject
- Tracking: HubSpot, GA4, conversion pixels

### Full Unboxing Video (5 min)

| Timestamp | Section | Content |
|-----------|---------|---------|
| 0:00-0:15 | Hook | Problem statement, reveal |
| 0:15-0:30 | Intro | Logo animation, presenter intro |
| 0:30-1:00 | Overview | Design philosophy, value props |
| 1:00-2:00 | Top Level | Core tooling walkthrough |
| 2:00-3:00 | Deep Dive | Module breakdown |
| 3:00-3:45 | Compatibility | System compatibility |
| 3:45-4:15 | Benefits | Workflow improvements |
| 4:15-4:45 | Scalability | Growth messaging |
| 4:45-5:00 | CTA | Summary, next steps |

**Specs**: 4K preferred, 16:9, 30fps, captions required, branded thumbnail

---

## Stage 3: Conversion (BOFU)

### PATH A: E-Commerce
Direct purchase through eservices.zimviedental.com

**Friction Points to Address**:
- Account required messaging on landing page
- Simplified login flow
- Direct deep links to product (not homepage)
- Abandoned cart email sequence

### PATH B: Lead Capture Forms

**Contact Rep Form (High Intent)**:
- First Name (required)
- Last Name (required)
- Email (required)
- Phone (required)
- Practice Name (required)
- Zip Code (required - for routing)
- Specialty (dropdown)
- Product of Interest (hidden)
- Comments (optional)

**Download Brochure Form (Medium Intent)**:
- First Name (required)
- Last Name (required)
- Email (required)
- Zip Code (required)
- Product of Interest (hidden)

**Lead Routing**:
1. Form submission → HubSpot CRM
2. Thank you email (immediate)
3. Sales distribution notification
4. Territory routing (zip-based)
5. Rep follow-up (24-48 hour SLA)
6. Salesforce sync

### PATH C: Education Webinar (120-day non-converters)

**Webinar Types**:
- Product Deep Dive: 45-60 min
- Clinical Technique (KOL): 60-90 min
- Case Presentation: 30-45 min
- On-Demand: 20-30 min

**Registration Page Elements**:
- Compelling title
- Speaker bio + photo
- Learning objectives (3-4 bullets)
- CE credit info
- Social proof

### Retargeting Loop

**Phased Messaging (120-day window)**:
- Days 1-30: Product Recall
- Days 31-60: Social Proof
- Days 61-90: Objection Handling
- Days 91-120: Education CTA
- 120+: Move to PATH C

**Frequency Caps**:
- Display: 3-5 impressions/user/day
- Social: 1-2 impressions/user/day
- Monthly cap: 60-90 total impressions

---

## Stage 4: Post-Purchase

### Onboarding Email Sequence

| Timing | Email | Content |
|--------|-------|---------|
| Immediate | Order Confirmation | Order details, delivery estimate |
| Shipped | Shipping Notification | Tracking number |
| Delivered | Welcome + Quick Start | Guide link, unboxing video, rep intro |
| Day 3 | Getting Started Tips | Top 3 tips, technique video |
| Day 7 | Check-In | Survey, support resources |
| Day 14 | Advanced Features | Next-level tips, additional modules |
| Day 30 | Review Request | Feedback link |

### Education Content Types
- Technique Videos (5-15 min)
- Tips & Tricks (2-5 min)
- Case Presentations (webinar)
- Live Webinars (45-90 min, CE eligible)
- On-Demand Courses
- IFU Walkthroughs (10-20 min)
- SME Interviews (podcast)

### Support Channels
- Chatbot (ManyChat): 24/7
- Live Chat: < 2 min response
- Phone: < 3 min hold time
- Email: < 24 hour response
- Rep: < 48 hour response

### Legacy Implant Support
Key systems: Biomet 3i (OSSEOTITE, NanoTite, Certain), Zimmer (TSV, Tapered Screw-Vent), Zimmer Dental (Hex-Lock, SwissPlus)

**Chatbot Flow**:
1. Identify legacy implant request
2. Information gathering (brand, age, records)
3. Image upload request (X-ray)
4. Quick match or expert handoff
5. Product recommendation
6. Purchase path

### Repeat Purchase Triggers
- Consumable replenishment (60/90-day)
- Cross-sell (30-60 days post-purchase)
- Upsell (90+ days)
- New product launch
- Re-engagement (180+ days)

### Customer Advocacy Ladder
1. Review/Rating
2. Social Mention
3. Testimonial (Quote)
4. Video Testimonial
5. Case Study
6. Webinar Guest Speaker
7. KOL Partnership
