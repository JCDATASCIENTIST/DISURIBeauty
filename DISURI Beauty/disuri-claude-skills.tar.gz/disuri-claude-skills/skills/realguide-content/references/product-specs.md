# RealGUIDE Product Specifications

Complete technical and product details for content generation.

## Table of Contents
1. [PLAN Module](#plan-module)
2. [APP Module](#app-module)
3. [GUIDE Module](#guide-module)
4. [CAD Module](#cad-module)
5. [FULL SUITE Module](#full-suite-module)
6. [Pricing Details](#pricing-details)
7. [Platform Features](#platform-features)
8. [Target Audiences](#target-audiences)

---

## PLAN Module

**Purpose:** Software for diagnosis and planning for guided surgery

**Price:** FREE for life

**Key Features:**
- Visualize digital records by merging CBCT & STL for complete 3D patient picture
- Set goals for oral rehabilitation with prosthetically driven implant planning
- Plan implants and multi-unit abutments for pre-surgical visualization
- Inventory selection for guides when desired
- Share created files with entire multidisciplinary treatment team

**Use Cases:**
- Treatment planning visualization
- Implant placement planning
- Team collaboration and case sharing
- Pre-surgical assessment

---

## APP Module

**Purpose:** Access projects shared on the cloud from anywhere using iOS devices

**Price:** $9/month

**Key Features:**
- Download from App Store using keyword "RealGUIDE Dental"
- Place virtual implants with touch of fingertip
- Message and share data with team members
- Manage projects from any location
- iOS native application

**Use Cases:**
- Mobile case review
- On-the-go project management
- Quick implant placement adjustments
- Team communication

---

## GUIDE Module

**Purpose:** Surgical guide design module supporting simple single-unit to complex full-arch surgical guides

**Pricing Tiers:**
- **Digital Doc:** $49/month (1 free guide click/month)
- **Enterprise:** $149/month (5 free guide clicks/month)

**Key Features:**
- Seamlessly import implant planning data
- Design surgical guides supported by bone, teeth, or soft tissue
- Export STL files optimized for 3D printing or milling
- Intuitive workflow with all functionalities
- APP module included

**Subscription Details:**
- 3-month or 12-month subscription options
- Paid upfront or monthly payment options
- Click bundles available for additional exports
- Digital Doc: Higher click bundle pricing
- Enterprise: Lower click bundle pricing

---

## CAD Module

**Purpose:** Cutting-edge restorative design software module for simple to complex restorative design

**Price:** $249/month

**Indications Supported:**
- Crowns & Bridges
- Abutments
- Full-arch Bars
- Overdenture and removable prosthesis
- Dentures
- Immediate Load Provisional

**Functionalities Supported:**
- Encode Libraries
- Provisional Planning
- Jaw Motion Visualizer
- Bar Designer module
- Model Creator module

**Key Differentiators:**
- All different restorative modules combined in one
- Compatible with vast library of abutments and tooth libraries
- Extensive modeling and AI tools (unique to RealGUIDE)
- Intuitive user interface
- Less regimented software with more freedom
- Cloud-based license management (no dongles)
- Integrated with all major CAM software
- Integrated with Implant Concierge Design services
- Integrated with ZimVie Milling Center & 3rd party milling centers
- All-in-one pricing
- Low start-up costs
- Monthly and annual subscription plans

---

## FULL SUITE Module

**Purpose:** Comprehensive module combining PLAN, GUIDE, and CAD modules in one software ecosystem

**Price:** $349/month

**Includes:**
- All PLAN module features (treatment planning)
- All GUIDE module features (surgical guide design)
- All CAD module features (restorative design)
- One-stop-shop solution for digital dental design needs

---

## Pricing Details

### Subscription Summary

| Module | Monthly Price | Notes |
|--------|---------------|-------|
| PLAN | FREE | Free for life |
| APP | $9 | iOS mobile access |
| GUIDE - Digital Doc | $49 | 1 free guide click/month |
| GUIDE - Enterprise | $149 | 5 free guide clicks/month |
| CAD | $249 | Unlimited exports, open format |
| FULL SUITE | $349 | Complete solution |

### Click Bundles

- Click bundles can be purchased when customer exhausts allocated exports/clicks
- Provided complimentary with subscription
- Enterprise tier has lower click bundle pricing than Digital Doc

### Subscription Terms

- 3-month or 12-month subscription options
- Paid upfront or monthly payment available
- Open format export for CAD module

---

## Platform Features

### Universal Compatibility
- Compatible with DICOM and STL files from any device
- Open to all implant systems
- Multiple licensing options for doctors and dental labs

### Multi-Platform Support
- PC native
- Mac native
- iOS mobile (Apple) native

### Cloud Infrastructure
- Patient data archived on computer
- Available on-demand during active projects through cloud platform
- Cloud-based license management (no software dongles)

### Collaboration Tools
- Integrated communication system
- Share and discuss clinical cases with clinicians, dental technicians, radiologists
- Clinics and labs can collaborate on same patient's project

### AI Tools
- Comprehensive AI tools for efficient design
- Streamlined surgical and restorative design workflows
- Only software with comprehensive AI tools in this category

### Ease of Use
- Extremely easy to use
- Manage virtual patient with click of mouse or touch of finger
- Intuitive user interface throughout

### Cost Benefits
- Low initial investment
- Affordable monthly subscriptions
- Low click fees

---

## Target Audiences

### Primary: Dental Labs
- Digital workflow efficiency
- Software integration capabilities
- Precision and accuracy focus
- Productivity gains

**Key Messages:**
- Universal compatibility with all systems
- Cloud collaboration with clinicians
- Comprehensive restorative design tools
- Low barrier to entry

### Secondary: Clinicians
- Oral surgeons
- Periodontists
- Prosthodontists
- General dentists (implant-placing)

**Key Messages:**
- FREE treatment planning
- Prosthetically driven implant planning
- Surgical guide design options
- Team collaboration features

---

## Competitive Positioning

**Unique Value Props:**
1. Only software with comprehensive AI tools for surgical AND restorative design
2. FREE treatment planning module (PLAN) for life
3. Universal, open platform - works with any implant system
4. True multi-platform: PC, Mac, iOS native (not emulated)
5. No dongles - cloud-based license management
6. All restorative modules combined in one (CAD)
7. Integrated with ZimVie ecosystem + third-party milling centers
