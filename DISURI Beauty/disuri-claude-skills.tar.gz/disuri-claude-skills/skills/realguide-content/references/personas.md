# RealGUIDE Target Personas

Complete persona profiles for targeted content creation. **Priority order: Dental Lab Designer > Periodontist > General Practitioner > DSO**

---

## 1. DENTAL LAB DESIGNER (Primary Target)

**Role:** CAD/CAM Specialist at full-service dental lab

### Needs
- Efficient digital design
- Rapid case turnaround
- Compatibility with multiple implant systems
- Flexibility in software access
- Access to training

### Goals
- Quick design turnaround timelines
- Open system with less rigidity
- Maintain precision and consistency
- Remote case access
- One software for simple to complex cases
- Easier collaboration with their doctors

### How RealGUIDE Helps
- AI tools to automate design and speed up case design
- Seamless open import/export of files
- Comprehensive digital design modules for bars, abutments, and restorations
- Dongle-free cloud-based license management structure for remote access
- Surgical and restorative modules along with Sandbox custom design environment all in one software
- Cloud-based collaboration with clinics and doctors

### Key Messages for Dental Lab Designers
| Pain Point | RealGUIDE Solution | Benefit |
|------------|-------------------|---------|
| Slow turnaround | AI-powered automation | Faster case completion |
| Rigid software | Open import/export | Work with any system |
| Multiple tools needed | All-in-one platform | Simplified workflow |
| Dongle dependency | Cloud-based licensing | Work from anywhere |
| Doctor communication | Cloud collaboration | Seamless case sharing |

### Sample Content for Dental Labs

**Social Hook:**
"Tired of switching between 3 different software systems to complete one case? RealGUIDE combines surgical planning, guide design, and CAD restoration in one open platform."

**Email Subject Lines:**
- "Cut your case turnaround time with AI-powered design"
- "Finally—one software for bars, abutments, AND restorations"
- "No more dongles. Design from anywhere."

**Video Script Opening:**
"As a lab designer, you know the frustration of juggling multiple software systems, waiting on file conversions, and being tied to a single workstation. What if there was a better way?"

---

## 2. PERIODONTIST

**Role:** Periodontist specialist

### Needs
- Predictable surgical planning
- Implant placement accuracy
- Predictable full-arch outcomes
- Easier collaboration
- Save treatment planning time

### Goals
- Minimize chair time via faster and accurate treatment planning
- Reduce surgical complications
- Easier complex full-arch case design
- Collaborate and communicate easily with labs and referrals

### How RealGUIDE Helps
- Integrations with iTero and Medit scanners for faster scan integration
- AI tools to treatment plan faster
- Offers accurate implant and guide design
- Intuitive workflow aiding complex case design
- Facilitates seamless cloud-based collaboration with referring dentists and labs

### Key Messages for Periodontists
| Pain Point | RealGUIDE Solution | Benefit |
|------------|-------------------|---------|
| Long planning time | iTero/Medit integration + AI | Faster treatment planning |
| Surgical uncertainty | Accurate guide design | Predictable outcomes |
| Complex full-arch cases | Intuitive workflow | Simplified case design |
| Lab communication delays | Cloud collaboration | Real-time case sharing |

### Sample Content for Periodontists

**Social Hook:**
"What if you could cut your treatment planning time in half while improving surgical accuracy? RealGUIDE's AI-powered planning integrates directly with your iTero or Medit scanner."

**Email Subject Lines:**
- "Reduce chair time with faster treatment planning"
- "Full-arch cases just got easier"
- "Your scanner + RealGUIDE = seamless workflow"

**Video Script Opening:**
"Every minute you spend on treatment planning is a minute away from patient care. RealGUIDE helps you plan faster without sacrificing accuracy."

---

## 3. GENERAL PRACTITIONER

**Role:** General Practitioner foraying into implantology

### Needs
- Reliable restorative planning
- Simplified single unit case planning
- Prosthetically driven implant planning
- Digitize their design workflow
- Easier collaboration with local lab

### Goals
- Deliver natural-looking restorations
- Consistency in implant placement for new implantologists
- Visualize the prosthetics before placing the implant
- Transition from analog to digital workflow
- Faster design reviews and communication with the local lab

### How RealGUIDE Helps
- Vast and comprehensive CAD module for reliable restorative design
- Offers restorative workflows that integrate with surgical planning all in one module
- Ability to design in a crown-down approach focusing on prosthetics even before implant is placed
- Features like scanner integration, virtual wax-ups, and smile design help digitize the workflow
- Cloud-based sharing and communication aids collaboration and turnaround

### Key Messages for General Practitioners
| Pain Point | RealGUIDE Solution | Benefit |
|------------|-------------------|---------|
| New to implants | Crown-down planning | Confidence in placement |
| Analog workflow | Scanner integration, virtual wax-ups | Easy digital transition |
| Lab communication | Cloud sharing | Faster case reviews |
| Unpredictable results | Prosthetically driven planning | Natural-looking outcomes |

### Sample Content for General Practitioners

**Social Hook:**
"New to implants? RealGUIDE lets you visualize the final restoration BEFORE you place the implant. It's called crown-down planning—and it changes everything."

**Email Subject Lines:**
- "See the restoration before you place the implant"
- "Ready to go digital? Start with FREE treatment planning"
- "The implant software built for GPs entering implantology"

**Video Script Opening:**
"Placing your first implants? The key to predictable outcomes is visualizing the end result before you begin. RealGUIDE's crown-down approach helps you plan with confidence."

---

## 4. DSO (Dental Service Organization)

**Role:** Clinical Director overseeing 20+ locations

### Needs
- Scalable software
- Standardization of treatment planning
- Quick design turnaround
- Cross-clinic collaboration & communication
- Uniform learning and onboarding across clinics

### Goals
- Implement standardized digital workflows across clinics
- Ensure consistent case quality
- Faster design turnaround to increase patients processed
- Easier collaboration across different clinics and design team
- Ensure uniform learning and onboarding of new and existing treatment team members

### How RealGUIDE Helps
- Scalable for large organizations via flexible module and user access management
- All-inclusive software with all features included ensuring no variability in modules or workflows
- AI tools to automate design and speed up case design
- Cloud-based sharing and communication aids collaboration and turnaround
- New E-learning platform ensures consistent learning across the treatment team

### Key Messages for DSOs
| Pain Point | RealGUIDE Solution | Benefit |
|------------|-------------------|---------|
| Inconsistent workflows | All-inclusive platform | Standardization across locations |
| Training variability | E-learning platform | Uniform onboarding |
| Slow throughput | AI automation | More patients processed |
| Multi-location coordination | Cloud collaboration | Centralized case management |
| Scaling challenges | Flexible user management | Easy expansion |

### Sample Content for DSOs

**Social Hook:**
"Managing implant workflows across 20+ locations? RealGUIDE scales with your organization—one platform, consistent training, standardized outcomes."

**Email Subject Lines:**
- "Standardize your digital workflow across all locations"
- "One platform. 20+ clinics. Consistent outcomes."
- "Train your entire team with RealGUIDE E-learning"

**Video Script Opening:**
"When you're overseeing multiple clinic locations, consistency is everything. RealGUIDE gives you one standardized platform that scales with your organization."

---

## Content Targeting Matrix

| Persona | Primary Modules | Key Pain Point | Lead Message | CTA |
|---------|----------------|----------------|--------------|-----|
| Dental Lab Designer | CAD, FULL SUITE | Multiple systems, slow turnaround | "One software for all your design needs" | Request Demo |
| Periodontist | PLAN, GUIDE | Planning time, surgical accuracy | "Plan faster, operate with confidence" | Try FREE PLAN |
| General Practitioner | PLAN, CAD | New to digital, need guidance | "Visualize before you place" | Start FREE |
| DSO | FULL SUITE, Enterprise | Standardization at scale | "One platform for all locations" | Contact Sales |

---

## Persona-Specific Feature Emphasis

### For Dental Labs (Emphasize)
- AI design automation
- Open file import/export
- No dongles (cloud licensing)
- Comprehensive CAD modules (bars, abutments, restorations)
- Sandbox custom design environment

### For Periodontists (Emphasize)
- iTero/Medit scanner integration
- Accurate surgical guide design
- Full-arch workflow
- Cloud collaboration with labs

### For General Practitioners (Emphasize)
- FREE PLAN module
- Crown-down prosthetic planning
- Virtual wax-ups and smile design
- Easy analog-to-digital transition

### For DSOs (Emphasize)
- Scalable user management
- All-inclusive feature set (no variability)
- E-learning platform
- Cross-clinic collaboration
- Enterprise pricing
