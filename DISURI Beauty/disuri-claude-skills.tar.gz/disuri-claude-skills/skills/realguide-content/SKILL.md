---
name: realguide-content
description: Generate marketing content for ZimVie's RealGUIDE Software Suite - a cloud-based dental implant planning and surgical guide design platform. Use when creating product descriptions, marketing copy, social media posts, email campaigns, landing pages, video scripts, sales collateral, or any content mentioning RealGUIDE modules (PLAN, APP, GUIDE, CAD, FULL SUITE). Triggers on "RealGUIDE", "RealGUIDE 6.0", "dental implant software", "surgical guide design", "implant planning software", or requests for ZimVie dental software content.
---

# RealGUIDE Content Generation

Generate accurate, compelling marketing content for ZimVie's RealGUIDE Software Suite.

## Product Overview

**RealGUIDE Software Suite** is a cloud-based, universal platform for diagnosis, virtual implant treatment planning, surgical guide design, and CAD/CAM restorative design.

**Core Value Proposition:** "One Software, Many Possibilities" - enables collaboration among multidisciplinary dental teams for precise planning and predictable implant placement.

## Target Personas (Priority Order)

| Priority | Persona | Role | Primary Need | Key Module |
|----------|---------|------|--------------|------------|
| 1 | **Dental Lab Designer** | CAD/CAM Specialist | Fast turnaround, open system | CAD, FULL SUITE |
| 2 | Periodontist | Specialist | Surgical accuracy, planning speed | PLAN, GUIDE |
| 3 | General Practitioner | GP entering implantology | Digital transition, crown-down planning | PLAN, CAD |
| 4 | DSO | Clinical Director (20+ locations) | Standardization, scalability | FULL SUITE |

**For detailed persona profiles, pain points, and sample content, see [references/personas.md](references/personas.md)**

## Modules Quick Reference

| Module | Purpose | Price | Key Benefit |
|--------|---------|-------|-------------|
| PLAN | Diagnosis & implant planning | FREE for life | Merge CBCT + STL, plan implants, share with team |
| APP | iOS mobile access | $9/month | Manage projects anywhere, place implants via touch |
| GUIDE | Surgical guide design | $49-$149/month | Design bone/teeth/tissue-supported guides, export STL |
| CAD | Restorative design | $249/month | Crowns, bridges, abutments, full-arch bars, dentures |
| FULL SUITE | Complete solution | $349/month | PLAN + GUIDE + CAD combined |

## Content Generation Workflow

1. **Identify target persona**: Dental Lab Designer (primary), Periodontist, GP, or DSO
2. **Review persona profile**: Check [references/personas.md](references/personas.md) for needs, goals, pain points
3. **Select relevant modules**: Match features to persona needs
4. **Apply messaging framework**: Use HOOK, FAB, or PAS format
5. **Include key differentiators**: Tailor to persona (see below)
6. **Add appropriate CTA**: Demo request, free trial (PLAN), subscription

## Persona-Specific Differentiators

### For Dental Lab Designers (Primary Target)
- AI tools to automate design and speed up case turnaround
- Seamless open import/export (works with any system)
- No dongles - cloud-based licensing for remote access
- Comprehensive CAD modules: bars, abutments, restorations in ONE platform
- Sandbox custom design environment
- Cloud collaboration with clinics and doctors

### For Periodontists
- iTero and Medit scanner integration
- AI-powered treatment planning
- Accurate surgical guide design
- Intuitive full-arch workflow
- Cloud collaboration with referring dentists and labs

### For General Practitioners
- FREE PLAN module to start
- Crown-down prosthetic planning (visualize restoration before implant)
- Virtual wax-ups and smile design
- Easy analog-to-digital transition
- Lab collaboration tools

### For DSOs
- Scalable user and module management
- All-inclusive software (no feature variability)
- E-learning platform for consistent onboarding
- Cross-clinic collaboration
- Enterprise pricing options

## Messaging Frameworks

### HOOK Format (Social/Ads)
```
[Attention-grabbing statement about persona's pain point]
[RealGUIDE solution in 1 sentence]
[Key differentiator for that persona]
[CTA]
```

### FAB Format (Product Pages/Emails)
```
Feature: [Specific capability]
Advantage: [How it's better than alternatives]
Benefit: [What user gains - time, money, outcomes]
```

### PAS Format (Landing Pages/Long-form)
```
Problem: [Pain point specific to persona]
Agitate: [Consequences of not solving]
Solution: [How RealGUIDE addresses it]
```

## Quick Content Examples by Persona

### Dental Lab Designer
**Social:** "Tired of switching between 3 different software systems to complete one case? RealGUIDE combines surgical planning, guide design, and CAD restoration in one open platform. No dongles. No file conversion headaches."

**Email Subject:** "Cut your case turnaround time with AI-powered design"

### Periodontist
**Social:** "What if you could cut your treatment planning time in half while improving surgical accuracy? RealGUIDE's AI-powered planning integrates directly with your iTero or Medit scanner."

**Email Subject:** "Your scanner + RealGUIDE = seamless workflow"

### General Practitioner
**Social:** "New to implants? RealGUIDE lets you visualize the final restoration BEFORE you place the implant. It's called crown-down planning—and it changes everything."

**Email Subject:** "See the restoration before you place the implant"

### DSO
**Social:** "Managing implant workflows across 20+ locations? RealGUIDE scales with your organization—one platform, consistent training, standardized outcomes."

**Email Subject:** "One platform. 20+ clinics. Consistent outcomes."

## Compliance Notes

- Use registered trademark: RealGUIDE® (first mention), RealGUIDE (subsequent)
- Module names use ™: RealGUIDE™ Software Suite
- Pricing is subscription-based; always note "per month"
- Do not make clinical outcome claims without substantiation

## Reference Files

- **[references/product-specs.md](references/product-specs.md)** - Complete module specs, pricing, features
- **[references/personas.md](references/personas.md)** - Detailed persona profiles with needs, goals, sample content
