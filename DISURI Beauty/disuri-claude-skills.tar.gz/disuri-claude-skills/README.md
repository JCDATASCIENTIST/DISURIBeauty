# Claude Skills Collection

Custom Claude Code skills for DISURI Beauty, ZimVie Dental, and general marketing/strategy workflows.

## Structure

```
├── skills/                    # All Claude Code skills
│   ├── disuri-*              # DISURI Beauty skincare brand
│   ├── zimvie-*              # ZimVie dental/medical device
│   ├── joinbrands-disuri-ugc # UGC campaigns on JoinBrands
│   ├── kbeauty-industry-intel # K-beauty market intelligence
│   ├── google-ads            # Google Ads strategy
│   ├── marketing-psychology  # Behavioral science for marketing
│   └── ...                   # Other strategy/operations skills
├── brand-voice/              # Brand voice guidelines (auto-detected by Claude)
├── frameworks/               # Strategic frameworks and compliance docs
└── README.md
```

## Skills Inventory (28 total)

### DISURI Beauty (6 skills)
| Skill | Purpose |
|-------|---------|
| `disuri-social-media` | Social content across Instagram, TikTok, YouTube Shorts |
| `disuri-gmc` | Google Merchant Center product feed generation |
| `disuri-email-marketing` | Email flows: welcome, cart, post-purchase, Queen nurture |
| `disuri-queen-onboarding` | Full Queen partner onboarding packages |
| `joinbrands-disuri-ugc` | UGC campaign briefs for JoinBrands.com |
| `kbeauty-industry-intel` | K-beauty market intelligence and competitive context |

### ZimVie Dental (10 skills)
| Skill | Purpose |
|-------|---------|
| `dental-device-expert` | Domain knowledge for implants, biomaterials, digital dentistry |
| `zimvie-biomaterials` | FDA-compliant marketing for regenerative products |
| `zimvie-brand-guidelines` | Brand identity specs (colors, typography, logo) |
| `zimvie-campaign-copywriting` | FDA-compliant copy frameworks (HOOK, FAB, PAS) |
| `zimvie-content-derivation` | Repurpose video into multi-channel assets |
| `zimvie-data-analytics` | Marketing data analysis and Power BI specs |
| `zimvie-hubspot-emails` | HubSpot HTML+HubL email templates |
| `zimvie-hubspot-landing-pages` | HubSpot landing page templates |
| `zimvie-product-launch` | Full product launch orchestration playbook |
| `realguide-content` | Marketing content for RealGUIDE software suite |

### Marketing & Strategy (12 skills)
| Skill | Purpose |
|-------|---------|
| `google-ads` | Google Ads strategy across all campaign types |
| `display-ad-specs` | StackAdapt + Performance Max creative specs |
| `senior-ugc-strategist` | UGC video scripts and storyboards |
| `marketing-psychology` | 70+ mental models for marketing application |
| `mckinsey-strategic-wealth-advisor` | Strategic wealth and AI investment guidance |
| `data-storytelling` | Data narratives and visualization strategy |
| `visualization-expert` | Chart selection and dashboard design |
| `regression-analysis` | Statistical regression on tabular datasets |
| `sprint-planner` | Agile sprint planning and estimation |
| `visual-design-foundations` | Typography, color theory, spacing systems |
| `project-planner` | Project breakdown with timelines and dependencies |
| `resume-builder` | ATS-optimized resume generation |

## Brand Voice & Frameworks

| File | Purpose |
|------|---------|
| `brand-voice/brand-voice-guidelines.md` | DISURI Beauty brand voice guidelines v3 (auto-detected by `/brand-voice:enforce-voice`) |
| `frameworks/DISURI-Founder-Voice-Transition-Plan.md` | 3-phase plan for transitioning from founder voice to brand voice |
| `frameworks/DISURI-Queen-Content-Compliance-Framework.md` | 7-question pre-publish checklist + enforcement mechanism for Queens |

## Installation

### Individual skills
Double-click any `.skill` file to install in Claude Code or Cowork.

### Full collection
Clone this repo and point Claude Code to the skills directory:
```bash
git clone https://github.com/YOUR_USERNAME/disuri-claude-skills.git
```

## Sources
- DISURI Beauty Brand Strategy v3.0 (Feb 2026)
- DISURI Beauty Brand Style Guide (Nov 2025)
- DISURI Beauty Queens Program Framework (Jan 2026)
